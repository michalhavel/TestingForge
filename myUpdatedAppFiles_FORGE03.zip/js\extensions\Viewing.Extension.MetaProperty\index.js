import './Viewing.Extension.MetaProperty'

export default 'Viewing.Extension.MetaProperty'
