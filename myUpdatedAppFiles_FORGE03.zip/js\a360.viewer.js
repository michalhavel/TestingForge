// <!-- script for a360 viewer -->
window.onload = function () {

    // var myEl1 = document.getElementById('btn1');

    // myEl1.addEventListener('click', function () {
    //     document.getElementById('frame').src =
    //         "https://myhub.autodesk360.com/ue29c8869/shares/public/SH7f1edQT22b515c761eea2b8900d48c165d?mode=embed";

    // });
    var myEl2 = document.getElementById('btn2');

    myEl2.addEventListener('click', function () {
        document.getElementById('frame').src =
            "https://myhub.autodesk360.com/ue29c8869/shares/public/SH7f1edQT22b515c761ebf78f4bcbd5a5b84?mode=embed";
    });

    var myEl8 = document.getElementById('btn8');

    myEl8.addEventListener('click', function () {
        document.getElementById('frame').src =
            "https://myhub.autodesk360.com/ue29c8869/shares/public/SH7f1edQT22b515c761eacf74a1e203afe9f?mode=embed";
    });

    var myEl9 = document.getElementById('btn9');

    myEl9.addEventListener('click', function () {
        document.getElementById('frame').src =
            "https://myhub.autodesk360.com/ue29c8869/shares/public/SH7f1edQT22b515c761e85cc991fccc9036b?mode=embed";
    });

    var myEl10 = document.getElementById('btn10');

    myEl10.addEventListener('click', function () {
        document.getElementById('frame').src =
            "https://myhub.autodesk360.com/ue29c8869/shares/public/SH7f1edQT22b515c761e774b6a9e6aa7f95f?mode=embed";
    });

    var myEl11 = document.getElementById('btn11');

    myEl11.addEventListener('click', function () {
        document.getElementById('frame').src =
            "https://myhub.autodesk360.com/ue29c8869/shares/public/SH7f1edQT22b515c761eac9f650ac976de3d?mode=embed";
    });

    var myEl12 = document.getElementById('btn12');

    myEl12.addEventListener('click', function () {
        document.getElementById('frame').src =
            "https://myhub.autodesk360.com/ue29c8869/shares/public/SH7f1edQT22b515c761ee713102dcda242d8?mode=embed";
    });
};
    // <!-- script -->