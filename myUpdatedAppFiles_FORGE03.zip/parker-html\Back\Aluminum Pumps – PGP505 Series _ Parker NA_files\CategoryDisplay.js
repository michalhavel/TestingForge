/* Start: Aurora Migration */
/*//-----------------------------------------------------------------
// Licensed Materials - Property of IBM
//
// WebSphere Commerce
//
// (C) Copyright IBM Corp. 2007, 2013 All Rights Reserved.
//
// US Government Users Restricted Rights - Use, duplication or
// disclosure restricted by GSA ADP Schedule Contract with
// IBM Corp.
//-----------------------------------------------------------------

//
//

*//**
* @fileOverview This file holds methods to perform client side operations in relation to catalog browsing, usually at the category level.<b> 
* 			For example, this file holds methods to add items to the shopping cart, wish list and compare zone and to resolve SKUs.<b> 
*			This file is referenced in a collection of JSPs including all of the catalog entry display JSPs such as
*			CachedBundleDisplay.jsp, CachedItemDisplay.jsp , CachedPackageDisplay.jsp, CachedProductOnlyDisplay.jsp.
*			As well this file is included in CategoryOnlyResultsDisplay.jsp and in none catalog browsing pages such as 
*			CatalogSearchDisplay.jsp and MyAccountDisplay.jsp.
*
* @version 1.0
**//*

*//**
* @class categoryDisplayJS This class defines all the variables and functions used by the CategoryDisplay.js. Any page that will use a function in this file
*		can access that function thru this class. Pages that use categoryDisplayJS include CachedProductOnlyDisplay.jsp which is responsible for
*		displaying product details. As well CategoryOnlyResultsDisplay.jsp uses this page to facilitate the category browsing functionality such as add to cart, 
*		wish list and compare zone.
*
**//*
categoryDisplayJS={
	
	*//** An array of entitled items which is used in various methods throughout CategoryDisplay.js **//*
	entitledItems:[],
	
	*//** An map which holds the attributes of a set of products **//*
	selectedProducts:new Object(),
	
	*//** A map of attribute name value pairs for the currently selected attribute values **//*
	selectedAttributes:new Object(),
	
	*//** Can be used to hold a map of error messages **//*
	errorMessages: new Object(),
	
	*//** The language ID currently in use **//*
	langId: "-1",
	
	*//** The store ID currently in use **//*
	storeId: "",
	
	*//** The catalog ID currently in use **//*
	catalogId: "",
	
	*//** The order ID currently in use if being called from the pending order details page.**//*
	orderId: "",
	
	*//** Holds a boolean value indicating whether or not AJAX shopping cart is enabled or not. **//*
	ajaxShopCart:true,
	
	*//** Holds a boolean value indicating whether or not AJAX My Account is enabled or not. **//*
	ajaxMyAccount:true,
	
	*//** Can be used to indicate whether or not there has been a context change event **//*
	contextChanged:false, 
	
	*//** Set to true in the goBack and goForward methods **//*
	isHistory:false,
	
	*//** Holds an array of  JSON objects representing properties of merchandising associations **//*
	merchandisingAssociationItems:[],
	
	*//** Holds an array of JSON objects holding information about the parent catalog entries of merchandising associations **//*
	baseCatalogEntryDetails:[],
	
	*//** Used to determine the index of the next association to display and is used as a global storage variable to share data between methods. **//*
	associationThumbnailIndex:1,
	
	*//** A count of the number of merchandising associations available. **//*
	totalAssociationCount:0,
	
	*//** A boolean used in a variety of the add to cart methods to tell whether or not the base item was added to the cart. **//*
	baseItemAddedToCart:false,
	
	*//** A boolean used to determine whether or not to add merchandising associations to the cart **//*
	merchandisingProductAssociationAddToCart:false,
	
	*//** The form which holds information about merchandising associations to be added to the cart **//*
	merchandisingProductAssociationForm:"",
	
	*//** A boolean used to determine whether or not the parent catalog entry is a bundle bean. **//*
	isParentBundleBean:false,
	
	*//** Holds the current user type such as guest or registered user. Allowed values are 'G' for guest and 'R' for registered.**//*
	userType:"",
	
	*//** A variable used to form the url dynamically for the more info link in the Quickinfo popup *//*
	moreInfoUrl :"",
	*//** The text to display as an alt to the image used on the MerchandisingAssociationDisplay.jsp to show the previous assoication **//*
	displayPrevAssociation:"",
	
	*//** The text to display as an alt to the image used on the MerchandisingAssociationDisplay.jsp to show the next assoication **//*
	displayNextAssociation:"",
	
	*//** A map holding a mapping between product IDs as its key and the first entitled item ID of that product as its value **//*
	defaultItemArray:[],

	*//** The type of the catalog page that the user is currently viewing **//*
	currentPageType:"",

	*//** The identifier of the catalog entry that the current page is displaying **//*
	currentCatalogEntryId:"",
	
    *//** a JSON object that holds attributes of an entitled item **//*
    entitledItemJsonObject: null,

	*//**
	* A boolean used to to determine is it from a Qick info popup or not. 
	**//*
	isPopup : false,

	*//**
	* A boolean used to to determine whether or not to diplay the price range when the catEntry is selected. 
	**//*
	displayPriceRange : true,

	*//**
	* This array holds the json object retured from the service, holding the price information of the catEntry.
	**//*
	itemPriceJsonOject : [],
	
	*//** 
	* stores all name and value of all swatches 
	* this is a 2 dimension array and each record i contains the following information:
	* allSwatchesArray[i][0] - attribute name of the swatch
	* allSwatchesArray[i][1] - attribute value of the swatch
	* allSwatchesArray[i][2] - image1 of swatch (image to use for enabled state)
	* allSwatchesArray[i][4] - onclick action of the swatch when enabled
	**//*
	allSwatchesArray : [],
	
	*//**
	* initHistory This function will take elementId and changeUrl as inputs and create a new history tracker object and sets the initial state.
	*			  This is used on CategoriesDisplay.jsp to initialize the page history to the CategoryDisplay URL of the category you are on.
	* @param {String} elementId  HistoryTracker elementId.
	* @param {String} changeUrl HistoryTracker URL.
	*
	**//*
	initHistory:function(elementId, changeUrl){
		var historyObject = new categoryDisplayJS.HistoryTracker(elementId, changeUrl);
		dojo.back.setInitialState(historyObject);	
	},


	 This function processes the category URL and loads the content based on what is present after the hash in the URL.
	
	processCategoryURL:function(){
		var hashString = location.hash;		
		var needContextUpdate = false;	
		var wholeUrl;
		if(hashString){
			hashString = hashString.substring(1, hashString.length);
			 Remove the identifier attached 
			wholeUrl = hashString;
			var indexOfIdentifier = hashString.indexOf("identifier", 0);
			if(indexOfIdentifier >= 0){
				wholeUrl = hashString.substring(0, indexOfIdentifier);
			}
			needContextUpdate = true;
			wholeUrl = unescape(wholeUrl);
		 }
		if(needContextUpdate){			
			isHistory=true;
			wc.render.getRefreshControllerById("CategoryDisplay_Controller").url = wholeUrl;
			wc.render.updateContext("CategoryDisplay_Context");
		}
	},

	*//**
	* setAjaxShopCart This function will set the flag "ajaxShopCart" which is used to determine if the shopping cart is using the Ajax flow or not.
	*
	* @param {Boolean} ajaxShopCart Flag which indicates whther to use AJAX shopping cart or not.
	*
	**//*
	setAjaxShopCart:function(ajaxShopCart){
		this.ajaxShopCart = ajaxShopCart;
	},
	
	*//**
	* setAjaxMyAccount This function will set the flag "ajaxMyAccount" which is used to determine if the My Account page is using the Ajax flow or not.
	*
	* @param {Boolean} ajaxMyAccount Flag which indicates whether to use AJAX My Account or not.
	*
	**//*	
	setAjaxMyAccount:function(ajaxMyAccount){
		this.ajaxMyAccount = ajaxMyAccount;
	},	
	
	*//**
	* setCommonParameters This function initializes storeId, catalogId, and langId.
	*
	* @param {String} langId The language id to use.
	* @param {String} storeId The store id to use.
	* @param {String} catalogId The catalog id to use.
	* @param {String} userType The type of user. G for Guest user.
	* 
	**//*
	setCommonParameters:function(langId,storeId,catalogId,userType){
		this.langId = langId;
		this.storeId = storeId;
		this.catalogId = catalogId;
		this.userType = userType;
	},
	
	*//**
	* setEntitledItems Sets an array of entitled items for a product. 
	*				   This function is used in CachedBundleDisplay.jsp to add all the entitled SKUs of the products in a particular bundle to this array.
	*				   The array that is generated is used later in {@link fastFinderJS.resolveSKU}.
	* 
	* @param {Object} entitledItemArray An object which holds both the catalog entry ID as well as an array of attributes for the entitled items of a product.
	*
	**//*
	setEntitledItems : function(entitledItemArray){
		this.entitledItems = entitledItemArray;
	},

	*//**
	* setSelectedAttribute Sets the selected attribute value for a particular attribute not in reference to any catalog entry.
	*					   One place this function is used is on CachedProductOnlyDisplay.jsp where there is a drop down box of attributes.
	*					   When an attribute is selected from that drop down this method is called to update the selected value for that attribute.
	*
	* @param {String} selectedAttributeName The name of the attribute.
	* @param {String} selectedAttributeValue The value of the selected attribute.
	*
	**//*
	setSelectedAttribute : function(selectedAttributeName , selectedAttributeValue){ 
		console.debug(selectedAttributeName +" : "+ selectedAttributeValue);
		this.selectedAttributes[selectedAttributeName] = selectedAttributeValue;
		this.moreInfoUrl=this.moreInfoUrl+'&'+selectedAttributeName+'='+selectedAttributeValue;
	},

	*//**
	* setSelectedAttributeJS Sets the selected attribute value for a particular attribute not in reference to any catalog entry.
	*					   One place this function is used is on the quick info pop up where there is a drop down box of attributes.
	*					   When an attribute is selected from that drop down this method is called to update the selected value for that attribute.
	*
	* @param {String} selectedAttributeName The name of the attribute.
	* @param {String} selectedAttributeValue The value of the selected attribute.
	*
	**//*
	setSelectedAttributeJS : function(selectedAttributeName , selectedAttributeValue){ 
		console.debug(selectedAttributeName.replace(/'/g,"&#039;") +" : "+ selectedAttributeValue.replace(/'/g,"&#039;"));
		this.selectedAttributes[selectedAttributeName.replace(/'/g,"&#039;")] = selectedAttributeValue.replace(/'/g,"&#039;");
		this.moreInfoUrl=this.moreInfoUrl+'&'+selectedAttributeName.replace(/'/g,"&#039;") +'='+selectedAttributeValue.replace(/'/g,"&#039;");
	},

	*//**
	* This function is used to change the price displayed in the Product Display Page on change of  a attribute of the product using an AJAX call. 
	* This function will resolve the catentryId using entitledItemId and displays the price of the catentryId.
	*				
	* @param {Object} entitledItemId A DIV containing a JSON object which holds information about a catalog entry. You can reference CachedProductOnlyDisplay.jsp to see how that div is constructed.
	* @param {Boolean} isPopup If the value is true, then this implies that the function was called from a quick info pop-up.
	* @param {Boolean} displayPriceRange If the value is true, then display the price range. If it is false then donot display the price range.
	*
	**//*
	changePrice : function(entitledItemId,isPopup,displayPriceRange){
		this.displayPriceRange = displayPriceRange;
		this.isPopup = isPopup;
		var entitledItemJSON;

		if (dojo.byId(entitledItemId)!=null && !this.isPopup) {
			//the json object for entitled items are already in the HTML. 
			 entitledItemJSON = eval('('+ dojo.byId(entitledItemId).innerHTML +')');
		}else{
			//if dojo.byId(entitledItemId) is null, that means there's no <div> in the HTML that contains the JSON object. 
			//in this case, it must have been set in catalogentryThumbnailDisplay.js when the quick info
			entitledItemJSON = this.getEntitledItemJsonObject(); 
		}
		
		this.setEntitledItems(entitledItemJSON);
		var catalogEntryId = this.getCatalogEntryId();
		
		if(catalogEntryId!=null){
			//check if the json object is already present for the catEntry.
			if(this.itemPriceJsonOject[catalogEntryId] != null && this.itemPriceJsonOject[catalogEntryId] != 'undefined'){
				this.displayPrice(this.itemPriceJsonOject[catalogEntryId].catalogEntry);
				console.debug("CategoryDisplay.changePrice: using stored json object.");
			}
			//if json object is not present, call the service to get the details.
			else{
				var parameters = {};
				parameters.storeId = this.storeId;
				parameters.langId= this.langId;
				parameters.catalogId= this.catalogId;
				parameters.productId= catalogEntryId;
				parameters.catalogEntryId = catalogEntryId; // this variable is used in GetCatalogEntryDetailsByID
				parameters.onlyCatalogEntryPrice = 'true';

				dojo.xhrPost({
					url: getAbsoluteURL() + "GetCatalogEntryDetailsByID",				
					handleAs: "json-comment-filtered",
					content: parameters,
					service: this,
					load: categoryDisplayJS.displayPriceServiceResponse,
					error: function(errObj,ioArgs) {
						console.debug("CategoryDisplay.changePrice: Unexpected error occurred during an xhrPost request.");
					}
				});
			}
		}
		else{
			console.debug("CategoryDisplay.changePrice: all attributes are not selected.");
		}
				
	},

	*//** 
	 * Displays price of the catEntry selected with the JSON objrct returned from the server.
	 * 
	 * @param {object} serviceRepsonse The JSON response from the service.
	 * @param {object} ioArgs The arguments from the service call.
	 *//*	
	 displayPriceServiceResponse : function(serviceResponse, ioArgs){
		
		//stores the json object, so that the service is not called when same catEntry is selected.
		categoryDisplayJS.itemPriceJsonOject[serviceResponse.catalogEntry.catalogEntryIdentifier.uniqueID] = serviceResponse;

		categoryDisplayJS.displayPrice(serviceResponse.catalogEntry);
	 },

	*//** 
	 * Displays price of the attribute selected with the JSON oject.
	 * 
	 * @param {object} catEntry The JSON object with catalog entry details.
	 *//*	
	 displayPrice : function(catEntry){

		var tempString;
		var popup = categoryDisplayJS.isPopup;

		if(popup == true){
			document.getElementById('productPrice').innerHTML = catEntry.offerPrice;
			document.getElementById('productName').innerHTML = catEntry.description[0].name;
			document.getElementById('productSKUValue').innerHTML = catEntry.catalogEntryIdentifier.externalIdentifier.partNumber;
		}
		
		if(popup == false){
			var innerHTML = "";
			if(!catEntry.listPriced ||  catEntry.listPrice <= catEntry.offerPrice){
				innerHTML = "<span class='price bold'>"+MessageHelper.messages['PRICE']+" "+"</span>" +
							"<span class='price bold'>" + catEntry.offerPrice + "</span>";
			}
			else{
				innerHTML = "<span class='price bold'>"+MessageHelper.messages['PRICE']+" "+"</span>" +
							"<span class='price listPrice bold'>" + catEntry.listPrice + "</span>"+
							"<div class='price offerprice bold'>" + catEntry.offerPrice + "</div>";
			}

			innerHTML = innerHTML +	"<br />";
			
			if(categoryDisplayJS.displayPriceRange == true){
				for(var i in catEntry.priceRange){
					if(catEntry.priceRange[i].endingNumberOfUnits != 'null'){
						tempString = MessageHelper.messages['TieredPricingDisp'];
						tempString = tempString.replace('{0}',catEntry.priceRange[i].startingNumberOfUnits);
						tempString = tempString.replace('{1}',catEntry.priceRange[i].endingNumberOfUnits);
						tempString = tempString.replace('{2}',catEntry.priceRange[i].localizedPrice);
						innerHTML = innerHTML + "<span class='price bold'>" + tempString + "</span>";;
					}
					else{
						tempString = MessageHelper.messages['TieredPricingDispLast'];
						tempString = tempString.replace('{0}',catEntry.priceRange[i].startingNumberOfUnits);
						tempString = tempString.replace('{1}',catEntry.priceRange[i].localizedPrice);
						innerHTML = innerHTML + "<span class='price bold'>" + tempString + "</span>";;
					}
					innerHTML = innerHTML + "<br />";
				}
			}
			document.getElementById('WC_CachedProductOnlyDisplay_div_4').innerHTML = innerHTML;
			document.getElementById('catalog_link').innerHTML = catEntry.description[0].name;
		}
	 },	
	
	*//**
	* setSelectedAttributeOfProduct Sets the selected attribute value for an attribute of a specified product.
	*								This function is used to set the assigned value of defining attributes to specific 
	*								products which will be stored in the selectedProducts map.
	*
	* @param {String} productId The catalog entry ID of the catalog entry to use.
	* @param {String} selectedAttributeName The name of the attribute.
	* @param {String} selectedAttributeValue The value of the selected attribute.
	*
	**//*
	setSelectedAttributeOfProduct : function(productId,selectedAttributeName,selectedAttributeValue){
		
		selectedAttributesForProduct = new Object();

		if(this.selectedProducts[productId]) selectedAttributesForProduct = this.selectedProducts[productId];
		
		selectedAttributesForProduct[selectedAttributeName] = selectedAttributeValue;
		this.selectedProducts[productId] = selectedAttributesForProduct;
		
	},
	
	// Function for subcategory display pagination	
	
	*//**
	* gotoASubCategoryDisplayPage  This function is used to validate the entered page number and loads the page if valid or displays an error message otherwise.
	*
	* @param {String} pageNum The page number entered.
	* @param {String} totalPages The total number of pages.
	* @param {String} pageSize The page size.
	* @param {String} subCatDispUrl The sub category display URL.
	*
	**//*
	gotoASubCategoryDisplayPage : function(pageNum, totalPages, pageSize, subCatDispUrl) {
		pageNum = trim(pageNum);
		if (pageNum == "") {	
			 MessageHelper.formErrorHandleClient(document.getElementById('subCategoriesListDisplayPageNum').id,MessageHelper.messages['ERROR_EMPTY_NUM']);
			return;
		}
		
		if (MessageHelper.IsNumeric(pageNum,false) == false){ 
			 MessageHelper.formErrorHandleClient(document.getElementById('subCategoriesListDisplayPageNum').id,MessageHelper.messages['ERROR_PAGE_NUM']);

			return;
		}	
		
		if (pageNum >= 1 && pageNum <= totalPages) {
		    MessageHelper.hideAndClearMessage();
			var url = subCatDispUrl + "&beginIndex=" + ((pageNum-1) * pageSize);
			this.loadSubCategoryContentURL(url)
		} else {
			MessageHelper.formErrorHandleClient(document.getElementById('subCategoriesListDisplayPageNum').id,MessageHelper.messages['ERROR_PAGE_NUM']);
			
			return;
		}
	}, 

	*//**
	* getCatalogEntryId Returns the catalog entry ID of the catalog entry with the selected attributes as specified in the {@link fastFinderJS.selectedAttributes} value.
	*					This method uses {@link fastFinderJS.resolveSKU} to find the SKU with the selected attributes values.
	*
	* @see fastFinderJS.resolveSKU
	*
	* @return {String} catalog entry ID.
	*
	**//*
	getCatalogEntryId : function(){
		var attributeArray = [];
		for(attribute in this.selectedAttributes){
			attributeArray.push(attribute + "_" + this.selectedAttributes[attribute]);
		}
		return this.resolveSKU(attributeArray);
	},
	
	*//**
	* getImageForSKU Returns the full image of the catalog entry with the selected attributes as specified in the {@link fastFinderJS.selectedAttributes} value.
	*					This method uses resolveImageForSKU to find the SKU image with the selected attributes values.
	*
	* @return {String} path to the SKU image.
	*
	**//*
	getImageForSKU : function(){
		var attributeArray = [];
		for(attribute in this.selectedAttributes){
			attributeArray.push(attribute + "_" + this.selectedAttributes[attribute]);
		}
		return this.resolveImageForSKU(attributeArray);
	},
	
	*//**
	* getCatalogEntryIdforProduct Returns the catalog entry ID for a catalog entry that has the same attribute values as a specified product's selected attributes as passed in via the selectedAttributes parameter.
	*
	* @param {String[]} selectedAttributes The array of selected attributes upon which to resolve the SKU.
	*
	* @return {String} catalog entry ID of the SKU.
	*
	**//*
	getCatalogEntryIdforProduct : function(selectedAttributes){
		var attributeArray = [];
		for(attribute in selectedAttributes){
			attributeArray.push(attribute + "_" + selectedAttributes[attribute]);
		}
		return this.resolveSKU(attributeArray);
	},


	*//**
	* resolveSKU Resolves a SKU using an array of defining attributes.
	*
	* @param {String[]} attributeArray An array of defining attributes upon which to resolve a SKU.
	*
	* @return {String} catentry_id The catalog entry ID of the SKU.
	*
	**//*
	resolveSKU : function(attributeArray){
	
		console.debug("Resolving SKU >> " + attributeArray +">>"+ this.entitledItems);
		var catentry_id = "";
		var attributeArrayCount = attributeArray.length;
		
		for(x in this.entitledItems){
			var catentry_id = this.entitledItems[x].catentry_id;
			var Attributes = this.entitledItems[x].Attributes;
			var attributeCount = 0;
			for(index in Attributes){
				attributeCount ++;
			}

			// Handle special case where a catalog entry has one sku with no attributes
			if (attributeArrayCount == 0 && attributeCount == 0){
				return catentry_id;
			}
			if(attributeCount != 0 && attributeArrayCount >= attributeCount){
				var matchedAttributeCount = 0;

				for(attributeName in attributeArray){
					var attributeValue = attributeArray[attributeName];
					if(attributeValue in Attributes){
						matchedAttributeCount ++;
					}
				}
				
				if(attributeCount == matchedAttributeCount){
					console.debug("CatEntryId:" + catentry_id + " for Attribute: " + attributeArray);
					return catentry_id;
				}
			}
		}
		return null;
	},

	*//**
	* resolveImageForSKU Resolves image of a SKU using an array of defining attributes.
	*
	* @param {String[]} attributeArray An array of defining attributes upon which to resolve a SKU.
	*
	* @return {String} imagePath The location of SKU image.
	*
	**//*
	resolveImageForSKU : function(attributeArray){
	
		console.debug("Resolving SKU >> " + attributeArray +">>"+ this.entitledItems);
		var imagePath = "";
		var attributeArrayCount = attributeArray.length;
		
		for(x in this.entitledItems){
			var imagePath = this.entitledItems[x].ItemImage;
			var Attributes = this.entitledItems[x].Attributes;
			var attributeCount = 0;
			for(index in Attributes){
				attributeCount ++;
			}

			// Handle special case where a catalog entry has one sku with no attributes
			if (attributeArrayCount == 0 && attributeCount == 0){
				return imagePath;
			}
			if(attributeCount != 0 && attributeArrayCount >= attributeCount){
				var matchedAttributeCount = 0;

				for(attributeName in attributeArray){
					var attributeValue = attributeArray[attributeName];
					if(attributeValue in Attributes){
						matchedAttributeCount ++;
					}
				}
				
				if(attributeCount == matchedAttributeCount){
					console.debug("ItemImage:" + imagePath + " for Attribute: " + attributeArray);
					return imagePath;
				}
			}
		}
		return null;
	},
	
	*//**
	* updates the product image from the PDP page to use the selected SKU image
	* @param String entitledItemId the ID of the SKU
	**//*
	changeProdImage: function(entitledItemId){
		if (dojo.byId(entitledItemId)!=null) {
			//the json object for entitled items are already in the HTML. 
			 entitledItemJSON = eval('('+ dojo.byId(entitledItemId).innerHTML +')');
		}
		this.setEntitledItems(entitledItemJSON);
		var skuImage = categoryDisplayJS.getImageForSKU();
		if(skuImage != null){
			document.getElementById('productMainImage').src = skuImage;
		}
	},
		
	*//**
	* Handles the case when a swatch is selected. Set the border of the selected swatch.
	* @param {String} selectedAttributeName The name of the selected swatch attribute.
	* @param {String} selectedAttributeValue The value of the selected swatch attribute.
	* @param {String} entitledItemId The ID of the SKU
	* @param {String} doNotDisable The name of the swatch attribute that should never be disabled.
	* @return boolean Whether the swatch is available for selection
	**//*
	selectSwatch: function(selectedAttributeName, selectedAttributeValue, entitledItemId, doNotDisable) {
		for (attribute in this.selectedAttributes) {
			if (attribute == selectedAttributeName) {
				// case when the selected swatch is already selected with a value, if the value is different than
				// what's being selected, reset other swatches and deselect the previous value and update selection
				if (this.selectedAttributes[attribute] != selectedAttributeValue) {
					// deselect previous value and update swatch selection
					document.getElementById("swatch_" + this.selectedAttributes[attribute]).className = "swatch_normal";
				}
			}
		}
		this.makeSwatchSelection(selectedAttributeName, selectedAttributeValue, entitledItemId, doNotDisable);
	},

	*//**
	* Make swatch selection - add to selectedAttribute, select image, and update other swatches and SKU image based on current selection.
	* @param {String} swatchAttrName The name of the selected swatch attribute.
	* @param {String} swatchAttrValue The value of the selected swatch attribute.
	* @param {String} entitledItemId The ID of the SKU.
	* @param {String} doNotDisable The name of the swatch attribute that should never be disabled.	
	**//*
	makeSwatchSelection: function(swatchAttrName, swatchAttrValue, entitledItemId, doNotDisable) {
		this.setSelectedAttribute(swatchAttrName, swatchAttrValue);
		document.getElementById("swatch_" + swatchAttrValue).className = "swatch_selected";
		this.updateSwatchImages(swatchAttrName, entitledItemId, doNotDisable);
		this.changeProdImage(entitledItemId);
	},
		
	*//**
	* Constructs record and add to this.allSwatchesArray.
	* @param {String} swatchName The name of the swatch attribute.
	* @param {String} swatchValue The value of the swatch attribute.	
	* @param {String} swatchImg1 The path to the swatch image.
	**//*
	addToAllSwatchsArray: function(swatchName, swatchValue, swatchImg1) {
		if (!this.existInAllSwatchsArray(swatchName, swatchValue)) {
			var swatchRecord = new Array();
			swatchRecord[0] = swatchName;
			swatchRecord[1] = swatchValue;
			swatchRecord[2] = swatchImg1;
			swatchRecord[4] = document.getElementById("swatch_" + swatchValue).onclick;
			this.allSwatchesArray.push(swatchRecord);
		}
	},

	*//**
	* Checks if a swatch is already exist in this.allSwatchesArray.
	* @param {String} swatchName The name of the swatch attribute.
	* @param {String} swatchValue The value of the swatch attribute.		
	* @return boolean Value indicating whether or not the specified swatch name and value exists in the allSwatchesArray.
	*//*
	existInAllSwatchsArray: function(swatchName, swatchValue) {
		for(var i=0; i<this.allSwatchesArray.length; i++) {
			var attrName = this.allSwatchesArray[i][0];
			var attrValue = this.allSwatchesArray[i][1];
			if (attrName == swatchName && attrValue == swatchValue) {
				return true;
			}
		}
		return false;
	},
	
	*//**
	* Check the entitledItems array and pre-select the first entited SKU as the default swatch selection.
	* @param {String} entitledItemId The ID of the SKU.
	* @param {String} doNotDisable The name of the swatch attribute that should never be disabled.		
	**//*
	makeDefaultSwatchSelection: function(entitledItemId, doNotDisable) {
		if (this.entitledItems.length == 0) {
			if (dojo.byId(entitledItemId)!=null) {
				 entitledItemJSON = eval('('+ dojo.byId(entitledItemId).innerHTML +')');
			}
			this.setEntitledItems(entitledItemJSON);
		}
		
		// need to make selection for every single swatch
		for(x in this.entitledItems){
			var Attributes = this.entitledItems[x].Attributes;
			for(y in Attributes){
				var index = y.indexOf("_");
				var swatchName = y.substring(0, index);
				var swatchValue = y.substring(index+1);
				this.makeSwatchSelection(swatchName, swatchValue, entitledItemId, doNotDisable);
			}
			break;
		}
	},
	
	*//**
	* Update swatch images - this is called after selection of a swatch is made, and this function checks for
	* entitlement and disable swatches that are not available
	* @param selectedAttrName The attribute that is selected
	* @param {String} entitledItemId The ID of the SKU.
	* @param {String} doNotDisable The name of the swatch attribute that should never be disabled.	
	**//*
	updateSwatchImages: function(selectedAttrName, entitledItemId, doNotDisable) {
		var swatchToUpdate = new Array();
		var selectedAttrValue = this.selectedAttributes[selectedAttrName];
		
		// finds out which swatch needs to be updated, add to swatchToUpdate array
		for(var i=0; i<this.allSwatchesArray.length; i++) {
			var attrName = this.allSwatchesArray[i][0];
			var attrValue = this.allSwatchesArray[i][1];
			var attrImg1 = this.allSwatchesArray[i][2];
			var attrImg2 = this.allSwatchesArray[i][3];
			var attrOnclick = this.allSwatchesArray[i][4];
			
			if (attrName != doNotDisable && attrName != selectedAttrName) {
				var swatchRecord = new Array();
				swatchRecord[0] = attrName;
				swatchRecord[1] = attrValue;
				swatchRecord[2] = attrImg1;
				swatchRecord[4] = attrOnclick;
				swatchRecord[5] = false;
				swatchToUpdate.push(swatchRecord);
			}
		}
		
		// finds out which swatch is entitled, if it is, image should be set to enabled
		// go through entitledItems array and find out swatches that are entitled 
		for (x in this.entitledItems) {
			var Attributes = this.entitledItems[x].Attributes;

			for(y in Attributes){
				var index = y.indexOf("_");
				var entitledSwatchName = y.substring(0, index);
				var entitledSwatchValue = y.substring(index+1);	
				
				//the current entitled item has the selected attribute value
				if (entitledSwatchName == selectedAttrName && entitledSwatchValue == selectedAttrValue) {
					//go through the other attributes that are available to the selected attribute
					//exclude the one that is selected
					for (z in Attributes) {
						var index2 = z.indexOf("_");
						var entitledSwatchName2 = z.substring(0, index2);
						var entitledSwatchValue2 = z.substring(index2+1);
						
						if(y != z){ //only check the attributes that are not the one selected
							for (i in swatchToUpdate) {
								var swatchToUpdateName = swatchToUpdate[i][0];
								var swatchToUpdateValue = swatchToUpdate[i][1];
								
								if (entitledSwatchName2 == swatchToUpdateName && entitledSwatchValue2 == swatchToUpdateValue) {
									swatchToUpdate[i][5] = true;
								}
							}
						}
					}
				}
			}
		}

		// Now go through swatchToUpdate array, and update swatch images
		var disabledAttributes = [];
		for (i in swatchToUpdate) {
			var swatchToUpdateName = swatchToUpdate[i][0];
			var swatchToUpdateValue = swatchToUpdate[i][1];
			var swatchToUpdateImg1 = swatchToUpdate[i][2];
			var swatchToUpdateImg2 = swatchToUpdate[i][3];
			var swatchToUpdateOnclick = swatchToUpdate[i][4];
			var swatchToUpdateEnabled = swatchToUpdate[i][5];		
			
			if (swatchToUpdateEnabled) {
				document.getElementById("swatch_" + swatchToUpdateValue).style.opacity = 1;
				document.getElementById("swatch_" + swatchToUpdateValue).style.filter = "";
				document.getElementById("swatch_" + swatchToUpdateValue).onclick = swatchToUpdateOnclick;
			} else {
				if(swatchToUpdateName != doNotDisable){
					document.getElementById("swatch_" + swatchToUpdateValue).style.opacity = 0.3;
					document.getElementById("swatch_" + swatchToUpdateValue).style.filter = 'alpha(opacity=30)';
					document.getElementById("swatch_" + swatchToUpdateValue).onclick = null;
					
					//The previously selected attribute is now unavailable for the new selection
					//Need to switch the selection to an available value
					if(this.selectedAttributes[swatchToUpdateName] == swatchToUpdateValue){
						disabledAttributes.push(swatchToUpdate[i]);
					}
				}
			}
		}
		
		//If there were any previously selected attributes that are now unavailable
		//Find another available value for that attribute and update other attributes according to the new selection
		for(i in disabledAttributes){
			var disabledAttributeName = disabledAttributes[i][0];
			var disabledAttributeValue = disabledAttributes[i][1];

			for (i in swatchToUpdate) {
				var swatchToUpdateName = swatchToUpdate[i][0];
				var swatchToUpdateValue = swatchToUpdate[i][1];
				var swatchToUpdateEnabled = swatchToUpdate[i][5];	
				
				if(swatchToUpdateName == disabledAttributeName && swatchToUpdateValue != disabledAttributeValue && swatchToUpdateEnabled){
						document.getElementById("swatch_" + disabledAttributeValue).className = "swatch_normal";
						this.makeSwatchSelection(swatchToUpdateName, swatchToUpdateValue, entitledItemId, doNotDisable);
					break;
				}
			}
		}
	},

	*//**
	* updateParamObject This function updates the given params object with a key to value pair mapping.
	*				    If the toArray value is true, It creates an Array for duplicate entries otherwise it overwrites the old value.
	*			        This is useful while making a service call which accepts a few parameters of type array.
	*					This function is used to prepare a a map of parameters which can be passed to XMLHttpRequests. 
	* 					The keys in this parameter map will be the name of the parameter to send and the value is the corresponding value for each parameter key.
	* @param {Object} params The parameters object to add name value pairs to.
	* @param {String} key The new key to add.
	* @param {String} value The new value to add to the specified key.
	* @param {Boolean} toArray Set to true to turn duplicate keys into an array, or false to override previous values for a specified key.
	* @param {int} index The index in an array of values for a specified key in which to place a new value.
	*
	* @return {Object} params A parameters object holding name value pairs.
	*
	**//*
	updateParamObject:function(params, key, value, toArray, index){
	
	   if(params == null){
		   params = [];
	   }

	   if(params[key] != null && toArray)
	   {
			if(dojo.lang.isArrayLike(params[key]))
			{
				//3rd time onwards
			    if(index != null && index != "")
				{
					//overwrite the old value at specified index
				     params[key][index] = value;
				}
				else
				{
				    params[key].push(value);
			     }
		    }
			else
			{
			     //2nd time
			     var tmpValue = params[key];
			     params[key] = [];
			     params[key].push(tmpValue);
			     params[key].push(value);
		    }
	   }
	   else
	   {
			//1st time
		   if(index != null && index != "" && index != -1)
		   {
		      //overwrite the old value at specified index
		      params[key+"_"+index] = value;
		   }
		   else if(index == -1)
		   {
		      var i = 1;
		      while(params[key + "_" + i] != null)
			  {
			       i++;
		      }
		      params[key + "_" + i] = value;
		   }
		   else
		   {
		      params[key] = value;
		    }
	   }
	   return params;
	 },
	 
	 *//**
	  *  This function associates the product id with its first entitledItemId.
	  *  @param {String} productId The id of the product.
	  *  @param {String} entitledItemId The id of the first entitledItem of the product.
	  *//*
	 setDefaultItem : function(productId,entitledItemId){
		this.defaultItemArray[productId] = entitledItemId;
		
},
	
     *	This function retrieves the first entitledItemId of the product.
	 *  @param {String} productId The id of the product.
	 *  
	 *  @return {String} The id of the first entitledItem of the product.
	 
getDefaultItem : function(productId){
		return this.defaultItemArray[productId];
},


	*//**
	* AddBundle2ShopCartAjax This function is used to add a bundle to the shopping cart. This is for the ajax flow which will take a form as input and retrieves all the items catentry IDs and adds them to the form.
	*						 
	* @param {form} form The form which contains all the inputs for the bundle.
	*					 The form is expected to have the following values: 
	*						numberOfProducts The number of products in the bundle.
	*						catEntryId_<index> where index is between 1 and numberOfProduct.
	*						quantity_<index> where index is between 1 and numberOfProduct.
	**//*
	AddBundle2ShopCartAjax : function(form){
		
		var params = [];
		//var queryString = dojo.io.encodeForm(dojo.byId(form));

		params.storeId		= this.storeId;
		params.catalogId	= this.catalogId;
		params.langId		= this.langId;
		params.orderId		= ".";
		params.calculationUsage = "-1,-2,-5,-6,-7";
		params.inventoryValidation = "true";
			
		var productCount = form["numberOfProduct"].value;
		for(var i = 1; i <= productCount; i++){
			var catEntryId = form["catEntryId_" + i].value;
			if(this.selectedProducts[catEntryId])
				catEntryId = this.getCatalogEntryIdforProduct(this.selectedProducts[catEntryId]);
			var qty = form["quantity_" + i].value;
			if(qty == null || qty == "" || qty<=0){ MessageHelper.displayErrorMessage(MessageHelper.messages['QUANTITY_INPUT_ERROR']); return;}
			if(qty!=null && qty!='' && catEntryId!=null){
				this.updateParamObject(params,"catEntryId",catEntryId,false,-1);
				this.updateParamObject(params,"quantity",qty,false,-1);
				this.baseItemAddedToCart=true;
			}
			else{
				MessageHelper.displayErrorMessage(MessageHelper.messages['ERR_RESOLVING_SKU']);
				return;
			}
			var contractIdElements = document.getElementsByName('contractSelectForm_contractId_' + catEntryId);
			if (contractIdElements != null && contractIdElements != "undefined") {
				for (j=0; j<contractIdElements.length; j++) {
					if (contractIdElements[j].checked) {
						form["contractId_" + i].value = contractIdElements[j].value;
						break;
					}
				}
			}
			var contractId = form["contractId_" + i].value;
			if (contractId != null && contractId != '') {
				this.updateParamObject(params,"contractId",contractId,false,-1);
			}
		}
		//For Handling multiple clicks
		if(!submitRequest()){
			return;
		}   		
		cursor_wait();		
		wc.service.invoke("AjaxAddOrderItem", params);

	},


	*//**
	* AddBundle2ShopCart This function is used to add a bundle to the shopping cart. This is for the non ajax flow which  will take a form as input and submits the form.
	*
	* @param {form} form The form which contains all the inputs for the bundle.
	*					 The form is expected to have the following values:
	*						numberOfProducts The number of products in the bundle.
	*						catEntryId_<index> where index is between 1 and numberOfProduct.
	*						quantity_<index> where index is between 1 and numberOfProduct. 
	*
	**//*
	AddBundle2ShopCart : function(form){
		
		form.URL.value = "AjaxOrderItemDisplayView";
		var productCount = form["numberOfProduct"].value;
		for(var i = 1; i <= productCount; i++){
			var catEntryId = form["catEntryId_" + i].value;
			if(this.selectedProducts[catEntryId]){
				catEntryId = this.getCatalogEntryIdforProduct(this.selectedProducts[catEntryId]);
				if(catEntryId != null)
				form["catEntryId_" + i].value = catEntryId;
				else{
					MessageHelper.displayErrorMessage(MessageHelper.messages['ERR_RESOLVING_SKU']);
					return;
				}
			}
			var qty = form["quantity_" + i].value;
			if(qty == null || qty == "" || qty<=0){ MessageHelper.displayErrorMessage(MessageHelper.messages['QUANTITY_INPUT_ERROR']); return;}
			var contractIdElements = document.getElementsByName('contractSelectForm_contractId_' + catEntryId);
			if (contractIdElements != null && contractIdElements != "undefined") {
				for (j=0; j<contractIdElements.length; j++) {
					if (contractIdElements[j].checked) {
						form["contractId_" + i].value = contractIdElements[j].value;
						break;
					}
				}
			}
		}
		
		//For Handling multiple clicks
		if(!submitRequest()){
			return;
		}
		
		form.submit();
	},
	
	
	*//**
	* Add2ShopCart This function is used to add to a catalog entry to the shopping cart. This will resolve the catentryId using entitledItemId and adds the item to the cart.
	*			   This function will call AddItem2ShopCart after resolving the entitledItemId to a SKU.
	*
	* @param {String} entitledItemId A DIV containing a JSON object which holds information about a catalog entry. You can reference CachedProductOnlyDisplay.jsp to see how that div is constructed.
	* @param {form} form The form which contains all the inputs for the item. The catEntryId and productId values of the form you pass in
	*					 will be set to the catalog entry Id of the SKU resolved from the list of skus whos defining attributes match those in the {@link fastFinderJS.selectedAttributes} array.
	* @param {int} quantity quantity of the item.
	* @param {String} isPopup If the value is true, then this implies that the function was called from a quick info pop-up.				
	*
	**//*
	Add2ShopCart : function(entitledItemId,form,quantity,isPopup){
		var entitledItemJSON;

		if (dojo.byId(entitledItemId)!=null) {
			//the json object for entitled items are already in the HTML. 
			 entitledItemJSON = eval('('+ dojo.byId(entitledItemId).innerHTML +')');
		}else{
			//if dojo.byId(entitledItemId) is null, that means there's no <div> in the HTML that contains the JSON object. 
			//in this case, it must have been set in catalogentryThumbnailDisplay.js when the quick info
			entitledItemJSON = this.getEntitledItemJsonObject(); 
		}
		
		this.setEntitledItems(entitledItemJSON);
		var catalogEntryId = this.getCatalogEntryId();
		if(catalogEntryId!=null){
			if(this.merchandisingProductAssociationAddToCart){
				this.AddAssociation2ShopCart(catalogEntryId,quantity);
				return;
			}
			form.catEntryId.value = catalogEntryId;
			form.productId.value = catalogEntryId;
			this.AddItem2ShopCart(form,quantity);
			hidePopup('second_level_category_popup');
		} else if (isPopup == true){
			dojo.byId('second_level_category_popup').style.zIndex = '1';
			MessageHelper.formErrorHandleClient('addToCartLink', MessageHelper.messages['ERR_RESOLVING_SKU']);		
		} else{
			MessageHelper.displayErrorMessage(MessageHelper.messages['ERR_RESOLVING_SKU']);
		}

	},
	
	
	
	*//**
	* AddItem2ShopCart This function is used to add a SKU to the shopping cart.
	*
	* @param {form} form The form which contains all the inputs for the item.
    * 					The form must have the following values:
    *						quantity The quantity of the item that you want to add to the cart.
	* @param {int} quantity The quantity of the item to add to the shopping cart.
	*
	**//*
	AddItem2ShopCart : function(form,quantity){
		if(!isPositiveInteger(quantity)){
			MessageHelper.displayErrorMessage(MessageHelper.messages['QUANTITY_INPUT_ERROR']);
			return;
		}
		
		form.quantity.value = quantity;
		
		var contractIdElements = document.getElementsByName('contractSelectForm_contractId');
		if (contractIdElements != null && contractIdElements != "undefined") {
			for (i=0; i<contractIdElements.length; i++) {
				if (contractIdElements[i].checked) {
					form.contractId.value = contractIdElements[i].value;
					break;
				}
			}
		}
		//For Handling multiple clicks
		if(!submitRequest()){
			return;
		}
		
		form.submit();
	},


	*//**
	* Add2ShopCartAjax This function is used to add a catalog entry to the shopping cart using an AJAX call. This will resolve the catentryId using entitledItemId and adds the item to the cart.
	*				This function will resolve the SKU based on the entitledItemId passed in and call {@link fastFinderJS.AddItem2ShopCartAjax}.
	* @param {String} entitledItemId A DIV containing a JSON object which holds information about a catalog entry. You can reference CachedProductOnlyDisplay.jsp to see how that div is constructed.
	* @param {int} quantity The quantity of the item to add to the cart.
	* @param {String} isPopup If the value is true, then this implies that the function was called from a quick info pop-up. 	
	* @param {Object} customParams - Any additional parameters that needs to be passed during service invocation.
	*
	**//*
	Add2ShopCartAjax : function(entitledItemId,quantity,isPopup,customParams)
	{	
		var entitledItemJSON;

		if (dojo.byId(entitledItemId)!=null) {
			//the json object for entitled items are already in the HTML. 
			 entitledItemJSON = eval('('+ dojo.byId(entitledItemId).innerHTML +')');
		}else{
			//if dojo.byId(entitledItemId) is null, that means there's no <div> in the HTML that contains the JSON object. 
			//in this case, it must have been set in catalogentryThumbnailDisplay.js when the quick info
			entitledItemJSON = this.getEntitledItemJsonObject(); 
		}
		
		this.setEntitledItems(entitledItemJSON);
		var catalogEntryId = this.getCatalogEntryId();
		if(catalogEntryId!=null){
			this.AddItem2ShopCartAjax(catalogEntryId , quantity,customParams);
			this.baseItemAddedToCart=true;
			hidePopup('second_level_category_popup');
		}
		else if (isPopup == true){
			dojo.byId('second_level_category_popup').style.zIndex = '1';
			MessageHelper.formErrorHandleClient('addToCartLinkAjax', MessageHelper.messages['ERR_RESOLVING_SKU']);			
		} else{
			MessageHelper.displayErrorMessage(MessageHelper.messages['ERR_RESOLVING_SKU']);
			this.baseItemAddedToCart=false;
		}
	},
    
	*//**
	 * sets the entitledItemJsonObject
	 * @param (object) jsonObject the entitled item JSON objects
	 *//*
    setEntitledItemJsonObject: function(jsonObject) {
        this.entitledItemJsonObject = jsonObject;
    },
    
    *//**
     * retrieves the entitledItemJsonObject
     *//*
    getEntitledItemJsonObject: function () {
    	return this.entitledItemJsonObject;
    },

	*//**
	* ReplaceItemAjax This function is used to replace an item in the shopping cart when the AJAX Checkout flow is enabled. This will be called from the shopping cart and checkout pages.
	*
	* @param {String} entitledItemId A DIV containing a JSON object which holds information about a catalog entry. You can reference CachedProductOnlyDisplay.jsp to see how that div is constructed.
	* @param {int} quantity The quantity of the item to add to the shopping cart.
	*
	**//*
	ReplaceItemAjax : function(entitledItemId,quantity){
	
		var entitledItemJSON;

		if (dojo.byId(entitledItemId)!=null) {
			//the json object for entitled items are already in the HTML. 
			 entitledItemJSON = eval('('+ dojo.byId(entitledItemId).innerHTML +')');
		}else{
			//if dojo.byId(entitledItemId) is null, that means there's no <div> in the HTML that contains the JSON object. 
			//in this case, it must have been set in catalogentryThumbnailDisplay.js when the quick info
			entitledItemJSON = this.getEntitledItemJsonObject(); 
		}
		this.setEntitledItems(entitledItemJSON);
		var catalogEntryId = this.getCatalogEntryId();
		var removeOrderItemId = "";
		//if(entitledItemJSON[0] != null){
		//	removeOrderItemId = entitledItemJSON[0].orderItemId_remove;
		//}
		var removeOrderItemId = replaceOrderItemId;
		var typeId = document.getElementById("shipmentTypeId");
		var addressId = "";
		var shipModeId = "";
		if(typeId != null && typeId != ""){
			if(typeId.value == "2"){
				//Multiple shipment..each orderItem will have its own addressId and shipModeId..
				addressId = document.getElementById("MS_ShipmentAddress_"+removeOrderItemId).value;
				shipModeId = document.getElementById("MS_ShippingMode_"+removeOrderItemId).value;
			}
			else {
				//Single Shipment..get the common addressId and shipModeId..
				addressId = document.getElementById("addressId_all").value;;
				shipModeId = document.getElementById("shipModeId_all").value;
			}
		}
		if(catalogEntryId!=null){
			if(removeOrderItemId == ""){
				//Just add new catentryId to shop cart in ajax way, since this is AjaxCheckout page
				//This code will never be executed, since we dont have Add To Cart link..
				var params = [];
				params.storeId		= this.storeId;
				params.catalogId	= this.catalogId;
				params.langId			= this.langId;
				params.orderId		= ".";
				params.catEntryId	= catalogEntryId;
				params.quantity		= quantity;
				params.addressId = addressId;
				params.shipModeId = shipModeId;
				wc.service.invoke("AjaxAddOrderItem", params);
				
			}
			else{
				//Else remove existing catEntryId and then add new one...
				this.ReplaceItemAjaxHelper(catalogEntryId,quantity,removeOrderItemId,addressId,shipModeId);
			}
		}
		else{
				MessageHelper.displayErrorMessage(MessageHelper.messages['ERR_RESOLVING_SKU']);
		}
	},

	*//**
	* ReplaceItemNonAjax This function is used to replace an item in the shopping cart when the Non Ajax checkout flow is enabled. This will be called from shopcart and checkout pages.
	* 
	* @param {String} entitledItemId A DIV containing a JSON object which holds information about a catalog entry. You can reference CachedProductOnlyDisplay.jsp to see how that div is constructed.
	* @param {int} quantity The quantity of the item to replace in the shopping cart.
	* @param {form} form The form which contains all the inputs for the item.
	*
	**//* 
	ReplaceItemNonAjax : function(entitledItemId,quantity,form){
	
		var entitledItemJSON;

		if (dojo.byId(entitledItemId)!=null) {
			//the json object for entitled items are already in the HTML. 
			 entitledItemJSON = eval('('+ dojo.byId(entitledItemId).innerHTML +')');
		}else{
			//if dojo.byId(entitledItemId) is null, that means there's no <div> in the HTML that contains the JSON object. 
			//in this case, it must have been set in catalogentryThumbnailDisplay.js when the quick info
			entitledItemJSON = this.getEntitledItemJsonObject(); 
		}
		this.setEntitledItems(entitledItemJSON);
		var catalogEntryId = this.getCatalogEntryId();
		var removeOrderItemId = "";
		//if(entitledItemJSON[0] != null){
		//	removeOrderItemId = entitledItemJSON[0].orderItemId_remove;
		//}
		var removeOrderItemId = replaceOrderItemId;
		if(catalogEntryId!=null){
			if(removeOrderItemId == ""){
				//Prepare form to just add this item.. This code will never be executed...
				//Needed only when we plan to show add to cart link also in the quick info..
				//form.action = "orderChangeServiceItemAdd";
				//form.submit();
			}
			else{
				//Else remove existing catEntryId and then add new one...
				form.orderItemId.value = removeOrderItemId;
				var addressId, shipModeId;
				if(quantity == 0){
					console.debug("An invalid quantity was selected");

				}
				if(form.shipmentTypeId != null && form.shipmenTypeId != ""){
					if(form.shipmentTypeId.value == "2"){
						//Multiple shipment..each orderItem will have its own addressId and shipModeId..
						addressId = document.getElementById("MS_ShipmentAddress_"+removeOrderItemId).value;;
						shipModeId = document.getElementById("MS_ShippingMode_"+removeOrderItemId).value;;
					}
					else {
						//Single Shipment..get the common addressId and shipModeId..
						addressId = document.getElementById("addressId_all").value;;
						shipModeId = document.getElementById("shipModeId_all").value;
					}
					form.URL.value = "OrderChangeServiceItemAdd?calculationUsage=-1,-2,-3,-4,-5,-6,-7&catEntryId="+catalogEntryId+"&quantity="+quantity+"&addressId="+addressId+"&shipModeId="+shipModeId+"&URL=OrderChangeServiceShipInfoUpdate?URL="+form.URL.value;
			    }
				else{
					form.URL.value = "OrderChangeServiceItemAdd?calculationUsage=-1,-2,-3,-4,-5,-6,-7&catEntryId="+catalogEntryId+"&quantity="+quantity+"&URL="+form.URL.value;
				}

				//For Handling multiple clicks
				if(!submitRequest()){
					return;
				}
				
				form.submit();
			}
		}
		else{
			MessageHelper.displayErrorMessage(MessageHelper.messages['ERR_RESOLVING_SKU']);
		}
	},

	*//**
	* AddItem2ShopCartAjax This function is used to add a single or multiple items to the shopping cart using an ajax call.
							If an array is passed for catEntryIdentifier and quantity parramters, then multiple items can be added.	In this case, catEntryIdentifier[i] corresponds to quantity[i]
							Else, catEntryIdentifier  and quantity parramters represent a single catalog entry.
	*
	* @param {Array|String} catEntryIdentifier An array of catalog entry identifiers or a single catalog entry ID of the item to add to the cart.
	* @param {Array|int} quantity An array of quantities corresponding to the catEntryIdentifier array or a single quantity of the item to add to the cart.
	* @param {Object} customParams - Any additional parameters that needs to be passed during service invocation.
	*
	**//*
	AddItem2ShopCartAjax : function(catEntryIdentifier, quantity, customParams)
	{
		var params = [];
		params.storeId		= this.storeId;
		params.catalogId	= this.catalogId;
		params.langId		= this.langId;
		params.orderId		= ".";
		params.calculationUsage = "-1,-2,-5,-6,-7";
		params.inventoryValidation = "true";
		var ajaxShopCartService = "AjaxAddOrderItem";
		var nonAjaxShopCartService = "AjaxAddOrderItem_shopCart";
		
		if(dojo.isArray(catEntryIdentifier) && dojo.isArray(quantity)){
			for(var i=0; i<catEntryIdentifier.length; i++){
				if(!isPositiveInteger(quantity[i])){
					MessageHelper.displayErrorMessage(MessageHelper.messages['QUANTITY_INPUT_ERROR']);
					return;
				}
				params["catEntryId_" + (i+1)] = catEntryIdentifier[i];
				params["quantity_" + (i+1)]	= quantity[i];
			}
		}
		else{
			if(!isPositiveInteger(quantity)){
				MessageHelper.displayErrorMessage(MessageHelper.messages['QUANTITY_INPUT_ERROR']);
				return;
			}
			params.catEntryId	= catEntryIdentifier;
			params.quantity		= quantity;
		}		

		//Pass any other customParams set by other add on features
		if(customParams != null && customParams != 'undefined'){
			for(i in customParams){
				params[i] = customParams[i];
			}
			if(customParams['catalogEntryType'] == 'dynamicKit' ){
				ajaxShopCartService = "AjaxAddPreConfigurationToCart";
				nonAjaxShopCartService = "AjaxAddPreConfigurationToCart_shopCart";
			}
		}

		var contractIdElements = document.getElementsByName('contractSelectForm_contractId');
		if (contractIdElements != null && contractIdElements != "undefined") {
			for (i=0; i<contractIdElements.length; i++) {
				if (contractIdElements[i].checked) {
					params.contractId = contractIdElements[i].value;
					break;
				}
			}
		}
		
		//For Handling multiple clicks
		if(!submitRequest()){
			return;
		}   
		cursor_wait();		
		if(this.ajaxShopCart){
			wc.service.invoke(ajaxShopCartService, params);
			this.baseItemAddedToCart=true;
		}else{
			wc.service.invoke(nonAjaxShopCartService, params);
			this.baseItemAddedToCart=true;
		}
		if(document.getElementById("headerShopCartLink")&&document.getElementById("headerShopCartLink").style.display != "none")
		{
			document.getElementById("headerShopCart").focus();
		}
		else
		{
			if(document.getElementById("headerShopCart1")){
				document.getElementById("headerShopCart1").focus();
			}
		}
	},
	
	*//**
	* ConfigureDynamicKit This function is used to call the configurator page for a dynamic kit.
	* @param {String} catEntryIdentifier A catalog entry ID of the item to add to the cart.
	* @param {int} quantity A quantity of the item to add to the cart.
	* @param {Object} customParams - Any additional parameters that needs to be passed to the configurator page.
	*
	**//*
	ConfigureDynamicKit : function(catEntryIdentifier, quantity, customParams)
	{
		var params = [];
		params.storeId		= this.storeId;
		params.catalogId	= this.catalogId;
		params.langId		= this.langId;
		params.catEntryId	= catEntryIdentifier;
		params.quantity		= quantity;
		
		if(!isPositiveInteger(quantity)){
			MessageHelper.displayErrorMessage(MessageHelper.messages['QUANTITY_INPUT_ERROR']);
			return;
		}

		var contractIdElements = document.getElementsByName('contractSelectForm_contractId');
		if (contractIdElements != null && contractIdElements != "undefined") {
			for (i=0; i<contractIdElements.length; i++) {
				if (contractIdElements[i].checked) {
					params.contractId = contractIdElements[i].value;
					break;
				}
			}
		}
		
		//Pass any other customParams set by other add on features
		if(customParams != null && customParams != 'undefined'){
			for(i in customParams){
				params[i] = customParams[i];
			}
		}

		//For Handling multiple clicks
		if(!submitRequest()){
			return;
		}   
		cursor_wait();
		
		var configureURL = "ConfigureView";
		var i =0;
		for(param in params){
			configureURL += ((i++ == 0)? "?" : "&") + param + "=" + params[param];
		}
		document.location.href = getAbsoluteURL() + configureURL;
	},
	
	*//**
	* ReplaceItemAjaxHelper This function is used to replace an item in the cart. This will be called from the {@link fastFinderJS.ReplaceItemAjax} method.
	*
	* @param {String} catalogEntryId The catalog entry of the item to replace to the cart.
	* @param {int} qty The quantity of the item to add.
	* @param {String} removeOrderItemId The order item ID of the catalog entry to remove from the cart.
	* @param {String} addressId The address ID of the order item.
	* @param {String} shipModeId The shipModeId of the order item.
	*
	**//*
	ReplaceItemAjaxHelper : function(catalogEntryId,qty,removeOrderItemId,addressId,shipModeId){
		
		var params = [];
		params.storeId = this.storeId;
		params.catalogId = this.catalogId;
		params.langId = this.langId;
		params.orderItemId	= removeOrderItemId;
		params.orderId = (this.orderId != null && this.orderId != 'undefined' && this.orderId != '')?this.orderId:".";
		if(CheckoutHelperJS.shoppingCartPage){	
			params.calculationUsage = "-1,-2,-5,-6,-7";
		}else{
			params.calculationUsage = "-1,-2,-3,-4,-5,-6,-7";
		}

		var params2 = [];
		params2.storeId = this.storeId;
		params2.catalogId = this.catalogId;
		params2.langId = this.langId;
		params2.catEntryId	= catalogEntryId;
		params2.quantity = qty;
		params2.orderId = (this.orderId != null && this.orderId != 'undefined' && this.orderId != '')?this.orderId:".";
		if(CheckoutHelperJS.shoppingCartPage){	
			params2.calculationUsage = "-1,-2,-5,-6,-7";
		}else{
			params2.calculationUsage = "-1,-2,-3,-4,-5,-6,-7";
		}

		var params3 = [];
		params3.storeId = this.storeId;
		params3.catalogId = this.catalogId;
		params3.langId = this.langId;
		params3.orderId = (this.orderId != null && this.orderId != 'undefined' && this.orderId != '')?this.orderId:".";
		if(CheckoutHelperJS.shoppingCartPage){	
			params3.calculationUsage = "-1,-2,-5,-6,-7";
		}else{
			params3.calculationUsage = "-1,-2,-3,-4,-5,-6,-7";
		}
		params3.allocate="***";
		params3.backorder="***";
		params3.remerge="***";
		params3.check="*n";
		
		var shipInfoUpdateNeeded = false;
		if(addressId != null && addressId != "" && shipModeId != null && shipModeId != ""){
			params3.addressId = addressId;
			params3.shipModeId = shipModeId;
			shipInfoUpdateNeeded = true;
		}

		//Delcare service for deleting item...
		wc.service.declare({
			id: "AjaxReplaceItem",
			actionId: "AjaxReplaceItem",
			url: "AjaxOrderChangeServiceItemDelete",
			formId: ""

			,successHandler: function(serviceResponse) {
				//Now add the new item to cart..
				if(!shipInfoUpdateNeeded){
					//We dont plan to update addressId and shipMOdeId..so call AjaxAddOrderItem..
					wc.service.invoke("AjaxAddOrderItem", params2);
				}
				else{
					//We need to update the adderessId and shipModeId..so call our temp service to add..
					wc.service.invoke("AjaxAddOrderItemTemp", params2);
				}
			}

			,failureHandler: function(serviceResponse) {
				if (serviceResponse.errorMessage) {
							 MessageHelper.displayErrorMessage(serviceResponse.errorMessage);
					  } else {
							 if (serviceResponse.errorMessageKey) {
									MessageHelper.displayErrorMessage(serviceResponse.errorMessageKey);
							 }
					  }
					  cursor_clear();
			}

		});

		//Delcare service for adding item..
		wc.service.declare({
			id: "AjaxAddOrderItemTemp",
			actionId: "AjaxAddOrderItemTemp",
			url: "AjaxOrderChangeServiceItemAdd",
			formId: ""

			,successHandler: function(serviceResponse) {
				//Now item is added.. call update to set addressId and shipModeId...
				wc.service.invoke("OrderItemAddressShipMethodUpdate", params3);
			}

			,failureHandler: function(serviceResponse) {
				MessageHelper.displayErrorMessage(serviceResponse.errorMessageKey);
			}
		});

		//For Handling multiple clicks
		if(!submitRequest()){
			return;
		}   
		cursor_wait();
		wc.service.invoke("AjaxReplaceItem",params);
	},
		
	*//**
	* AddBundle2WishList This function is used to add a bundle to the wish list and it can be called by the product/bundle/package details pages.
	*
	* @param {form} form The form which contains all the inputs for the bundle.
	*
	**//*	
	AddBundle2WishList : function(form){
		if (!isAuthenticated) { 
			setWarningMessageCookie('WISHLIST_GUEST_ADDITEM');
		}
		var productCount = form["numberOfProduct"].value; 
		for(var i = 1; i <= productCount; i++){
			var catEntryId = form["catEntryId_" + i].value;
			if(this.selectedProducts[catEntryId]){
				catEntryId = this.getCatalogEntryIdforProduct(this.selectedProducts[catEntryId]);
				if(catEntryId != null)
				form["catEntryId_" + i].value = catEntryId;
				else{
					MessageHelper.displayErrorMessage(MessageHelper.messages['ERR_RESOLVING_SKU']);
					return;
				}
			}
		}
			form.action="InterestItemAdd";
			form.page.value="customerlinkwishlist";
		if (this.ajaxMyAccount){
			if(this.userType=='G'){
				form.URL.value='InterestItemDisplay';
			}else {
				form.URL.value='AjaxLogonForm';
			}
		}else{
			if(this.userType=='G'){
				form.URL.value='InterestItemDisplay';
			}else {
				form.URL.value='NonAjaxAccountWishListDisplayView';
			}
		}
		//For Handling multiple clicks
		if(!submitRequest()){
			return;
		}
		
		form.submit();
	},
	
	*//**
	* AddBundle2WishListAjax This fuction is used to add a bundle to the wish list using the ajax flow and it is called by the product/bundle/package details pages.
	*
	* @param {form} form The form which contains all the inputs for the bundle.
	*
	**//*
	AddBundle2WishListAjax : function(form){
		if (!isAuthenticated) { 
			setWarningMessageCookie('WISHLIST_GUEST_ADDITEM');
		}
		var params = [];
		//var queryString = dojo.io.encodeForm(dojo.byId(form));

		params.storeId		= this.storeId;
		params.catalogId	= this.catalogId;
		params.langId		= this.langId;
		params.updateable	= 0;
		params.orderId		= ".";
			
		var catEntryArray = [];
		catEntryArray = form.catEntryIDS.value.toString().split(",");
		
		for(var i = 0; i < catEntryArray.length; i++){
			var qty = document.getElementById("quantity_" + catEntryArray[i]).value;
			var catEntryId = catEntryArray[i];
			if(this.selectedProducts[catEntryArray[i]])
				catEntryId = this.getCatalogEntryIdforProduct(this.selectedProducts[catEntryArray[i]]);
			if(qty==0 || qty == null) qty = 1;
			if(qty!=null && qty!='' && catEntryId!=null){
				this.updateParamObject(params,"catEntryId",catEntryId,false,-1);
				this.updateParamObject(params,"quantity",qty,false,-1);
			}
			else{
				MessageHelper.displayErrorMessage(MessageHelper.messages['ERR_RESOLVING_SKU']);
				return;
			}
		}
		//For Handling multiple clicks
		if(!submitRequest()){
			return;
		}   		
		cursor_wait();		
		wc.service.invoke("AjaxInterestItemAdd", params);

	},
	
	*//**
	* Add2WishListAjaxByID. This function is used to add a catalog entry to the wish list using ajax by passing in a catalog entry ID.
	*
	* @param {int} catalogEntryId The catalog entry ID of the catalog entry.
	*
	**//*
	Add2WishListAjaxByID:function(catalogEntryId)
	{
		if(catalogEntryId!=null){
			if (!isAuthenticated) { 
				setWarningMessageCookie('WISHLIST_GUEST_ADDITEM');
			}
			var params = [];
			params.storeId		= this.storeId;
			params.catalogId	= this.catalogId;
			params.langId			= this.langId;
			params.catEntryId	= catalogEntryId;
			params.updateable	= 0;
			params.URL = "SuccessfulAJAXRequest";
			if(document.getElementById("controllerURLWishlist")!=null && document.getElementById("controllerURLWishlist")!='undefined')
					CommonControllersDeclarationJS.setControllerURL("WishlistDisplay_Controller",document.getElementById("controllerURLWishlist").value);

			//For Handling multiple clicks
			if(!submitRequest()){
				return;
			}   
			cursor_wait();			
			if(this.ajaxShopCart)
				wc.service.invoke("AjaxInterestItemAdd", params);
			else
				wc.service.invoke("AjaxInterestItemAdd_shopCart", params);
		}
		else MessageHelper.displayErrorMessage(MessageHelper.messages['ERR_RESOLVING_SKU']);
	},
	
	*//**
	* Add2WishListAjax This function is used to add an item to the wishlist using ajax by passing in the id of an HTML element containing a JSON object representing a catalog entry.
	*				   This fuction is called by product/bundle/package detail pages.
	* 
	* @param {HTMLDivElement} entitledItemId A DIV containing a JSON object which holds information about a catalog entry. You can reference CachedProductOnlyDisplay.jsp to see how that div is constructed.
	*
	**//*
	Add2WishListAjax:function(entitledItemId)
	{
		if (!isAuthenticated) { 
			setWarningMessageCookie('WISHLIST_GUEST_ADDITEM');
		}
		var entitledItemJSON;

		if (dojo.byId(entitledItemId)!=null) {
			//the json object for entitled items are already in the HTML. 
			 entitledItemJSON = eval('('+ dojo.byId(entitledItemId).innerHTML +')');
		}else{
			//if dojo.byId(entitledItemId) is null, that means there's no <div> in the HTML that contains the JSON object. 
			//in this case, it must have been set in catalogentryThumbnailDisplay.js when the quick info
			entitledItemJSON = this.getEntitledItemJsonObject(); 
		}
		this.setEntitledItems(entitledItemJSON);
		
		
		
		var catalogEntryId = this.getCatalogEntryId();
		
		this.Add2WishListAjaxByID(catalogEntryId);
		
	},
	
	*//**
	* AddItem2WishListAjax. This function is used to add an item to the wishlist using AJAX by passing in its catentryId. 
	* 						This function can be called by item detail page.
	*
	* @param {String} itemId The catalog entry ID of the catalog entry to add to the wish list.
	*
	**//*
	AddItem2WishListAjax:function(itemId)
	{
		if (!isAuthenticated) { 
			setWarningMessageCookie('WISHLIST_GUEST_ADDITEM');
		}
		var params = [];
		params.storeId		= this.storeId;
		params.catalogId	= this.catalogId;
		params.langId			= this.langId;
		params.catEntryId	= itemId;
		params.updateable	= 0;
		params.URL = "SuccessfulAJAXRequest";
		if(document.getElementById("controllerURLWishlist")!=null && document.getElementById("controllerURLWishlist")!='undefined')
					CommonControllersDeclarationJS.setControllerURL("WishlistDisplay_Controller",document.getElementById("controllerURLWishlist").value);

		//For Handling multiple clicks
		if(!submitRequest()){
			return;
		}   		
		cursor_wait();			
		if(this.ajaxShopCart)
			wc.service.invoke("AjaxInterestItemAdd", params);
		else
			wc.service.invoke("AjaxInterestItemAdd_shopCart", params);
	},

	*//**
	* Add2WishList This function is used to add a catalog entry to the wish list using the non ajax flow by passing in the ID of an HTML element containing a JSON which represents a catalog entry 
	*			   This fuction is called by the product/bundle/package detail pages.
	*
	* @param {String} entitledItemId A DIV containing a JSON object which holds information about a catalog entry. You can reference CachedProductOnlyDisplay.jsp to see how that div is constructed.
	* @param {form} form form to submit the request.
	*
	**//*
	Add2WishList:function(entitledItemId,form)
	{
		if (!isAuthenticated) { 
			setWarningMessageCookie('WISHLIST_GUEST_ADDITEM');
		}
		var entitledItemJSON;

		if (dojo.byId(entitledItemId)!=null) {
			//the json object for entitled items are already in the HTML. 
			 entitledItemJSON = eval('('+ dojo.byId(entitledItemId).innerHTML +')');
		}else{
			//if dojo.byId(entitledItemId) is null, that means there's no <div> in the HTML that contains the JSON object. 
			//in this case, it must have been set in catalogentryThumbnailDisplay.js when the quick info
			entitledItemJSON = this.getEntitledItemJsonObject(); 
		}
		this.setEntitledItems(entitledItemJSON);
		var catalogEntryId = this.getCatalogEntryId();
		this.Add2WishListByID(catalogEntryId,form);
	},


	*//**
	* Add2WishListByID Add a catalog entry to the wish list using the non-AJAX flow. This fuction is called by the product/bundle/package detail pages.
	*
	* @param {String} catalogEntryId The catalog entry ID of the catalog entry to be added.
	* @param {form} form  form to submit the request.
	*
	**//*
	Add2WishListByID:function(catalogEntryId,form)
	{
		if (!isAuthenticated) { 
			setWarningMessageCookie('WISHLIST_GUEST_ADDITEM');
		}
		if(catalogEntryId!=null){
			form.productId.value = catalogEntryId;
			form.catEntryId.value = catalogEntryId;
			form.action="InterestItemAdd";
			form.page.value="customerlinkwishlist";
		if (this.ajaxMyAccount){
			if(this.userType=='G'){
				form.URL.value='InterestItemDisplay';
			}else {
				form.URL.value='AjaxLogonForm';
			}
		}else{
			if(this.userType=='G'){
				form.URL.value='InterestItemDisplay';
			}else {
				form.URL.value='NonAjaxAccountWishListDisplayView';
			}
		}
			form.quantity.value = "1";
			
			//For Handling multiple clicks
			if(!submitRequest()){
				return;
			}
			
			form.submit();
		}
		else MessageHelper.displayErrorMessage(MessageHelper.messages['ERR_RESOLVING_SKU']);
	},
	
	
	*//** 
	* AddItem2WishList Add a SKU to the wish list using the non-AJAX flow. This function is called by the item detail page.
	*
	* @param {form} form The form to submit the request.
	*
	**//*
	AddItem2WishList:function(form)
	{
		if (!isAuthenticated) { 
			setWarningMessageCookie('WISHLIST_GUEST_ADDITEM');
		}
		form.action="InterestItemAdd"
		form.quantity.value = "1";
		form.page.value="customerlinkwishlist";
		if (this.ajaxMyAccount){
			if(this.userType=='G'){
				form.URL.value='InterestItemDisplay';
			}else {
				form.URL.value='AjaxLogonForm';
			}
		}else{
			if(this.userType=='G'){
				form.URL.value='InterestItemDisplay';
			}else {
				form.URL.value='NonAjaxAccountWishListDisplayView';
			}
		}
		//For Handling multiple clicks
		if(!submitRequest()){
			return;
		}
			
		form.submit();
	},
	
	*//**
	* loadContentURL Sets the URL of the page to load into CategoryDisplay_Controller which in turn is used to display categories
	* 				 on the CategoryDisplay.jsp and DepartmentDisplay.jsp. The HistoryTracker is also updated.
	*
	* @param {String} contentURL The URL to load contents from.
	*
	**//*
	loadContentURL:function(contentURL){
		
		//For Handling multiple clicks
		if(!submitRequest()){
			return;
		}   		
		cursor_wait();
		CommonControllersDeclarationJS.setControllerURL('CategoryDisplay_Controller',contentURL);		
		wc.render.updateContext("CategoryDisplay_Context");
	},
	
	
	*//**
	* loadSubCategoryContentURL Sets the URL of the page to load into SubCategoryDisplay_Controller which in turn is used to display sub categories 
	* 							on the CategoryDisplay.jsp and DepartmentDisplay.jsp. The HistoryTracker is also updated.
	* 
	* @param {String} contentURL The URL to display for a sub category.
	*
	**//*
	loadSubCategoryContentURL:function(contentURL){
		
		MessageHelper.hideAndClearMessage();

		//For Handling multiple clicks
		if(!submitRequest()){
			return;
		}   		
		cursor_wait();
		CommonControllersDeclarationJS.setControllerURL('SubCategoryDisplay_Controller',contentURL);	
		wc.render.updateContext("SubCategoryDisplay_Context");
	},
	
	*//**
	* goBack Called when the back button is clicked in the browser. 
	*		 Uses the changeUrl set by the HistoryTracker and calls the loadContentURL method so that the state of the page get 
	* 		 loaded from a previous state in the page history.
	**//*
	goBack:function(){
		
		categoryDisplayJS.loadContentURL(this.changeUrl);
		categoryDisplayJS.isHistory=true;

	},


	*//**
	* goForward Called when the forward button is clicked in the browser. 
	*			Uses the changeUrl set by HistoryTracker and calls the loadContentURL method so that the state of the page gets
	*           loaded from the next available point in the page history.
	**//*
	goForward:function(){
		
		categoryDisplayJS.loadContentURL(this.changeUrl);
		isHistory=true;
	},


	*//**
	* HistoryTracker Used to track the history for the browser back and forward buttons.
	*
	* @param {String} elementId HistoryTracker id.
	* @param {String} changeUrl The change url of the current state.
	*
	**//*
	HistoryTracker:function(elementId, changeUrl){
	
		this.elementId = elementId; 
		this.changeUrl =  changeUrl;

	},
	
	*//**
	* processBookmarkURL Processes the bookmark using the bookmarkId which is stored in location.hash.
	**//*
	processBookmarkURL : function(){
		
			var bookmarkId = location.hash;	
			if(bookmarkId){					        
				bookmarkId = bookmarkId.substring(1, bookmarkId.length);
			}   
			if(bookmarkId){
				var indexOfIdentifier = bookmarkId.indexOf("identifier", 0);
				if ( indexOfIdentifier >= 0) {
					var realUrl = bookmarkId.substring(0, indexOfIdentifier - 1);
				}
			}

			if(bookmarkId == null || bookmarkId == ""){

			}
	},
	
	
	*//**
	* initializeMerchandisingAssociation Since the merchandising associations are only displayed one at a time with a scrolling widget this method
	*									 will initialize that widget with a specified starting index represented by thumbnailIndex so that the correct 
	*									 merchandising association is displayed first.
	*									 This function is called on MerchandisingAssociationsDisplay.jsp.s
	* 
	* @param {String} thumbnailIndex The index of the association that needs to be displayed.
	*
	**//*
	initializeMerchandisingAssociation:function(thumbnailIndex){
	
	var associationDisplay = document.getElementById("marchandisingAssociationDisplay");
	var totalPriceMsg = document.getElementById("totalPriceMsg").value;
	var baseCatEntryJSON = eval('('+ dojo.byId("baseCatEntryDetails").innerHTML +')');
	this.baseCatalogEntryDetails = baseCatEntryJSON;
	var basePrice=this.baseCatalogEntryDetails[0].baseCatEntry_Price;
	this.totalAssociationCount= this.baseCatalogEntryDetails[0].totalAssociations;
	var identifierJSON = "associatedCatEntries_"+thumbnailIndex;
	var associationEntryJSON = eval('('+ dojo.byId(identifierJSON).innerHTML +')');
	this.merchandisingAssociationItems = associationEntryJSON;
	var totalPrice = parseFloat(basePrice)+ parseFloat(this.merchandisingAssociationItems[0].catEntry_Price);
	var dragType = "";
		
	if(this.merchandisingAssociationItems[0].catEntry_Type =='ProductBean'){
		dragType = "product";
	}else if (this.merchandisingAssociationItems[0].catEntry_Type =='ItemBean'){
		dragType = "item";
	}else if (this.merchandisingAssociationItems[0].catEntry_Type =='PackageBean'){
		dragType = "package";
	}else if (this.merchandisingAssociationItems[0].catEntry_Type =='BundleBean'){
		dragType = "bundle";
	}
//Creates the inner HTML of the associated item determined by the thumbnailIndex which needs to be displayed in the page.
var widgetHTML = "";
if(document.getElementById('addToCartLink')){
var url = "AjaxOrderItemDisplayView?storeId="+this.storeId+"&catalogId="+this.catalogId+"&langId="+this.langId;
						widgetHTML = widgetHTML
						+"<form name='OrderItemAddForm_"+this.merchandisingAssociationItems[0].catEntry_Identifier+"' action='OrderChangeServiceItemAdd' method='post' id='OrderItemAddForm_"+this.merchandisingAssociationItems[0].catEntry_Identifier+"'>\n"
						+"<input type='hidden' name='storeId' value='"+this.storeId+"' id='OrderItemAddForm_storeId_"+this.merchandisingAssociationItems[0].catEntry_Identifier+"'/>\n"
						+"<input type='hidden' name='orderId' value='.' id='OrderItemAddForm_orderId_"+this.merchandisingAssociationItems[0].catEntry_Identifier+"'/>\n"
						+"<input type='hidden' name='catalogId' value='"+this.catalogId+"' id='OrderItemAddForm_orderId_"+this.merchandisingAssociationItems[0].catEntry_Identifier+"'/>\n"
						+"<input type='hidden' name='URL' value='"+ url + "' id='OrderItemAddForm_url_"+this.merchandisingAssociationItems[0].catEntry_Identifier+"'/>\n"
						+"<input type='hidden' name='errorViewName' value='InvalidInputErrorView' id='OrderItemAddForm_errorViewName_"+this.merchandisingAssociationItems[0].catEntry_Identifier+"'/>\n"
						+"<input type='hidden' name='catEntryId' value='"+this.merchandisingAssociationItems[0].catEntry_Identifier+"' id='OrderItemAddForm_catEntryId_"+this.merchandisingAssociationItems[0].catEntry_Identifier+"'/>\n"
						+"<input type='hidden' name='productId' value='"+this.merchandisingAssociationItems[0].catEntry_Identifier+"' id='OrderItemAddForm_productId_"+this.merchandisingAssociationItems[0].catEntry_Identifier+"'/>\n"
						+"<input type='hidden' value='1' name='quantity' id='OrderItemAddForm_quantity_"+this.merchandisingAssociationItems[0].catEntry_Identifier+"'/>\n"
						+"<input type='hidden' value='' name='page' id='OrderItemAddForm_page_"+this.merchandisingAssociationItems[0].catEntry_Identifier+"'/>\n"
						+"<input type='hidden' value='-1,-2,-3,-4,-5,-6,-7' name='calculationUsage' id='OrderItemAddForm_calcUsage_"+this.merchandisingAssociationItems[0].catEntry_Identifier+"'/>\n"
						+"<input type='hidden' value='0' name='updateable' id='OrderItemAddForm_updateable_"+this.merchandisingAssociationItems[0].catEntry_Identifier+"'/>\n"
						+"<input type='hidden' value='' name='giftListId' id='OrderItemAddForm_giftListId_"+this.merchandisingAssociationItems[0].catEntry_Identifier+"'/>\n"
						+"</form>\n";
						}
widgetHTML = widgetHTML					
			+"<div class='scroller' id='WC_CategoryDisplayJS_div_1'>";
			if(this.totalAssociationCount > 1){
				if(this.associationThumbnailIndex < this.totalAssociationCount){
					widgetHTML = widgetHTML
					+"		<a href='Javascript:categoryDisplayJS.showNextAssociation()'  id='WC_ProductAssociation_UpArrow_Link_1'>";
				}
				widgetHTML = widgetHTML
				+"		<img src='"+this.baseCatalogEntryDetails[0].storeImage_Path+"i_up_arrow.png' alt='"+this.displayNextAssociation+"'/></a>";
			}
			widgetHTML = widgetHTML +" <br />"
			+"<div id='baseContent_"+this.merchandisingAssociationItems[0].catEntry_Identifier+"'";
			if(this.merchandisingAssociationItems[0].showProductQuickView == 'true'){
				widgetHTML = widgetHTML
				+" onmouseover='showPopupButton("+this.merchandisingAssociationItems[0].catEntry_Identifier+");' onmouseout='hidePopupButton("+this.merchandisingAssociationItems[0].catEntry_Identifier+");'>";
			}else{
				widgetHTML = widgetHTML
				+" >";
			}
			widgetHTML = widgetHTML
			+"	<a href='"+this.merchandisingAssociationItems[0].catEntry_ProductLink+"'  id='img"+this.merchandisingAssociationItems[0].catEntry_Identifier+"' onfocus='showPopupButton("+this.merchandisingAssociationItems[0].catEntry_Identifier+");'>";
			widgetHTML = widgetHTML
			+"		<img src='"+this.merchandisingAssociationItems[0].catEntry_Thumbnail+"' alt='"+this.merchandisingAssociationItems[0].catEntry_ShortDescription+"' class='img' width='70' height='70'/>"
			+"	</a><br />";
			if(this.merchandisingAssociationItems[0].showProductQuickView == 'true'){
				widgetHTML = widgetHTML
				+" <div id='popupButton_"+this.merchandisingAssociationItems[0].catEntry_Identifier+"' class='main_quickinfo_button'>"
					+"<span class='secondary_button' >\n"
						+"<span class='button_container' >\n"
							+"<span class='button_bg' >\n"
								+"<span class='button_top'>\n"
									+"<span class='button_bottom'>\n"
										+"<a id='QuickInfoButton_"+this.merchandisingAssociationItems[0].catEntry_Identifier+"' href='#' onclick='javaScript:var actionListImageAcct = new popupActionProperties(); actionListImageAcct.showWishList="+this.merchandisingAssociationItems[0].associationProductBuyable+"; actionListImageAcct.showAddToCart="+this.merchandisingAssociationItems[0].associationProductBuyable+"; showPopup("+this.merchandisingAssociationItems[0].catEntry_Identifier+",event,null,null,actionListImageAcct);' onkeypress='javaScript:var actionListImageAcct = new popupActionProperties(); actionListImageAcct.showWishList="+this.merchandisingAssociationItems[0].associationProductBuyable+"; actionListImageAcct.showAddToCart="+this.merchandisingAssociationItems[0].associationProductBuyable+"; showPopup("+this.merchandisingAssociationItems[0].catEntry_Identifier+",event,null,null,actionListImageAcct);' onblur='hidePopupButton("+this.merchandisingAssociationItems[0].catEntry_Identifier+");' role='wairole:button' waistate:haspopup='true'>"+this.merchandisingAssociationItems[0].showProductQuickViewLable+"</a>"
									+"</span>\n"
								+"</span>\n"
							+"</span>\n"
						+"</span>\n"
					+"</span>\n"										
				+"</div>\n";
			}
			widgetHTML = widgetHTML
			+"</div>";	
		
			if(this.totalAssociationCount > 1){
				if(this.associationThumbnailIndex > 1 ){
					widgetHTML = widgetHTML
					+"		<a href='Javascript:categoryDisplayJS.showPreviousAssociation()'  id='WC_ProductAssociation_DownArrow_Link_1'>";
				}
				widgetHTML = widgetHTML
				+"		<img src='"+this.baseCatalogEntryDetails[0].storeImage_Path+"i_down_arrow.png' alt='"+this.displayPrevAssociation+"'/></a>";
			}
			
			var comboText = this.baseCatalogEntryDetails[0].associatedProductsName.replace(/%0/, this.baseCatalogEntryDetails[0].baseCatEntry_Name);
			comboText = comboText.replace(/%1/, this.merchandisingAssociationItems[0].catEntry_Name);
			
			widgetHTML = widgetHTML
			+"</div>"
			+"<div class='combo_text' id='WC_CategoryDisplayJS_div_2'>\n"
			+"	<h1 id='maHeader' class='status_msg'>"+ comboText +"</h1>\n"
			+"	<span id='maPrice' class='grey'>"+totalPriceMsg+dojo.currency.format(totalPrice.toFixed(2), {currency: this.baseCatalogEntryDetails[0].currency})+"</span>\n"
			+"</div>\n";
			widgetHTML = widgetHTML
			+"<input type='hidden' id='compareImgPath_"+this.merchandisingAssociationItems[0].catEntry_Identifier+"' value='"+this.merchandisingAssociationItems[0].catEntry_Thumbnail_compare+"'/>"
			+"<input type='hidden' id='compareProductDetailsPath_"+this.merchandisingAssociationItems[0].catEntry_Identifier+"' value='"+this.merchandisingAssociationItems[0].catEntry_ProductLink+"'/>"
			+"<input type='hidden' id='compareImgDescription_"+this.merchandisingAssociationItems[0].catEntry_Identifier+"' value='"+this.merchandisingAssociationItems[0].catEntry_ShortDescription+"'/>";
			associationDisplay.innerHTML=null;
			associationDisplay.innerHTML=widgetHTML;
			dojo.parser.parse(associationDisplay);
},


	*//**
	* showNextAssociation Displays the next association in the association array. No action is performed if it is already at the last item.
	*				      This function is used with the merchandising association widget on the MerchandisingAssociationDisplay.jsp to display the next
	*					  association available.
	**//*
	showNextAssociation : function(){
		
		if(this.associationThumbnailIndex < this.totalAssociationCount){
			this.associationThumbnailIndex = this.associationThumbnailIndex+1;
			this.initializeMerchandisingAssociation(this.associationThumbnailIndex);
		}
	},

	*//**
	* showPreviousAssociation Displays the previous association in the association array. No action is performed if it is already the first item.
	*				      This function is used with the merchandising association widget on the MerchandisingAssociationDisplay.jsp to display the previous
	*					  association available.
	**//*
	showPreviousAssociation : function(){
		
	if(this.associationThumbnailIndex > 1 ){
			this.associationThumbnailIndex = this.associationThumbnailIndex-1;
			this.initializeMerchandisingAssociation(this.associationThumbnailIndex);
		}
	},

	*//**
	* AddAssociation2ShopCartAjax Adds the associated product to the shopping cart when AjaxAddToCart is enabled.
	*
	* @param {String} baseProductId The catalog entry ID of the parent product.
	* @param {int} baseProductQuantity The quantity of the parent product to add.
	*
	**//*
	AddAssociation2ShopCartAjax:function(baseProductId,baseProductQuantity){
	
		var identifierJSON = "associatedCatEntries_"+this.associationThumbnailIndex;
		//Get the associated item from the JSON object.
		var associationEntryJSON = eval('('+ dojo.byId(identifierJSON).innerHTML +')');
		this.merchandisingAssociationItems = associationEntryJSON;
		this.baseItemAddedToCart = false;
		//Add the parent product to the cart.
		if(this.merchandisingAssociationItems[0].catEntry_Type=='ProductBean'){
			this.Add2ShopCartAjax(baseProductId,baseProductQuantity);
			if(this.baseItemAddedToCart){
				//Show the pop-up to select the attributes of the associated product.
				showPopup(this.merchandisingAssociationItems[0].catEntry_Identifier,function(e){return e;},'marchandisingAssociationDisplay');
			}
		}else if (this.merchandisingAssociationItems[0].catEntry_Type=='ItemBean' || this.merchandisingAssociationItems[0].catEntry_Type=='PackageBean' || this.merchandisingAssociationItems[0].catEntry_Type=='BundleBean'){
			//Get the associated item from the JSON object.
			var entitledItemJSON = eval('('+ dojo.byId(baseProductId).innerHTML +')');
			this.setEntitledItems(entitledItemJSON);
			var catalogEntryId = this.getCatalogEntryId();
			var params = [];
				params.storeId		= this.storeId;
				params.catalogId	= this.catalogId;
				params.langId			= this.langId;
				params.orderId		= ".";
				params.calculationUsage = "-1,-2,-5,-6,-7";
			if(catalogEntryId!=null){
				this.updateParamObject(params,"catEntryId",catalogEntryId,false,-1);
				this.updateParamObject(params,"quantity",baseProductQuantity,false,-1);
				if(this.merchandisingAssociationItems[0].catEntry_Type=='BundleBean'){
					var form = document.getElementById(this.merchandisingAssociationItems[0].catEntry_BundleFormId);
					var catEntryArray = [];
					// add the individual bundle items to the request.
					catEntryArray = form.catEntryIDS.value.toString().split(",");
					for(var i = 0; i < catEntryArray.length; i++){
						var qty = document.getElementById("quantity_" + catEntryArray[i]).value;
						var catEntryId = catEntryArray[i];
						if(this.getDefaultItem(catEntryArray[i]))
							catEntryId = this.getDefaultItem(catEntryArray[i]);
						if(qty==0 || qty == null) qty = 1;
						if(qty!=null && qty!='' && catEntryId!=null){
							this.updateParamObject(params,"catEntryId",catEntryId,false,-1);
							this.updateParamObject(params,"quantity",qty,false,-1);
						}else{
							MessageHelper.displayErrorMessage(MessageHelper.messages['ERR_RESOLVING_SKU']);
							return;
						}
					}
				}else{
					this.updateParamObject(params,"catEntryId",this.merchandisingAssociationItems[0].catEntry_Identifier,false,-1);
					this.updateParamObject(params,"quantity",1,false,-1);
				}
			}else{
				MessageHelper.displayErrorMessage(MessageHelper.messages['ERR_RESOLVING_SKU']);
				return;
			}
			//For Handling multiple clicks
			if(!submitRequest()){
				return;
			}   		
			cursor_wait();				
			//Invoke service to add to the cart.
			wc.service.invoke("AjaxAddOrderItem", params);
		}
	},

	*//**
	* AddMarchandisingAssociation2ShopCart Adds the associated product to the shopping cart when AjaxAddToCart is disabled.
	*
	* @param {String} entitledItemId A DIV containing a JSON object which holds information about a catalog entry. You can reference CachedProductOnlyDisplay.jsp to see how that div is constructed.
	* @param {form} form The form which contains the details of the item that needs to be added to the cart. This method will set the quanitty, catEntryId_1, productId_1 as well as
	*					 quantity_2, catEntryId_2 and productId_2 values in the form based on the values from the quantity you enter into this method and the catalog entry ID 
	* 					 resolved from retrieving the catalog entry ID of the entitled item passed in.						
	* @param {int} quantity The quantity of the parent product to add.
	*
	**//*
	AddMarchandisingAssociation2ShopCart : function(entitledItemId,form,quantity){
	
	var identifierJSON = "associatedCatEntries_"+this.associationThumbnailIndex;
	var associationEntryJSON = eval('('+ dojo.byId(identifierJSON).innerHTML +')');
	this.merchandisingAssociationItems = associationEntryJSON;
	//get the item form the JSON object	
	var entitledItemJSON;

	if (dojo.byId(entitledItemId)!=null) {
		//the json object for entitled items are already in the HTML. 
		 entitledItemJSON = eval('('+ dojo.byId(entitledItemId).innerHTML +')');
	}else{
		//if dojo.byId(entitledItemId) is null, that means there's no <div> in the HTML that contains the JSON object. 
		//in this case, it must have been set in catalogentryThumbnailDisplay.js when the quick info
		entitledItemJSON = this.getEntitledItemJsonObject(); 
	}
	this.setEntitledItems(entitledItemJSON);
	var catalogEntryId_1 = this.getCatalogEntryId();
	//Add the product to the cart if the product attributes are selected otherwise show the pop-up dialog.	
	if(this.merchandisingAssociationItems[0].catEntry_Type=='ProductBean'){
		if(catalogEntryId_1!=null){
			form.catEntryId_1.value = catalogEntryId_1;
			form.productId_1.value = catalogEntryId_1;
			form.quantity_1.value = quantity;
			this.merchandisingProductAssociationAddToCart = true;
			this.merchandisingProductAssociationForm = form;
			showPopup(this.merchandisingAssociationItems[0].catEntry_Identifier,function(e){return e;},'marchandisingAssociationDisplay');
		}else{
			MessageHelper.displayErrorMessage(MessageHelper.messages['ERR_RESOLVING_SKU']);
			return;
		}
	}else if (this.merchandisingAssociationItems[0].catEntry_Type=='ItemBean' || this.merchandisingAssociationItems[0].catEntry_Type=='PackageBean' || this.merchandisingAssociationItems[0].catEntry_Type=='BundleBean'){
		//Add the  items to the shop cart.
		if(catalogEntryId_1!=null){
			form.catEntryId_1.value = catalogEntryId_1;
			form.productId_1.value = catalogEntryId_1;
			form.quantity_1.value = quantity;
			if(this.merchandisingAssociationItems[0].catEntry_Type=='BundleBean'){
				// add the individual bundle items to the request.
				var bundleForm = document.getElementById(this.merchandisingAssociationItems[0].catEntry_BundleFormId);
				var catEntryArray = [];
				catEntryArray = bundleForm.catEntryIDS.value.toString().split(",");
				var catEntryCount = 3;
				for(var i = 0; i < catEntryArray.length; i++){
					var qty = document.getElementById("quantity_" + catEntryArray[i]).value;
					var catEntryId = catEntryArray[i];
					if(this.getDefaultItem(catEntryArray[i]))
							catEntryId = this.getDefaultItem(catEntryArray[i]);
					if(qty==0 || qty == null) qty = 1;
					if(qty!=null && qty!='' && catEntryId!=null){
						if(i==0){
							form.catEntryId_2.value = catEntryId;
							form.productId_2.value = catEntryId;
							form.quantity_2.value = qty;	
						}else{
							var input1 = document.createElement("input");
							input1.setAttribute("id", "OrderAssociationItemAddForm_catEntryId_"+catEntryId);
							input1.setAttribute("type", "hidden");
							input1.setAttribute("name", "catEntryId_"+catEntryCount);
							input1.setAttribute("value", catEntryId);
							form.appendChild(input1);
							var input2 = document.createElement("input");
							input2.setAttribute("id", "OrderAssociationItemAddForm_productId_"+catEntryId);
							input2.setAttribute("type", "hidden");
							input2.setAttribute("name", "productId_"+catEntryCount);
							input2.setAttribute("value", catEntryId);
							form.appendChild(input2);
							var quantity1 = document.createElement("input");
							quantity1.setAttribute("id", "OrderAssociationItemAddForm_quantity_"+catEntryId);
							quantity1.setAttribute("type", "hidden");
							quantity1.setAttribute("name", "quantity_"+catEntryCount);
							quantity1.setAttribute("value", "1");
							form.appendChild(quantity1);
							catEntryCount = catEntryCount+1;
						}
						
					}else{
						MessageHelper.displayErrorMessage(MessageHelper.messages['ERR_RESOLVING_SKU']);
						return;
					}
				}
			}else{
				form.catEntryId_2.value = this.merchandisingAssociationItems[0].catEntry_Identifier;
				form.productId_2.value = this.merchandisingAssociationItems[0].catEntry_Identifier;
				form.quantity_2.value = "1";
			}
			
			//For Handling multiple clicks
			if(!submitRequest()){
				return;
			}

			// submit the form to add the items to the shop cart.
			form.submit();	
		}else{
			MessageHelper.displayErrorMessage(MessageHelper.messages['ERR_RESOLVING_SKU']);
			return;
		}
		}
	},

	*//** 
	* AddAssociation2ShopCart Adds an associated product to the shopping cart. This function is called by other functions in the FastFinderDisplay.js such as Add2ShopCart().
	* 
	* @param {String} associatedItemId The catalog entry ID of the associated item.
	* @param {int} quantity The quantity of the associated item to add.
	*
	**//*
	AddAssociation2ShopCart:function(associatedItemId,quantity){
	
	var form = this.merchandisingProductAssociationForm;
	this.merchandisingProductAssociationAddToCart = false;
	if(this.isParentBundleBean){
		// add the individual bundle items to the request.
		var catEntryArray = [];
		catEntryArray = form.catEntryIDS.value.toString().split(",");
		var bundleItemsCount = 1;
		for(var i = 0; i < catEntryArray.length; i++){
			var qty = document.getElementById("quantity_" + catEntryArray[i]).value;
			var catEntryId = catEntryArray[i];
			if(this.selectedProducts[catEntryArray[i]])
				catEntryId = this.getCatalogEntryIdforProduct(this.selectedProducts[catEntryArray[i]]);
			if(qty==0 || qty == null) qty = 1;
			if(qty!=null && qty!='' && catEntryId!=null){
				var input1 = document.createElement("input");
				input1.setAttribute("id", "OrderItemAddForm_catEntryId_"+catEntryId);
				input1.setAttribute("type", "hidden");
				input1.setAttribute("name", "catEntryId_"+bundleItemsCount);
				input1.setAttribute("value", catEntryId);
				bundleItemsCount = bundleItemsCount + 1;
				form.appendChild(input1);
			}else{
				MessageHelper.displayErrorMessage(MessageHelper.messages['ERR_RESOLVING_SKU']);
				return;
			}
		}
		var input2 = document.createElement("input");
		input2.setAttribute("id", "OrderItemAddForm_catEntryId_"+associatedItemId);
		input2.setAttribute("type", "hidden");
		input2.setAttribute("name", "catEntryId_"+bundleItemsCount);
		input2.setAttribute("value", associatedItemId);
		form.appendChild(input2);
		var quantity1 = document.createElement("input");
		quantity1.setAttribute("id", "OrderItemAddForm_quantity_"+associatedItemId);
		quantity1.setAttribute("type", "hidden");
		quantity1.setAttribute("name", "quantity_"+bundleItemsCount);
		quantity1.setAttribute("value", quantity);
		form.appendChild(quantity1);
		form.URL.value = "AjaxOrderItemDisplayView";
		this.isParentBundleBean = false;
	}else{
		form.catEntryId_2.value = associatedItemId;
		form.productId_2.value = associatedItemId;
		form.quantity_2.value = quantity;
	}
	
	//For Handling multiple clicks
	if(!submitRequest()){
		return;
	}
	
	// submit the form to add the items to the shop cart.
	form.submit();
	this.merchandisingProductAssociationForm = "";
	},

	*//**
	* AddAssociationItem2ShopCartAjax Adds the associated item to the shopping cart when AjaxAddToCart is enabled.
	*								  This function is called from MerchandisingAssociationsDisplay.jsp to add an associated item to the shopping cart.
	*
	* @param {String} baseItemId The catalog entry ID of the item to add.
	* @param {int} baseItemQuantity The quantity to add.
	* @param {Object} customParams - Any additional parameters that needs to be passed during service invocation.
	*
	**//*
	AddAssociationItem2ShopCartAjax:function(baseItemId , baseItemQuantity, customParams) {
	
	var ajaxShopCartService = "AjaxAddOrderItem";
	var identifierJSON = "associatedCatEntries_"+this.associationThumbnailIndex;
	//get the item form the JSON object	
	var associationEntryJSON = eval('('+ dojo.byId(identifierJSON).innerHTML +')');
	this.merchandisingAssociationItems = associationEntryJSON;
	this.baseItemAddedToCart = false;
	//Add the parent item to the cart and if the associated catentry is a product bean then show the pop-up dialog.
	if(this.merchandisingAssociationItems[0].catEntry_Type=='ProductBean'){
		this.AddItem2ShopCartAjax(baseItemId,baseItemQuantity,customParams);
		if(this.baseItemAddedToCart){
			showPopup(this.merchandisingAssociationItems[0].catEntry_Identifier,function(e){return e;},'marchandisingAssociationDisplay');
		}
	}else if (this.merchandisingAssociationItems[0].catEntry_Type=='ItemBean' || this.merchandisingAssociationItems[0].catEntry_Type=='PackageBean' || this.merchandisingAssociationItems[0].catEntry_Type=='BundleBean'){
			var params = [];
				params.storeId		= this.storeId;
				params.catalogId	= this.catalogId;
				params.langId			= this.langId;
				params.orderId		= ".";
				params.calculationUsage = "-1,-2,-5,-6,-7";
			this.updateParamObject(params,"catEntryId",baseItemId,false,-1);
			this.updateParamObject(params,"quantity",baseItemQuantity,false,-1);
			// add the individual bundle items to the request.
			if(this.merchandisingAssociationItems[0].catEntry_Type=='BundleBean'){
				var form = document.getElementById(this.merchandisingAssociationItems[0].catEntry_BundleFormId);
				var catEntryArray = [];
				catEntryArray = form.catEntryIDS.value.toString().split(",");
				for(var i = 0; i < catEntryArray.length; i++){
					var qty = document.getElementById("quantity_" + catEntryArray[i]).value;
					var catEntryId = catEntryArray[i];
					if(this.getDefaultItem(catEntryArray[i]))
							catEntryId = this.getDefaultItem(catEntryArray[i]);
					if(qty==0 || qty == null) qty = 1;
					if(qty!=null && qty!='' && catEntryId!=null){
						this.updateParamObject(params,"catEntryId",catEntryId,false,-1);
						this.updateParamObject(params,"quantity",qty,false,-1);
					}else{
						MessageHelper.displayErrorMessage(MessageHelper.messages['ERR_RESOLVING_SKU']);
						return;
					}
				}
			}else{
				this.updateParamObject(params,"catEntryId",this.merchandisingAssociationItems[0].catEntry_Identifier,false,-1);
				this.updateParamObject(params,"quantity",1,false,-1);
			}
			
			//For Handling multiple clicks
			if(!submitRequest()){
				return;
			} 			
			cursor_wait();			
			//Invoke service to add item to the cart.
			if(customParams != null && customParams != 'undefined'){
				if(customParams['catalogEntryType'] == 'dynamicKit' ){
					ajaxShopCartService = "AjaxAddPreConfigurationToCart";
				}
			}

			wc.service.invoke(ajaxShopCartService, params);
		}
	},

	*//**
	* AddAssociationItem2ShopCart Adds the parent item with associated catentry to the shopping cart when AjaxAddToCart is disabled.
	*
	* @param {form} form The form which contains the details of the item that needs to be added to the cart. The {@link fastFinderJS.merchandisingProductAssociationForm}
	*				      is set to the the form passed in. The forms quanitity_1 and quantity_2 values are set according to the values passed in 
	*					  for quantity and the value of the quantity_<catEntryId> element for the two quantity values respectively. The catEntryId_2 and productId_2 values
	*					  are also set. 
	* @param {int} quantity The quantity of the item to add to the cart.
	*
	**//*
	AddAssociationItem2ShopCart : function(form,quantity){

	var identifierJSON = "associatedCatEntries_"+this.associationThumbnailIndex;
	//Get the associated item from the JSON object.
	var associationEntryJSON = eval('('+ dojo.byId(identifierJSON).innerHTML +')');
	this.merchandisingAssociationItems = associationEntryJSON;
	//Add the parent item to the cart and if the associated catentry is a product bean then show the pop-up dialog.
	if(this.merchandisingAssociationItems[0].catEntry_Type=='ProductBean'){
		if(quantity) form.quantity_1.value = quantity;
		this.merchandisingProductAssociationAddToCart = true;
		this.merchandisingProductAssociationForm = form;
		showPopup(this.merchandisingAssociationItems[0].catEntry_Identifier,function(e){return e;},'marchandisingAssociationDisplay');
	}else if (this.merchandisingAssociationItems[0].catEntry_Type=='ItemBean' || this.merchandisingAssociationItems[0].catEntry_Type=='PackageBean' || this.merchandisingAssociationItems[0].catEntry_Type=='BundleBean'){
		if(quantity) form.quantity_1.value = quantity;
			// add the individual bundle items to the request.
			if(this.merchandisingAssociationItems[0].catEntry_Type=='BundleBean'){
				var bundleForm = document.getElementById(this.merchandisingAssociationItems[0].catEntry_BundleFormId);
				var catEntryArray = [];
				catEntryArray = bundleForm.catEntryIDS.value.toString().split(",");
				var catEntryCount = 3;
				for(var i = 0; i < catEntryArray.length; i++){
					var qty = document.getElementById("quantity_" + catEntryArray[i]).value;
					var catEntryId = catEntryArray[i];
					if(this.getDefaultItem(catEntryArray[i]))
							catEntryId = this.getDefaultItem(catEntryArray[i]);
					if(qty==0 || qty == null) qty = 1;
						if(i==0){
							form.catEntryId_2.value = catEntryId;
							form.productId_2.value = catEntryId;
							form.quantity_2.value = qty;	    
						}else{
							var input1 = document.createElement("input");
							input1.setAttribute("id", "OrderAssociationItemAddForm_catEntryId_"+catEntryId);
							input1.setAttribute("type", "hidden");
							input1.setAttribute("name", "catEntryId_"+catEntryCount);
							input1.setAttribute("value", catEntryId);
							form.appendChild(input1);
							var input2 = document.createElement("input");
							input2.setAttribute("id", "OrderAssociationItemAddForm_productId_"+catEntryId);
							input2.setAttribute("type", "hidden");
							input2.setAttribute("name", "productId_"+catEntryCount);
							input2.setAttribute("value", catEntryId);
							form.appendChild(input2);
							var quantity1 = document.createElement("input");
							quantity1.setAttribute("id", "OrderAssociationItemAddForm_quantity_"+catEntryId);
							quantity1.setAttribute("type", "hidden");
							quantity1.setAttribute("name", "quantity_"+catEntryCount);
							quantity1.setAttribute("value", "1");
							form.appendChild(quantity1);
							catEntryCount = catEntryCount+1;
						}
					}
			}else{
				form.catEntryId_2.value = this.merchandisingAssociationItems[0].catEntry_Identifier;
				form.productId_2.value = this.merchandisingAssociationItems[0].catEntry_Identifier;
				form.quantity_2.value = "1";
			}
			
			//For Handling multiple clicks
			if(!submitRequest()){
				return;
			}
			
			//submit the form to add the item to the cart.
			form.submit();	
		}
	},

	*//**
	* AddAssociationBundle2ShopCartAjax Adds the parent bundle and associated products to the shopping cart when AjaxAddToCart is enabled.
	*									This function is used on MerchandisingAssociationsDisplay.jsp.
	*
	* @param {form} form The form which contains the details of the catalog entries that need to be added to the cart.
	* 				      This form is expected to have a comma separated list of catalog entry IDs of catalog entries in the bundle which should be added to the shopping cart.
	*
	**//*
	AddAssociationBundle2ShopCartAjax:function(form){

	var identifierJSON = "associatedCatEntries_"+this.associationThumbnailIndex;
	//Get the associated item from the JSON object.
	var associationEntryJSON = eval('('+ dojo.byId(identifierJSON).innerHTML +')');
	this.merchandisingAssociationItems = associationEntryJSON;
	this.baseItemAddedToCart = false;
//Add the parent bundle to the cart and show the pop-up dialog for the associated product.
			
			var params = [];
			
			params.storeId		= this.storeId;
			params.catalogId	= this.catalogId;
			params.langId		= this.langId;
			params.orderId		= ".";
			params.calculationUsage = "-1,-2,-5,-6,-7";
		// add the individual bundle items of the parent bundle to the request.
			var catEntryArray = [];
			catEntryArray = form.catEntryIDS.value.toString().split(",");
			for(var i = 0; i < catEntryArray.length; i++){
				var qty = document.getElementById("quantity_" + catEntryArray[i]).value;
				var catEntryId = catEntryArray[i];
				if(this.getDefaultItem(catEntryArray[i]))
							catEntryId = this.getDefaultItem(catEntryArray[i]);
				if(qty==0 || qty == null) qty = 1;
				if(qty!=null && qty!='' && catEntryId!=null){
					this.updateParamObject(params,"catEntryId",catEntryId,false,-1);
					this.updateParamObject(params,"quantity",qty,false,-1);
					this.baseItemAddedToCart = "true";
				}else{
					MessageHelper.displayErrorMessage(MessageHelper.messages['ERR_RESOLVING_SKU']);
					return;
				}
			}
			// add the individual bundle items of the associated bundle to the request.
			if(this.merchandisingAssociationItems[0].catEntry_Type=='BundleBean'){
					var bundleForm = document.getElementById(this.merchandisingAssociationItems[0].catEntry_BundleFormId);
					var innerCatEntryArray = [];
					innerCatEntryArray = bundleForm.catEntryIDS.value.toString().split(",");
					for(var i = 0; i < innerCatEntryArray.length; i++){
						var qty = document.getElementById("quantity_" + innerCatEntryArray[i]).value;
						var innerCatEntryId = innerCatEntryArray[i];
						if(this.getDefaultItem(innerCatEntryArray[i]))
							innerCatEntryId = this.getDefaultItem(innerCatEntryArray[i]);
						if(qty==0 || qty == null) qty = 1;
						if(qty!=null && qty!='' && innerCatEntryId!=null){
							this.updateParamObject(params,"catEntryId",innerCatEntryId,false,-1);
							this.updateParamObject(params,"quantity",qty,false,-1);
						}else{
							MessageHelper.displayErrorMessage(MessageHelper.messages['ERR_RESOLVING_SKU']);
							return;
						}
					}
				}else if(this.merchandisingAssociationItems[0].catEntry_Type=='PackageBean' || this.merchandisingAssociationItems[0].catEntry_Type=='ItemBean'){
					this.updateParamObject(params,"catEntryId",this.merchandisingAssociationItems[0].catEntry_Identifier,false,-1);
					this.updateParamObject(params,"quantity",1,false,-1);
				}
			//For Handling multiple clicks
			if(!submitRequest()){
				return;
			}   
			cursor_wait();			
			//Invoke service to add to the cart.
			wc.service.invoke("AjaxAddOrderItem", params);
	
	   if(this.merchandisingAssociationItems[0].catEntry_Type=='ProductBean'){
		   showPopup(this.merchandisingAssociationItems[0].catEntry_Identifier,function(e){return e;},'marchandisingAssociationDisplay');
	   }
},

*//** 
* Sets the orderID if it is not already set on the Current Order page. 
* The order ID is used to determine which order to act upon such as in the case of replacing an order item in an order.
* @param {String} orderId The orderID to use.
*//*
setOrderId : function(orderId)
{
	this.orderId = orderId;
},

	*//**
	* AddAssociationBundle2ShopCart Adds the parent bundle and associated product to the shopping cart when AjaxAddToCart is disabled.
	*								This function is used on MerchandisingAssociationsDisplay.jsp. 
	* 
	* @param {form} form The form which contains the details of the catalog entries that need to be added to the cart.
	* 						The {@link fastFinderJS.merchandisingProductAssociationForm} is set to the form passed in.
	*						The form is expected to have a value for catEntryIDS which is a list of catalog entry IDs of the catalog entries in the bundle which should be
	*						added to the shopping cart.
	*
	**//*
	AddAssociationBundle2ShopCart : function(form){
	
	var identifierJSON = "associatedCatEntries_"+this.associationThumbnailIndex;
	//get the item form the JSON object	
	var associationEntryJSON = eval('('+ dojo.byId(identifierJSON).innerHTML +')');
	this.merchandisingAssociationItems = associationEntryJSON;
	this.isParentBundleBean = true;
	//Add the parent bundle to the cart and show the pop-up dialog for the associated product.
	if(this.merchandisingAssociationItems[0].catEntry_Type=='ProductBean'){
		this.merchandisingProductAssociationAddToCart = true;
		this.merchandisingProductAssociationForm = form;
		var catEntryArray = [];
		// add the individual bundle items of the parent bundle to the request.
		catEntryArray = form.catEntryIDS.value.toString().split(",");
		var bundleItemsCount = 1;
		for(var i = 0; i < catEntryArray.length; i++){
			var qty = document.getElementById("quantity_" + catEntryArray[i]).value;
			var catEntryId = catEntryArray[i];
			if(this.getDefaultItem(catEntryArray[i]))
							catEntryId = this.getDefaultItem(catEntryArray[i]);
			if(catEntryId != null)
							form["catEntryId_" + catEntryArray[i]].value = catEntryId;				
			else{
					MessageHelper.displayErrorMessage(MessageHelper.messages['ERR_RESOLVING_SKU']);
					return;
			}
			bundleItemsCount = bundleItemsCount + 1;
			
		}
		showPopup(this.merchandisingAssociationItems[0].catEntry_Identifier,function(e){return e;},'marchandisingAssociationDisplay');
	}else if (this.merchandisingAssociationItems[0].catEntry_Type=='ItemBean' || this.merchandisingAssociationItems[0].catEntry_Type=='PackageBean' || this.merchandisingAssociationItems[0].catEntry_Type=='BundleBean'){
		var catEntryArray = [];
		// add the individual bundle items of the parent bundle to the request.
		catEntryArray = form.catEntryIDS.value.toString().split(",");
		var bundleItemsCount = 1;
		for(var i = 0; i < catEntryArray.length; i++){
			var qty = document.getElementById("quantity_" + catEntryArray[i]).value;
			var catEntryId = catEntryArray[i];
			if(this.getDefaultItem(catEntryArray[i]))
							catEntryId = this.getDefaultItem(catEntryArray[i]);
			if(catEntryId != null)
							form["catEntryId_" + catEntryArray[i]].value = catEntryId;				
			else{
					MessageHelper.displayErrorMessage(MessageHelper.messages['ERR_RESOLVING_SKU']);
					return;
			}
			bundleItemsCount = bundleItemsCount + 1;
			
		}
		if(this.merchandisingAssociationItems[0].catEntry_Type=='BundleBean'){
			// add the individual bundle items of the associated bundle to the request.
			var bundleForm = document.getElementById(this.merchandisingAssociationItems[0].catEntry_BundleFormId);
			var innerCatEntryArray = [];
			innerCatEntryArray = bundleForm.catEntryIDS.value.toString().split(",");
			for(var i = 0; i < innerCatEntryArray.length; i++){
				var qty = document.getElementById("quantity_" + innerCatEntryArray[i]).value;
				var innerCatEntryId = innerCatEntryArray[i];
				if(this.getDefaultItem(innerCatEntryArray[i])){
							innerCatEntryId = this.getDefaultItem(innerCatEntryArray[i]);
							}
				if(qty==0 || qty == null) qty = 1;
				if(qty!=null && qty!='' && innerCatEntryId!=null){
					var input2 = document.createElement("input");
					input2.setAttribute("id", "OrderItemAddForm_catEntryId_"+innerCatEntryId);
					input2.setAttribute("type", "hidden");
					input2.setAttribute("name", "catEntryId_"+bundleItemsCount);
					input2.setAttribute("value", innerCatEntryId);
					form.appendChild(input2);
					var quantity2 = document.createElement("input");
					quantity2.setAttribute("id", "OrderItemAddForm_quantity_"+innerCatEntryId);
					quantity2.setAttribute("type", "hidden");
					quantity2.setAttribute("name", "quantity_"+bundleItemsCount);
					quantity2.setAttribute("value", "1");
					form.appendChild(quantity2);
					bundleItemsCount = bundleItemsCount + 1;
				}else{
					MessageHelper.displayErrorMessage(MessageHelper.messages['ERR_RESOLVING_SKU']);
					return;
				}
			}
		}else{
			var input2 = document.createElement("input");
			input2.setAttribute("id", "OrderItemAddForm_catEntryId_"+this.merchandisingAssociationItems[0].catEntry_Identifier);
			input2.setAttribute("type", "hidden");
			input2.setAttribute("name", "catEntryId_"+bundleItemsCount);
			input2.setAttribute("value", this.merchandisingAssociationItems[0].catEntry_Identifier);
			form.appendChild(input2);
			var quantity2 = document.createElement("input");
			quantity2.setAttribute("id", "OrderItemAddForm_quantity_"+this.merchandisingAssociationItems[0].catEntry_Identifier);
			quantity2.setAttribute("type", "hidden");
			quantity2.setAttribute("name", "quantity_"+bundleItemsCount);
			quantity2.setAttribute("value", "1");
			form.appendChild(quantity2);
		}
		form.URL.value = "AjaxOrderItemDisplayView";
		
		//For Handling multiple clicks
		if(!submitRequest()){
			return;
		}
		
		//submit the form to add to cart.
		form.submit();
	}
	
},

	*//**
	 * Resolves the SKU and adds the item to a new requisition list.
	 *  
	 * @param {String} entitledItemId The catalog entry ID of the item to add to the requisition list.
	 * @param {String} quantityElemId The ID of the Quantity field.
	 * @param {String} currentPage The URL of the current page. When a customer clicks Cancel on the requisition list creation page, they are redirected to the current page.
	 *//*
	addToNewListFromProductDetail:function (entitledItemId,quantityElemId,currentPage) {
		MessageHelper.hideAndClearMessage();
		var entitledItemJSON;

		if (dojo.byId(entitledItemId)!=null) {
			//the json object for entitled items are already in the HTML. 
			 entitledItemJSON = eval('('+ dojo.byId(entitledItemId).innerHTML +')');
		}else{
			//if dojo.byId(entitledItemId) is null, that means there's no <div> in the HTML that contains the JSON object. 
			//in this case, it must have been set in catalogentryThumbnailDisplay.js when the quick info
			entitledItemJSON = this.getEntitledItemJsonObject(); 
		}
		this.setEntitledItems(entitledItemJSON);
		var catalogEntryId = this.getCatalogEntryId();
		if(catalogEntryId!=null){
			this.addItemToNewListFromProductDetail(catalogEntryId, quantityElemId, currentPage);
		}
		else{
			MessageHelper.displayErrorMessage(MessageHelper.messages['ERR_RESOLVING_SKU_REQ_LIST']);
			//Close the quick info pop-up if it exists
			if(dijit.byId('second_level_category_popup') != null){
				hidePopup('second_level_category_popup');
			}
			return;			
		}
	},
	
	*//**
	 * Adds the item to a new requisition list.
	 *  
	 * @param {String} catalogEntryId The resolved catalog entry ID of the item to add to the requisition list.
	 * @param {String} quantityElemId The ID of the Quantity field.
	 * @param {String} currentPage The URL of the current page. When a customer clicks Cancel on the requisition list creation page, they are redirected to the current page.
	 *//*
	addItemToNewListFromProductDetail:function (catalogEntryId,quantityElemId,currentPage) {
		MessageHelper.hideAndClearMessage();
		if(catalogEntryId!=null){
			var quantity = document.getElementById(quantityElemId).value;
			if (quantity == null || quantity == "" || quantity<=0 || !RequisitionList.isNumber(quantity)) {
				MessageHelper.displayErrorMessage(MessageHelper.messages['QUANTITY_INPUT_ERROR']);
				//Close the quick info pop-up if it exists
				if(dijit.byId('second_level_category_popup') != null){
					hidePopup('second_level_category_popup');
				}
				return;
			}
			if(this.ajaxMyAccount){
				var URL = "AjaxLogonForm?page=createrequisitionlist";
			} else {
				var URL = "RequisitionListDetailView?editable=true&newList=true";
			}
			
			//using the form because the previousPage url can be very long
			var formObj = document.createElement("form");
			formObj.setAttribute("method","POST");
			
			var input = document.createElement("input");
			input.setAttribute("type", "hidden");
			input.setAttribute("value", currentPage);
			input.setAttribute("name", "previousPage");
			formObj.appendChild(input);
			
			formObj.action = URL + "&catEntryId="+catalogEntryId +"&quantity="+quantity+ "&storeId=" + this.storeId +"&catalogId=" + this.catalogId + "&langId=" + this.langId;
			
			document.body.appendChild(formObj); // have to add this form to the body node before submitting.
			formObj.submit();
		}
		else{
			MessageHelper.displayErrorMessage(MessageHelper.messages['ERR_RESOLVING_SKU_REQ_LIST']);
		}
	},	
	
	*//**
	 * Adds the bundle to a new requisition list.
	 *  
	 * @param {form} form The form that contains all of the inputs for the bundle.
	 * @param {String} currentPage The URL of the current page. When a customer clicks Cancel on the requisition list creation page, they are redirected to the current page.
	 *//*
	addBundleToNewListFromProductDetail:function (form,currentPage) {
		var productCount = form["numberOfProduct"].value;
		var URL = "";
		if(this.ajaxMyAccount){
			URL = "AjaxLogonForm?page=createrequisitionlist";
		} else {
			URL = "RequisitionListDetailView?editable=true&newList=true";
		}	
		
		for(var i = 1; i <= productCount; i++){
			var catEntryId = form["catEntryId_" + i].value;
			if(this.selectedProducts[catEntryId]) {
				catEntryId = this.getCatalogEntryIdforProduct(this.selectedProducts[catEntryId]);
			}
			
			var qty = form["quantity_" + i].value;
			if(qty == null || qty == "" || qty<=0 || !RequisitionList.isNumber(qty)){ 
				MessageHelper.displayErrorMessage(MessageHelper.messages['QUANTITY_INPUT_ERROR']); 
				return;
			} else if(catEntryId!=null){			
				URL = URL + "&catEntryId=" + catEntryId + "&quantity=" + qty;
			} else{
				MessageHelper.displayErrorMessage(MessageHelper.messages['ERR_RESOLVING_SKU_REQ_LIST']);
				return;
			}
		}
		
		var input = document.createElement("input");
		input.setAttribute("type", "hidden");
		input.setAttribute("value", currentPage);
		input.setAttribute("name", "previousPage");
		form.appendChild(input);		
		
		URL = URL +"&numberOfProduct="+form.numberOfProduct.value+ "&storeId=" + this.storeId +"&catalogId=" + this.catalogId + "&langId=" + this.langId; 
		form.action=URL;
		form.submit();
	},	
	
	*//**
	* Resolves the SKU and adds the item to an existing requisition list.
	*
	* @param {string} entitledItemId The catalog entry ID of the item to add to the requisition list.
	* @param {string} quantityElemId The ID of the Quantity field.
	* @param {boolean} ajaxAddToCart Indicates whether the AJAX Add to Cart flexflow is enabled.
	*//*
	addToExistingRequisitionList:function (entitledItemId,quantityElemId,ajaxAddToCart) {
		//resolve the SKU for the product
				var entitledItemJSON;

		if (dojo.byId(entitledItemId)!=null) {
			//the json object for entitled items are already in the HTML. 
			 entitledItemJSON = eval('('+ dojo.byId(entitledItemId).innerHTML +')');
		}else{
			//if dojo.byId(entitledItemId) is null, that means there's no <div> in the HTML that contains the JSON object. 
			//in this case, it must have been set in catalogentryThumbnailDisplay.js when the quick info
			entitledItemJSON = this.getEntitledItemJsonObject(); 
		}
		this.setEntitledItems(entitledItemJSON);
		var catalogEntryId = this.getCatalogEntryId();
		
		if(catalogEntryId!=null){
			//Add the resolved SKU to the selected requisition list
			this.addItemToExistingRequisitionList(catalogEntryId,quantityElemId,ajaxAddToCart);
		} else{
			MessageHelper.displayErrorMessage(MessageHelper.messages['ERR_RESOLVING_SKU_REQ_LIST']);
		}
	},	
	
	*//** 
	* Adds the bundle to an existing requisition list.
	*
	* @param {form} form The form that contains all of the inputs for the bundle.
	* @param {boolean} ajaxAddToCart Indicates whether the AJAX Add to Cart flexflow is enabled.
	*//*
	addBundleToExistingRequisitionList:function(form,ajaxAddToCart){
		//Get all the requisition list radio button inputs
		var reqListSelection = document.getElementsByName("RequisitionListTableDisplay_RequisitionListSelection");
		
		//Retrieve the requisition list id from the radio button selection
		for (var i=0; i<reqListSelection.length; i++) {
			if (reqListSelection.item(i).checked) {
				var requisitionListId = reqListSelection.item(i).value;
			} 
		}
		
		if(ajaxAddToCart){
			var params = [];
	
			params.storeId		= this.storeId;
			params.catalogId	= this.catalogId;
			params.langId		= this.langId;
			params["requisitionListId"] = requisitionListId;
				
			var productCount = form["numberOfProduct"].value;
			for(var i = 1; i <= productCount; i++){
				var catEntryId = form["catEntryId_" + i].value;
				if(this.selectedProducts[catEntryId]) {
					catEntryId = this.getCatalogEntryIdforProduct(this.selectedProducts[catEntryId]);
				}
				
				var qty = form["quantity_" + i].value;
				if(qty == null || qty == "" || qty<=0 || !RequisitionList.isNumber(qty)){ 
					MessageHelper.displayeErrorMessage(MessageHelper.messages['QUANTITY_INPUT_ERROR']); 
					return;
				} else if(qty!=null && qty!='' && catEntryId!=null){
					this.updateParamObject(params,"catEntryId",catEntryId,false,-1);
					this.updateParamObject(params,"quantity",qty,false,-1);
					this.baseItemAddedToCart=true;
				} else{
					MessageHelper.displayErrorMessage(MessageHelper.messages['ERR_RESOLVING_SKU_REQ_LIST']);
					return;
				}
			}
			//For Handling multiple clicks
			if(!submitRequest()){
				return;
			}   		
			cursor_wait();		
			wc.service.invoke("requisitionListAddItem_popup", params);
		} else {
			form.action = "RequisitionListItemUpdate?requisitionListId="+requisitionListId;
			
			if(this.ajaxMyAccount){
				form.URL.value = "AjaxLogonForm?page=editrequisitionlist&requisitionListId=" + requisitionListId + "&editable=true";
			} else {
				form.URL.value = "RequisitionListDetailView?requisitionListId=" + requisitionListId + "&editable=true";
			}			
			
			//For Handling multiple clicks
			if(!submitRequest()){
				return;
			}   		
			cursor_wait();
			form.submit();
		}	
	},	

	*//**
	* Adds the resolved SKU of an item to an existing requisition list.
	* Assumes that the catalogEntryId is a resolved SKU.
	*
	* @param {string} catalogEntryId The resolved catalog entry ID of the item to add to the requisition list.
	* @param {string} quantityElemId The ID of the Quantity field.
	* @param {boolean} ajaxAddToCart Indicates whether the AJAX Add to Cart flexflow is enabled.
	*//*
	addItemToExistingRequisitionList:function (catalogEntryId,quantityElemId,ajaxAddToCart) {
		if(catalogEntryId!=null){
			//Validate the quantity value
			var quantity = document.getElementById(quantityElemId).value;
			if (!RequisitionList.isNumber(quantity) || quantity <= 0) {
				if(quantityElemId == "productPopUpQty"){
					MessageHelper.displayErrorMessage(MessageHelper.messages['QUANTITY_INPUT_ERROR']);
					//Close the quick info pop-up if it exists
					if(dijit.byId('second_level_category_popup') != null){
						hidePopup('second_level_category_popup');
					}
					return;
				} else {
					MessageHelper.formErrorHandleClient(quantityElemId,MessageHelper.messages["QUANTITY_INPUT_ERROR"]); 
					return;
				}
			}		
	
			//Get all the requisition list radio button inputs
			var reqListSelection = document.getElementsByName("RequisitionListTableDisplay_RequisitionListSelection");
			
			//Retrieve the requisition list id from the radio button selection
			for (var i=0; i<reqListSelection.length; i++) {
				if (reqListSelection.item(i).checked) {
					var requisitionListId = reqListSelection.item(i).value;
				} 
			}
						
			//For Ajax "Add to Cart" flexflow, add item and remain on the same page
			if(ajaxAddToCart){
				var params = {};
				
				params["requisitionListId"] = requisitionListId;
				params["catEntryId"] = catalogEntryId;
				params["quantity"] = quantity;
				params.storeId = this.storeId;
				params.catalogId = this.catalogId;
				params.langId = this.langId;
				
				For Handling multiple clicks. 
				if(!submitRequest()){
					return;
				}			
				cursor_wait();
				wc.service.invoke('requisitionListAddItem_popup',params);				
			} else { 
				//For Non-Ajax add to cart
				var form = document.forms["RequisitionListPopupForm"];
				form.requisitionListId.value = requisitionListId;
				form.quantity.value = quantity;
				form.catEntryId.value = catalogEntryId;
				
				if(this.ajaxMyAccount){
					form.URL.value = "AjaxLogonForm?page=editrequisitionlist&requisitionListId=" + requisitionListId + "&editable=true";
				} else {
					form.URL.value = "RequisitionListDetailView?requisitionListId=" + requisitionListId + "&editable=true";
				}
				
				For Handling multiple clicks. 
				if(!submitRequest()){
					return;
				}			
				cursor_wait();
				form.submit();
			}
		} else{
			MessageHelper.displayErrorMessage(MessageHelper.messages['ERR_RESOLVING_SKU_REQ_LIST']);
		}		
	},
	
	*//**
	* Sets the currentPageType variable. 
	* This variable determines the type of catalog pages that are being viewed, such as product or item pages.
	*
	* @param {Boolean} pageType Indicates the type of catalog page viewed by the customer.
	*
	**//*
	setCurrentPageType:function(pageType){
		this.currentPageType = pageType;
	},	
	
	*//**
	* Sets the currentCatalogEntryId variable. 
	* This variable stores the catalogEntryId of the catalog item being viewed.
	*
	* @param {Boolean} catalogEntryId The ID of the new catalog item viewed by the customer.
	*
	**//*
	setCurrentCatalogEntryId:function(catalogEntryId){
		this.currentCatalogEntryId = catalogEntryId;
	},
	
	*//**
	 * Submits a category subscription request.
	 * If AjaxAddToCart is enabled, then invoke the AjaxCategorySubscribe service; otherwise submit the form and reload the page.
	 * 
	 * @param {String} formId The form Id.
	 * @param {Boolean} ajaxEnabled A true/false value that indicates if AjaxAddToCart is enabled.
	 *//*
	handleCategorySubscription:function(formId, ajaxEnabled){
		if(ajaxEnabled == true || ajaxEnabled == "true"){
			var form = document.forms[formId];
			var params = {};
			params["DM_ReqCmd"] = form.DM_ReqCmd.value;
			params["storeId"] = form.storeId.value;
			params["catalogId"] = form.catalogId.value;
			params["langId"] = form.langId.value;
			params["categoryId"] = form.categoryId.value;
			if(!submitRequest()){
				return;
			}
			cursor_wait();
			wc.service.invoke("AjaxCategorySubscribe", params);
		}else{
			var form = document.forms[formId];
			form.URL.value = location.href;
			form.submit();
		}
	}
}

categoryDisplayJS.HistoryTracker.prototype.back = categoryDisplayJS.goBack;
categoryDisplayJS.HistoryTracker.prototype.forward=categoryDisplayJS.goForward;
		
		
	
*/
/* End: Aurora Migration */


//-----------------------------------------------------------------
// Licensed Materials - Property of IBM
//
// WebSphere Commerce
//
// (C) Copyright IBM Corp. 2007, 2010 All Rights Reserved.
//
// US Government Users Restricted Rights - Use, duplication or
// disclosure restricted by GSA ADP Schedule Contract with
// IBM Corp.
//-----------------------------------------------------------------

//
//

/**
* @fileOverview This file holds methods to perform client side operations in relation to catalog browsing, usually at the category level.<b> 
* 			For example, this file holds methods to add items to the shopping cart, wish list and compare zone and to resolve SKUs.<b> 
*			This file is referenced in a collection of JSPs including all of the catalog entry display JSPs such as
*			CachedBundleDisplay.jsp, CachedItemDisplay.jsp , CachedPackageDisplay.jsp, CachedProductOnlyDisplay.jsp.
*			As well this file is included in CategoryOnlyResultsDisplay.jsp and in none catalog browsing pages such as 
*			CatalogSearchDisplay.jsp and MyAccountDisplay.jsp.
*
* @version 1.0
**/

/**
* @class categoryDisplayJS This class defines all the variables and functions used by the CategoryDisplay.js. Any page that will use a function in this file
*		can access that function thru this class. Pages that use categoryDisplayJS include CachedProductOnlyDisplay.jsp which is responsible for
*		displaying product details. As well CategoryOnlyResultsDisplay.jsp uses this page to facilitate the category browsing functionality such as add to cart, 
*		wish list and compare zone.
*
**/

/* Declare the namespace for this file if it does not already exist. */
if (categoryDisplayJS == null || typeof(categoryDisplayJS) != "object") {
	var categoryDisplayJS = new Object();
}

categoryDisplayJS={
	
	/** An array of entitled items which is used in various methods throughout CategoryDisplay.js **/
	entitledItems:[],
	
	/** An map which holds the attributes of a set of products **/
	selectedProducts:new Object(),
	
	/** A map of attribute name value pairs for the currently selected attribute values **/
	selectedAttributes:new Object(),
	
	/** Can be used to hold a map of error messages **/
	errorMessages: new Object(),
	
	/** The language ID currently in use **/
	langId: "-1",
	
	/** The store ID currently in use **/
	storeId: "",
	
	/** The catalog ID currently in use **/
	catalogId: "",
	
	/** The order ID currently in use if being called from the pending order details page.**/
	orderId: "",
	
	/** Holds a boolean value indicating whether or not AJAX shopping cart is enabled or not. **/
	ajaxShopCart:true,
	
	/** Holds a boolean value indicating whether or not AJAX My Account is enabled or not. **/
	ajaxMyAccount:true,
	
	/** Can be used to indicate whether or not there has been a context change event **/
	contextChanged:false, 
	
	/** Set to true in the goBack and goForward methods **/
	isHistory:false,
	
	/** Holds an array of  JSON objects representing properties of merchandising associations **/
	merchandisingAssociationItems:[],
	
	/** Holds an array of JSON objects holding information about the parent catalog entries of merchandising associations **/
	baseCatalogEntryDetails:[],
	
	/** Used to determine the index of the next association to display and is used as a global storage variable to share data between methods. **/
	associationThumbnailIndex:1,
	
	/** A count of the number of merchandising associations available. **/
	totalAssociationCount:0,
	
	/** A boolean used in a variety of the add to cart methods to tell whether or not the base item was added to the cart. **/
	baseItemAddedToCart:false,
	
	/** A boolean used to determine whether or not to add merchandising associations to the cart **/
	merchandisingProductAssociationAddToCart:false,
	
	/** The form which holds information about merchandising associations to be added to the cart **/
	merchandisingProductAssociationForm:"",
	
	/** A boolean used to determine whether or not the parent catalog entry is a bundle bean. **/
	isParentBundleBean:false,
	
	/** Holds the current user type such as guest or registered user. Allowed values are 'G' for guest and 'R' for registered.**/
	userType:"",
	
	/** A variable used to form the url dynamically for the more info link in the Quickinfo popup */
	moreInfoUrl :"",
	/** The text to display as an alt to the image used on the MerchandisingAssociationDisplay.jsp to show the previous assoication **/
	displayPrevAssociation:"",
	
	/** The text to display as an alt to the image used on the MerchandisingAssociationDisplay.jsp to show the next assoication **/
	displayNextAssociation:"",
	
	/** A map holding a mapping between product IDs as its key and the first entitled item ID of that product as its value **/
	defaultItemArray:[],

	/** The type of the catalog page that the user is currently viewing **/
	currentPageType:"",

	/** The identifier of the catalog entry that the current page is displaying **/
	currentCatalogEntryId:"",
	
    /** a JSON object that holds attributes of an entitled item **/
    entitledItemJsonObject: null,

	/**
	* A boolean used to to determine is it from a Qick info popup or not. 
	**/
	isPopup : false,

	/**
	* A boolean used to to determine whether or not to diplay the price range when the catEntry is selected. 
	**/
	displayPriceRange : true,

	/**
	* This array holds the json object retured from the service, holding the price information of the catEntry.
	**/
	itemPriceJsonOject : [],
    
	/**
	* initHistory This function will take elementId and changeUrl as inputs and create a new history tracker object and sets the initial state.
	*			  This is used on CategoriesDisplay.jsp to initialize the page history to the CategoryDisplay URL of the category you are on.
	* @param {String} elementId  HistoryTracker elementId.
	* @param {String} changeUrl HistoryTracker URL.
	*
	**/
	initHistory:function(elementId, changeUrl){
		var historyObject = new categoryDisplayJS.HistoryTracker(elementId, changeUrl);
		dojo.back.setInitialState(historyObject);	
	},
	
	/**
	* setAjaxShopCart This function will set the flag "ajaxShopCart" which is used to determine if the shopping cart is using the Ajax flow or not.
	*
	* @param {Boolean} ajaxShopCart Flag which indicates whther to use AJAX shopping cart or not.
	*
	**/
	setAjaxShopCart:function(ajaxShopCart){
		this.ajaxShopCart = ajaxShopCart;
	},
	
	/**
	* setAjaxMyAccount This function will set the flag "ajaxMyAccount" which is used to determine if the My Account page is using the Ajax flow or not.
	*
	* @param {Boolean} ajaxMyAccount Flag which indicates whether to use AJAX My Account or not.
	*
	**/	
	setAjaxMyAccount:function(ajaxMyAccount){
		this.ajaxMyAccount = ajaxMyAccount;
	},	
	
	/**
	* setCommonParameters This function initializes storeId, catalogId, and langId.
	*
	* @param {String} langId The language id to use.
	* @param {String} storeId The store id to use.
	* @param {String} catalogId The catalog id to use.
	* @param {String} userType The type of user. G for Guest user.
	* 
	**/
	setCommonParameters:function(langId,storeId,catalogId,userType){
		this.langId = langId;
		this.storeId = storeId;
		this.catalogId = catalogId;
		this.userType = userType;
	},
	
	/**
	* setEntitledItems Sets an array of entitled items for a product. 
	*				   This function is used in CachedBundleDisplay.jsp to add all the entitled SKUs of the products in a particular bundle to this array.
	*				   The array that is generated is used later in {@link fastFinderJS.resolveSKU}.
	* 
	* @param {Object} entitledItemArray An object which holds both the catalog entry ID as well as an array of attributes for the entitled items of a product.
	*
	**/
	setEntitledItems : function(entitledItemArray){
		
		this.entitledItems = entitledItemArray;
	},

	/**
	* setSelectedAttribute Sets the selected attribute value for a particular attribute not in reference to any catalog entry.
	*					   One place this function is used is on CachedProductOnlyDisplay.jsp where there is a drop down box of attributes.
	*					   When an attribute is selected from that drop down this method is called to update the selected value for that attribute.
	*
	* @param {String} selectedAttributeName The name of the attribute.
	* @param {String} selectedAttributeValue The value of the selected attribute.
	*
	**/
	setSelectedAttribute : function(selectedAttributeName , selectedAttributeValue){ 
		this.selectedAttributes[selectedAttributeName] = selectedAttributeValue;
		this.moreInfoUrl=this.moreInfoUrl+'&'+selectedAttributeName+'='+selectedAttributeValue;
	},

	/**
	* setSelectedAttributeJS Sets the selected attribute value for a particular attribute not in reference to any catalog entry.
	*					   One place this function is used is on the quick info pop up where there is a drop down box of attributes.
	*					   When an attribute is selected from that drop down this method is called to update the selected value for that attribute.
	*
	* @param {String} selectedAttributeName The name of the attribute.
	* @param {String} selectedAttributeValue The value of the selected attribute.
	*
	**/
	setSelectedAttributeJS : function(selectedAttributeName , selectedAttributeValue){ 
		console.debug(selectedAttributeName.replace(/'/g,"&#039;") +" : "+ selectedAttributeValue);
		this.selectedAttributes[selectedAttributeName.replace(/'/g,"&#039;")] = selectedAttributeValue;
		this.moreInfoUrl=this.moreInfoUrl+'&'+selectedAttributeName.replace(/'/g,"&#039;") +'='+selectedAttributeValue;
	},
	
	/**
	* This function is used to change the price displayed in the Product Display Page on change of  a attribute of the product using an AJAX call. 
	* This function will resolve the catentryId using entitledItemId and displays the price of the catentryId.
	*				
	* @param {Object} entitledItemId A DIV containing a JSON object which holds information about a catalog entry. You can reference CachedProductOnlyDisplay.jsp to see how that div is constructed.
	* @param {Boolean} isPopup If the value is true, then this implies that the function was called from a quick info pop-up.
	* @param {Boolean} displayPriceRange If the value is true, then display the price range. If it is false then donot display the price range.
	*
	**/
	changePrice : function(entitledItemId,isPopup,displayPriceRange){
		this.displayPriceRange = displayPriceRange;
		this.isPopup = isPopup;
		var entitledItemJSON;
			
		if (dojo.byId(entitledItemId)!=null && !this.isPopup) {
			//the json object for entitled items are already in the HTML. 
			 entitledItemJSON = eval('('+ dojo.byId(entitledItemId).innerHTML +')');
		}else{
			//if dojo.byId(entitledItemId) is null, that means there's no <div> in the HTML that contains the JSON object. 
			//in this case, it must have been set in catalogentryThumbnailDisplay.js when the quick info
			entitledItemJSON = this.getEntitledItemJsonObject(); 			
		}
		
		this.setEntitledItems(entitledItemJSON);
		var catalogEntryId = this.getCatalogEntryId();
		if(catalogEntryId!=null){
			//check if the json object is already present for the catEntry.
			if(this.itemPriceJsonOject[catalogEntryId] != null && this.itemPriceJsonOject[catalogEntryId] != 'undefined'){
				
				this.displayPriceLocal(catalogEntryId);
				console.debug("CategoryDisplay.changePrice: using stored json object.");
				categoryDisplayJS.displayLeadTimeNew(this.itemPriceJsonOject[catalogEntryId]);
				console.debug("CategoryDisplay.leadtime: using stored json object.");
			}
			//if json object is not present, call the service to get the details.
			else{
				
				var parameters = {};
				parameters.storeId = this.storeId;
				parameters.langId= this.langId;
				parameters.catalogId= this.catalogId;
				parameters.productId= catalogEntryId;
				parameters.catalogEntryID= document.getElementById('productIdQuickInfo').innerHTML;
				parameters.onlyCatalogEntryPrice = 'false';
				parameters.parentCatId= catalogEntryId;
				dojo.xhrPost({
					url: getAbsoluteURL() + "ProductInfoJSON",						
					content: parameters,
					handleAs: "text",
					service: this,
					load:function(data){
					if (dojo.byId(entitledItemId)==null)
						dojo.create("div", {innerHTML:data}, dojo.body(), "last");
					
					if (dojo.byId(entitledItemId)!=null)							
						var  entitledItemJSON = eval('('+ dojo.byId(entitledItemId).innerHTML +')');
						
					this.setEntitledItems(entitledItemJSON);
					var catEntry;
					for (x in this.entitledItems) {
						if (catalogEntryId == this.entitledItems[x].catentry_id) {
								catEntry = this.entitledItems[x];
						}
					}
					categoryDisplayJS.displayProductJSON(entitledItemJSON,catalogEntryId);
					},
					error: function(errObj,ioArgs) {
						console.debug("CategoryDisplay.changePrice: Unexpected error occurred during an xhrPost request. Error= "+errObj+" ioArgs= "+ioArgs);
						console.error(err);
					}
				});		
			}
			categoryDisplayJS.displayPriceLocal(catalogEntryId);
		}
		else{
			//reset
			this.resetValues();
			console.debug("CategoryDisplay.changePrice: all attributes are not selected.");
		}		
	},
	
	resetValues : function(){
		if (document.getElementById('WC_CachedProductOnlyDisplay_div_4') !=null )
			document.getElementById('WC_CachedProductOnlyDisplay_div_4').style.display = 'none';
		if (document.getElementById('itemInfo') != null)
			document.getElementById('itemInfo').style.display = 'none';
		if (document.getElementById('leadTime_1') != null )
			document.getElementById('leadTime_1').style.display = 'none';
		if (document.getElementById('PPN_1') != null )
			document.getElementById('PPN_1').style.display = 'none';
		if (document.getElementById('productSKUValue_1') != null )
			document.getElementById('productSKUValue_1').style.display = 'none';
		if (document.getElementById('chooseAttrText') != null )
			document.getElementById('chooseAttrText').style.display = 'block';

		
		if(!categoryDisplayJS.isConfigProduct()){
			categoryDisplayJS.displayWTB();
		}
	},
	
	
	/**
	* This function is used to change the price displayed in the Product Display Page on change of  a attribute of the product using an AJAX call. 
	* This function will resolve the catentryId using entitledItemId and displays the price of the catentryId.
	*				
	* @param {Object} entitledItemId A DIV containing a JSON object which holds information about a catalog entry. You can reference CachedProductOnlyDisplay.jsp to see how that div is constructed.
	* @param {Boolean} isPopup If the value is true, then this implies that the function was called from a quick info pop-up.
	* @param {Boolean} displayPriceRange If the value is true, then display the price range. If it is false then donot display the price range.
	* @param {Boolean} changeAttribute If the function is getting called for change Attribute flow in which we are updating the exiting item
	* @param {Integer} oldOrderItemId If we changing the attribute of exisitng item then it will contain that order item id for which we are changing attributes.
	*
	**/
	loadItemDisplayScreen : function(entitledItemId,isPopup,displayPriceRange,changeAttribute,oldOrderItemId){
		this.displayPriceRange = displayPriceRange;
		this.isPopup = isPopup;
		var entitledItemJSON;

		if (dojo.byId(entitledItemId)!=null && !this.isPopup) {
			
			//the json object for entitled items are already in the HTML. 
			 entitledItemJSON = eval('('+ dojo.byId(entitledItemId).innerHTML +')');
		}else{
			
			//if dojo.byId(entitledItemId) is null, that means there's no <div> in the HTML that contains the JSON object. 
			//in this case, it must have been set in catalogentryThumbnailDisplay.js when the quick info
			entitledItemJSON = this.getEntitledItemJsonObject(); 			
		}
		
		this.setEntitledItems(entitledItemJSON);
		var catalogEntryId = this.getCatalogEntryId();
		
	if(catalogEntryId!=null){
				setTimeout('displayProgressBar()',500);
				var tempPartIdUrl = categoryDisplayJS.getPartIdUrlProductJSON(entitledItemJSON,catalogEntryId);
				
				//check if changeAttribute value is true; if yes, append required parameters to part page
				if(undefined != changeAttribute && changeAttribute == true){
					tempPartIdUrl = tempPartIdUrl + "?changeAttribute="+changeAttribute+"&oldOrderItemId="+oldOrderItemId;
				}
				
				window.location= tempPartIdUrl;	
			
		}
		else{
			//reset
			this.resetValues();
			console.debug("CategoryDisplay.loadItemDisplayScreen: all attributes are not selected.");
		}
	},
	
	resetValues : function(){
		if (document.getElementById('WC_CachedProductOnlyDisplay_div_4') !=null )
			document.getElementById('WC_CachedProductOnlyDisplay_div_4').style.display = 'none';
		if (document.getElementById('itemInfo') != null)
			document.getElementById('itemInfo').style.display = 'none';
		if (document.getElementById('leadTime_1') != null )
			document.getElementById('leadTime_1').style.display = 'none';
		if (document.getElementById('PPN_1') != null )
			document.getElementById('PPN_1').style.display = 'none';
		if (document.getElementById('productSKUValue_1') != null )
			document.getElementById('productSKUValue_1').style.display = 'none';
		if (document.getElementById('chooseAttrText') != null )
			document.getElementById('chooseAttrText').style.display = 'block';

		
		if(!categoryDisplayJS.isConfigProduct()){
			categoryDisplayJS.displayWTB();
		}
	},
	
	
	
	/**Check to see if a configurable product **/
	
	isConfigProduct : function(){
		var catalogEntryID;
		if (document.getElementById('productIdQuickInfo')!=null){
			catalogEntryID = document.getElementById('productIdQuickInfo').innerHTML;
		}
		var extConfigurableProductDivId = "externallyConfigurableProduct_"+catalogEntryID;
		var mixedConfigurableProductDivId = "mixedConfigurableProduct_"+catalogEntryID;
		
		if(dojo.byId(extConfigurableProductDivId)!=null && dojo.byId(extConfigurableProductDivId)!=undefined){
			if(dojo.byId(mixedConfigurableProductDivId)!=null && dojo.byId(mixedConfigurableProductDivId)!=undefined){
				return false;}
			else{
				return true;}
		}
		else{
			return false;}
	},

	/** 
	 * Displays price of the catEntry selected with the JSON object returned from the server.
	 * 
	 * @param {object} serviceRepsonse The JSON response from the service.
	 * @param {object} ioArgs The arguments from the service call.
	 */	
	 displayPriceServiceResponse : function(serviceResponse, ioArgs){		
		
		//stores the json object, so that the service is not called when same catEntry is selected.
		categoryDisplayJS.itemPriceJsonOject[serviceResponse.catalogEntry.catalogEntryIdentifier.uniqueID] = serviceResponse;

		categoryDisplayJS.displayPrice(serviceResponse.catalogEntry);
		categoryDisplayJS.displayLeadTime(serviceResponse);
	 },
	 
	 displayProductJSON : function(entitledItemJSON,catEntryId){	
			this.setEntitledItems(entitledItemJSON);
			var leadTime = "";
			var productPartNumber = "";
			var popup = categoryDisplayJS.isPopup;
			var catEntry;
			for (x in this.entitledItems) {
				if (catEntryId == this.entitledItems[x].catentry_id) {
					leadTime = this.entitledItems[x].leadTime;
					catEntry = this.entitledItems[x];
					productPartNumber = this.entitledItems[x].partNumber;
				}
			}
			categoryDisplayJS.itemPriceJsonOject[catEntryId] = entitledItemJSON;
			categoryDisplayJS.displayPrice(catEntry);
			categoryDisplayJS.displayLeadTimeNew(catEntry);

	},
	
	
	getPartIDProductJSON : function(entitledItemJSON,catEntryId){	
		this.setEntitledItems(entitledItemJSON);
		var partId = "";
		
		for (x in this.entitledItems) {
			if (catEntryId == this.entitledItems[x].catentry_id) {
				partId = this.entitledItems[x].catentry_id;
			}
		}
		return partId;
},
	 
		getPartIdUrlProductJSON : function(entitledItemJSON,catEntryId){	
			this.setEntitledItems(entitledItemJSON);
			var partIDUrl = "";
			//for (x in this.entitledItems) {
			for(var x=0;x<this.entitledItems.length;x++){
				if (catEntryId == this.entitledItems[x].catentry_id) {
					partIDUrl = this.entitledItems[x].partDetailDisplayUrl ;
					break;
				}				
			}
			return partIDUrl;
		},
		 
	displayLeadTime : function(serviceResponse){
		var attributes = serviceResponse.catalogEntryAttributes.attributes;
		var inv = serviceResponse.inventory;
		var productPartNumber = "";
		var leadTime="";
		var ship = "";
		var avail = "";
		
		if (this.langId=='-1'){
			var ship = 'ships within ';
			var avail = ' business day(s)';
		}else {
			var ship = 'Lieferung innerhalb von ';
			var avail = ' Arbeitstag(en)';
		}
		
		for(var i in attributes){
			var obj = attributes[i].name;	
			if(inv >= 1000){
			if(attributes[i].name==stdLeadTime){
			 leadTime = attributes[i].attributeDataType.value;
			}}
			else{
				 if(attributes[i].name==osLeadTime){					
				   leadTime = attributes[i].attributeDataType.value;}}		
			
		}		
		productPartNumber = serviceResponse.catalogEntry.catalogEntryIdentifier.externalIdentifier.partNumber;
		
		document.getElementById('leadTime_2').innerHTML = ship + leadTime + avail;
		document.getElementById('leadTime_1').style.display = 'block';
		document.getElementById('catalog_link').innerHTML = serviceResponse.catalogEntry.description[0].name;		
	 },
	 
	 displayLeadTimeNew : function(serviceResponse){
			var attributes = serviceResponse.Attributes;
			var inv = serviceResponse.inventory;
			var productPartNumber = serviceResponse.partNumber;
			var leadTime=serviceResponse.leadTime;
			var ship = "";
			var avail = "";
			
			if (this.langId=='-1'){
				var ship = 'ships within ';
				var avail = ' business day(s)';
			}else {
				var ship = 'Lieferung innerhalb von ';
				var avail = ' Arbeitstag(en)';
			}
			
			document.getElementById('leadTime_2').innerHTML = ship + leadTime + avail;
			document.getElementById('leadTime_1').style.display = 'block';	
	},
	
	
	/** 
	 * 	Display Where to Buy when sku is Unbuyable.
	 */	 
	displayWTB : function() {
		
		//display for quickview
		if(document.getElementById('WTBProductDiv')){
			document.getElementById('WTBProductDiv').style.display = 'block';
		}
		if(document.getElementById('productQuantity')){
			document.getElementById('productQuantity').style.display = 'none';
		}
		if(document.getElementById('addToCartAction')){
			document.getElementById('addToCartAction').style.display = 'none';
		}
		if(document.getElementById('productActions')){
			document.getElementById('productActions').style.display = 'none';
		}
		if(document.getElementById('WTB_HidePrice')){
			document.getElementById('WTB_HidePrice').style.display = 'none';
		}
		if(document.getElementById('WTB_HideShipping')) {
			document.getElementById('WTB_HideShipping').style.display = 'none';
		}	
		
		//display for pdp   
		if(document.getElementById('itemIsBuyableDynWTB')) {
			document.getElementById('itemIsBuyableDynWTB').style.display = 'block';
		}
		if(document.getElementById('itemIsBuyableLeadTime')) {
			document.getElementById('itemIsBuyableLeadTime').style.display = 'none';
		}
		if(document.getElementById('itemIsBuyableDynAddtoCart')) {
			document.getElementById('itemIsBuyableDynAddtoCart').style.display = 'none';
		}
	},
	
	/**
	 * Hide Where to buy when sku is still buyable.
	 */
	hideWTB : function() {
		//hide for quickview
		if (document.getElementById('WTBProductDiv') != null ) {
			document.getElementById('WTBProductDiv').style.display = 'none'; 
		}
		if(document.getElementById('productQuantity')){
			document.getElementById('productQuantity').style.display = 'block';
		}
		if(document.getElementById('addToCartAction')){
			document.getElementById('addToCartAction').style.display = 'block';
		}
		if(document.getElementById('productActions')){
			document.getElementById('productActions').style.display = 'block';
		}
		if(document.getElementById('WTB_HidePrice')){
			document.getElementById('WTB_HidePrice').style.display = 'block';
		}
		if(document.getElementById('WTB_HideShipping')) {
			document.getElementById('WTB_HideShipping').style.display = 'block';
		}
		
		//hide for pdp
		if(document.getElementById('itemIsBuyableDynWTB')) {
			document.getElementById('itemIsBuyableDynWTB').style.display = 'none';
		}
		if(document.getElementById('itemIsBuyableLeadTime')) {
			document.getElementById('itemIsBuyableLeadTime').style.display = 'block';
		}
		if(document.getElementById('itemIsBuyableQuantity')) {
			document.getElementById('itemIsBuyableQuantity').style.display = 'block';
		}
		if(document.getElementById('itemIsBuyableDynAddtoCart')) {
			document.getElementById('itemIsBuyableDynAddtoCart').style.display = 'block';
		}
	},
	 
	/** 
	 * Displays price of the attribute selected with the JSON locally.
	 * 
	 * @param {object} catEntryId 
	 */	
	 displayPriceLocal : function(catEntryId) {
		var leadTime = "";
		var productPartNumber = "";
		var itemBuyable = "";
		var catEntry;
		var productBuyable = "";
		var ship = "";
		var avail = "";
		
		if (this.langId=='-1'){
			var ship = 'ships within ';
			var avail = ' business day(s)';
		}else {
			var ship = 'Lieferung innerhalb von ';
			var avail = ' Arbeitstag(en)';
		}
		
		for (x in this.entitledItems) {
			if (catEntryId == this.entitledItems[x].catentry_id) {
				leadTime = this.entitledItems[x].leadTime;
				catEntry = this.entitledItems[x];
				productPartNumber = this.entitledItems[x].partNumber;
				itemBuyable = this.entitledItems[x].buyable;
				productBuyable = this.entitledItems[x].productBuyable;
			}
		}

		// offerprice and PartNumber
		//if (catEntry != null && catEntry.offerPrice) {
		if (catEntry != null) {
			categoryDisplayJS.displayPrice(catEntry);
		}
		
		// leadtime
		if(document.getElementById('leadTime_2')){
			if(leadTime != null && leadTime != ''){
				document.getElementById('leadTime_2').innerHTML = ship + leadTime + avail;
				
				if(document.getElementById('leadTimeAvailability')){
					document.getElementById('leadTimeAvailability').value = leadTime;
				}
			}
			else{
				document.getElementById('leadTime_2').innerHTML = statusNotAvailable;
			}
			document.getElementById('leadTime_1').style.display = 'block';
		}
		
		//check if item is buyable. If not display 'Where To Buy' functionality
		//if it is then hide the default 'Where to Buy' functionality
		if((itemBuyable != '1') || (productBuyable != '1')){
				categoryDisplayJS.displayWTB();
		}else {
			categoryDisplayJS.hideWTB();
		}
	},	
	/**
	 * Displays price of the attribute selected with the JSON oject.
	 * 
	 * @param {object}
	 *            catEntry The JSON object with catalog entry details.
	 */	
	 displayPrice : function(catEntry){

		var tempString;
		var popup = categoryDisplayJS.isPopup;
		if(popup == true){
			if(document.getElementById('productPrice')){
				document.getElementById('productPrice').innerHTML = catEntry.offerPrice;
				dojo.style(dojo.byId('productPrice'),"display","inline");
			}
			if (document.getElementById('productSKUValue')){
				document.getElementById('productSKUValue').innerHTML = catEntry.partName;
				dojo.style(dojo.byId('productSKUValue'),"display","inline");
				if(document.getElementById('productSKUValue_1')){
					dojo.style(dojo.byId('productSKUValue_1'),"display","block");
				}
			}
			if(document.getElementById('itemInfo')){
				dojo.style(dojo.byId('itemInfo'),"display","block");
			}
		}
		if(popup == false){
			var innerHTML = "";
			if(!catEntry.listPriced ||  catEntry.listPrice <= catEntry.offerPrice){
				innerHTML = "<label class='PDP bold'>"+MessageHelper.messages['PRICE']+" "+"</label>" +
							"<span class='price bold' style='margin-left: 60px;'>" + catEntry.offerPrice + "</span>";
			}
			else{
				innerHTML = "<label class='PDP bold'>"+MessageHelper.messages['PRICE']+" "+"</label>" +
							"<span class='price listPrice bold'>" + catEntry.listPrice + "</span>"+
							"<div class='price offerprice bold'>" + catEntry.offerPrice + "</div>";
			}
			innerHTML = innerHTML +	"<br />";
			
			if(categoryDisplayJS.displayPriceRange == true){
				for(var i in catEntry.priceRange){
					if(catEntry.priceRange[i].endingNumberOfUnits != 'null'){
						tempString = MessageHelper.messages['TieredPricingDisp'];
						tempString = tempString.replace('{0}',catEntry.priceRange[i].startingNumberOfUnits);
						tempString = tempString.replace('{1}',catEntry.priceRange[i].endingNumberOfUnits);
						tempString = tempString.replace('{2}',catEntry.priceRange[i].localizedPrice);
						innerHTML = innerHTML + "<span class='price bold'>" + tempString + "</span>";;
					}
					else{
						tempString = MessageHelper.messages['TieredPricingDispLast'];
						tempString = tempString.replace('{0}',catEntry.priceRange[i].startingNumberOfUnits);
						tempString = tempString.replace('{1}',catEntry.priceRange[i].localizedPrice);
						innerHTML = innerHTML + "<span class='price bold'>" + tempString + "</span>";;
					}
					innerHTML = innerHTML + "<br />";
				}
			}
			
			if(document.getElementById('WC_CachedProductOnlyDisplay_div_4')){
				document.getElementById('WC_CachedProductOnlyDisplay_div_4').innerHTML = innerHTML;
				document.getElementById('WC_CachedProductOnlyDisplay_div_4').style.display = 'block';
			}
			
			if(document.getElementById('PPN_2')){
				document.getElementById('PPN_2').innerHTML = catEntry.partNumber;
				document.getElementById('PPN_1').style.display = 'block';
			}
		}
	 },
	 
	 /**
	 * Center "Request a Quote" popup windows 
	 **/
	 PopupCenter : function(pageURL, title, properties) {
		var left = (screen.width / 2) - (800 / 2);
		var top = (screen.height / 2) - (600 / 2);
		window.open(pageURL, title, properties+',top='+top+',left='+left);
	},
	
	/**
	* setSelectedAttributeOfProduct Sets the selected attribute value for an attribute of a specified product.
	*								This function is used to set the assigned value of defining attributes to specific 
	*								products which will be stored in the selectedProducts map.
	*
	* @param {String} productId The catalog entry ID of the catalog entry to use.
	* @param {String} selectedAttributeName The name of the attribute.
	* @param {String} selectedAttributeValue The value of the selected attribute.
	*
	**/
	setSelectedAttributeOfProduct : function(productId,selectedAttributeName,selectedAttributeValue){
		
		selectedAttributesForProduct = new Object();

		if(this.selectedProducts[productId]) selectedAttributesForProduct = this.selectedProducts[productId];
		
		selectedAttributesForProduct[selectedAttributeName] = selectedAttributeValue;
		this.selectedProducts[productId] = selectedAttributesForProduct;
	},
	
	// Function for subcategory display pagination	
	
	/**
	* gotoASubCategoryDisplayPage  This function is used to validate the entered page number and loads the page if valid or displays an error message otherwise.
	*
	* @param {String} pageNum The page number entered.
	* @param {String} totalPages The total number of pages.
	* @param {String} pageSize The page size.
	* @param {String} subCatDispUrl The sub category display URL.
	*
	**/
	gotoASubCategoryDisplayPage : function(pageNum, totalPages, pageSize, subCatDispUrl) {
		pageNum = trim(pageNum);
		if (pageNum == "") {	
			 MessageHelper.formErrorHandleClient(document.getElementById('subCategoriesListDisplayPageNum').id,MessageHelper.messages['ERROR_EMPTY_NUM']);
			return;
		}
		
		if (MessageHelper.IsNumeric(pageNum,false) == false){ 
			 MessageHelper.formErrorHandleClient(document.getElementById('subCategoriesListDisplayPageNum').id,MessageHelper.messages['ERROR_PAGE_NUM']);

			return;
		}	
		
		if (pageNum >= 1 && pageNum <= totalPages) {
		    MessageHelper.hideAndClearMessage();
			var url = subCatDispUrl + "&beginIndex=" + ((pageNum-1) * pageSize);
			this.loadSubCategoryContentURL(url)
		} else {
			MessageHelper.formErrorHandleClient(document.getElementById('subCategoriesListDisplayPageNum').id,MessageHelper.messages['ERROR_PAGE_NUM']);
			
			return;
		}
	}, 

	/**
	* getCatalogEntryId Returns the catalog entry ID of the catalog entry with the selected attributes as specified in the {@link fastFinderJS.selectedAttributes} value.
	*					This method uses {@link fastFinderJS.resolveSKU} to find the SKU with the selected attributes values.
	*
	* @see fastFinderJS.resolveSKU
	*
	* @return {String} catalog entry ID.
	*
	**/
	getCatalogEntryId : function(){
		var attributeArray = [];
		for(attribute in this.selectedAttributes){
			attributeArray.push(attribute + "_" + this.selectedAttributes[attribute]);
		}
		return this.resolveSKU(attributeArray);
	},
	
	/**
	* getCatalogEntryIdforProduct Returns the catalog entry ID for a catalog entry that has the same attribute values as a specified product's selected attributes as passed in via the selectedAttributes parameter.
	*
	* @param {String[]} selectedAttributes The array of selected attributes upon which to resolve the SKU.
	*
	* @return {String} catalog entry ID of the SKU.
	*
	**/
	getCatalogEntryIdforProduct : function(selectedAttributes){
		var attributeArray = [];
		for(attribute in selectedAttributes){
			attributeArray.push(attribute + "_" + selectedAttributes[attribute]);
		}
		return this.resolveSKU(attributeArray);
	},


	/**
	* resolveSKU Resolves a SKU using an array of defining attributes.
	*
	* @param {String[]} attributeArray An array of defining attributes upon which to resolve a SKU.
	*
	* @return {String} catentry_id The catalog entry ID of the SKU.
	*
	**/
	resolveSKU : function(attributeArray){
		//console.debug("Resolving SKU >> " + attributeArray);
		
		var catentry_id = "";
		var attributeArrayCount = attributeArray.length;
		var currentlySelectedAttrs  =0;
		for(var i=0 ;i<attributeArrayCount;i++){			
			if(attributeArray[i].length-1 > attributeArray[i].indexOf("_"))
				currentlySelectedAttrs++;
		}
		var attrSelectIds = new Array();
		for(x in this.entitledItems){
			var catentry_id = this.entitledItems[x].catentry_id;
			var Attributes = this.entitledItems[x].Attributes;
			var attributeCount = 0;
			for(index in Attributes){
				attributeCount ++;
			}

			// Handle special case where a catalog entry has one sku with no attributes
			if (attributeArrayCount == 0 && attributeCount == 0){
				return catentry_id;
			}
		//***********************************		Decoding special characters from Attribute Array	
			
			var keyAttribute = Object.keys(Attributes);
			for (var j=0; j < keyAttribute.length; j++) {								
				var key = keyAttribute[j]; // key
				var value = Attributes[key]; // data
				
				delete Attributes[key]; // deleting data with old key
				var parser = new DOMParser;
				var dom = parser.parseFromString(
				    '<!doctype html><body>' + key, 'text/html');
				var decodedString = dom.body.textContent;
				key = decodedString;  // renaming key
				Attributes[key] = value; // setting data with new key				
			}
			
			//*******************************************
			if(attributeCount != 0 && attributeArrayCount >= attributeCount){
				var matchedAttributeCount = 0;

				for(attributeName in attributeArray){
					var attributeValue = attributeArray[attributeName];
					attributeValue = attributeValue.toString().replace(/\\/g, '');
					if(attributeValue in Attributes){
						matchedAttributeCount ++;
					}
				}
				if(currentlySelectedAttrs == matchedAttributeCount){
					console.debug("updateAttributeSelection attributes updating attributes");
					for(attribute in Attributes){
						var strAttr =  new String(attribute);
												
						var attrSelectId = "attrValue_"+strAttr.substring(0,strAttr.indexOf("_"));
						var attrValueExists = false;
						for(var i = 0; i < attrSelectIds.length; i++)
						   if(attrSelectIds[i] === attrSelectId){
						     attrValueExists=true;
						}
						if(!attrValueExists){
							attrSelectIds.push(attrSelectId);
							this.removeOptions(attrSelectId);
						}
						var setSelected = false;
						for(var i=0 ;i<attributeArray.length;i++){			
							var tempAttributeValue = attributeArray[i].toString().replace(/\\/g, '');						
							if(tempAttributeValue==attribute)
								setSelected = true;
						}						
						this.addOption(attrSelectId,strAttr.substring(strAttr.indexOf("_")+1),strAttr.substring(strAttr.indexOf("_")+1), setSelected);
					}
				}
				if(attributeCount == matchedAttributeCount){
					console.debug("CatEntryId:" + catentry_id + " for Attribute: " + attributeArray);
					return catentry_id;
				}
			}
		}
		return null;
	},
	resetOptions: function(){
		console.debug("resetOptions attributes updating attributes");
		for(attribute in this.selectedAttributes){
			this.selectedAttributes[attribute]="";
		}
		this.resetValues();
		var attrSelectIds = new Array();
		for(x in this.entitledItems){			
			for(attribute in this.entitledItems[x].prodAttributes){
				var strAttr =  new String(attribute);
				var attrSelectId = "attrValue_"+strAttr.substring(0,strAttr.indexOf("_"));
				var attrValueExists = false;
				for(var i = 0; i < attrSelectIds.length; i++)
				   if(attrSelectIds[i] === attrSelectId){
				     attrValueExists=true;
				}
				if(!attrValueExists){
					attrSelectIds.push(attrSelectId);
					this.removeOptions(attrSelectId);
				}
				var parser = new DOMParser;
				var dom = parser.parseFromString(
				    '<!doctype html><body>' + strAttr, 'text/html');
				var strAttr = dom.body.textContent;			
				this.addOption(attrSelectId,strAttr.substring(strAttr.indexOf("_")+1),strAttr.substring(strAttr.indexOf("_")+1),false,true);
			}
		}
	},
	addOption:function(elementId, text,value,selected,enableSelect){
		  var elSel = document.getElementById(elementId);
		  if(elSel!==null) {
		  	for(var i=0; i<elSel.options.length; i++){
			   if(elSel.options[i].value ==value){
			   	return;
			   }
			}
		  	var elOptNew = document.createElement('option');
		  	if(text.indexOf("&amp;#034;") > -1){
		  		text = text.replace("&amp;#034;", "\"");			
		  		
		  	}
		  	elOptNew.text = text;
		    elOptNew.value = value;
		   	try {
		      elSel.add(elOptNew,null); // standards compliant; doesn't work in IE
		    }
		    catch(ex) {
		      elSel.add(elOptNew); // IE only
		    }
		    if(selected){
		    	elSel.selectedIndex =1;
		    	elSel.disabled=true;
		    }
		    if(enableSelect){
		    	elSel.disabled=false;
		    }
		  }
		// HCL Add START_SORTING_CR_1_DATED_02.09.12 : 
		  
		  arritems = new Array();
		  
		  // Code to list out the attribute values in sequence as defined in DB.
		  arritemsTemp = new Array();
		  if($("#prodAttributeMap") != null || $("#prodAttributeMap") != 'undefined'){
			  var prodAttributeMap	=	$("#prodAttributeMap").val();
		  }		 		
		  prodAttributeMap	=	$('<div>').text(prodAttributeMap).html();
		 
		//***********************************		Decoding special characters from Product AttributeMap	
		  var parser = new DOMParser;
		  var dom = parser.parseFromString(
			    '<!doctype html><body>' + prodAttributeMap, 'text/html');
		  var prodAttributeMap = dom.body.textContent;
					
		  for(i=0; i<elSel.length; i++)
		   {
			  if(elSel.options[i].value.indexOf(MessageHelper.messages["QuickInfo_Select"]) != -1){
				  arritems[i] = elSel.options[i].value;
			  }
			  else{
				  var optValStr	=	elSel.options[i].value;
				  var optVal	=	$.trim(elementId.substring(elementId.indexOf("_")+1)+"_"+optValStr+"=");
				  //optVal = optVal.toString().replace(/"/g, '\\"');
				  var index		=	prodAttributeMap.indexOf(optVal);
				  if(index != -1){
					  var attrStr	=	prodAttributeMap.substring(index+optVal.length);
					  var sequence	=	parseInt(attrStr.substring(0,attrStr.indexOf(",") == -1 ? attrStr.indexOf("}") : attrStr.indexOf(",")));					  
					  arritems[sequence] = optValStr;
				  }else{
					  arritemsTemp[i] = optValStr;
				  }
			  }
		   }
		  
		arritems = arritems.filter(function(n){ return (n != undefined && n !='')});
		if(arritemsTemp.length > 0){
			arritemsTemp = arritemsTemp.filter(function(n){ return (n != undefined && n !='')});	
			arritems.concat(arritemsTemp);
		}
		
		  /*for(i=0; i<elSel.length; i++)
		   {
			  arritems[i] = elSel.options[i].value;
		   } */
			//arritems.sort(this.numberSorter);  // Sorting the attribute Values in PDP and Quick Info popup , at Onchange and at Reset
			
		  for(var i=0; i<elSel.length; i++)
		  {  
			  if(arritems[i] !="" && arritems[i] !== undefined){
				  var parser = new DOMParser;
					var dom = parser.parseFromString(
					    '<!doctype html><body>' + arritems[i], 'text/html');
					var decodedString = dom.body.textContent;
					 elSel.options[i].text = decodedString;
					 elSel.options[i].value = decodedString; 
			  }
			  else if(arritems[i] !== undefined){
				   elSel.options[i].text =arritems[i];
				   elSel.options[i].value =arritems[i];
			  }else{
			  	elSel.remove(i);
		     }
		  }
		  //HCL Add END_SORTING_CR_1
		}
	,
	removeOptions:function (elementId){
		if(document.getElementById(elementId)){
			var elSel = document.getElementById(elementId);
			var i;
			  
			for (i = elSel.length - 1; i>0; i--)
				elSel.remove(i);
		}
	},
	
	/**
	 * 
	 *  HCL Add START_SORTING_CR_1_DATED_02.09.12 : 
	 *  
	 *  This function is used to sort the Attribute values in PDP ,Quick info popup  .
	 *   Array of attribute values is passed for sorting  from addOption function 
	 *   
	 *   
	 */ 
	numberSorter:function (as,bs){
		var a, b, a1, b1, i= 0, L, rx=  /(\d+)|(\D+)/g, rd=  /\d/;
	    if(isFinite(as) && isFinite(bs)) return as - bs;
	    a= String(as).toLowerCase();
	    b= String(bs).toLowerCase();
	    if(a=== b) return 0;
	    if(!(rd.test(a) && rd.test(b))) return a> b? 1:-1;
	    a= a.match(rx);
	    b= b.match(rx);
	    L= a.length> b.length? b.length:a.length;
	    while(i<L){
	        a1= a[i];
	        b1= b[i++];
	        if(a1!== b1){
	            if(isFinite(a1) && isFinite(b1)){
	                if(a1.charAt(0)=== '0') a1= '.' + a1;
	                if(b1.charAt(0)=== '0') b1= '.' + b1;
	                return a1 - b1;
	            }
	            else return a1> b1? 1:-1;
	        }
	    }
	    return a.length - b.length;

		},
		
	

	/**
	* updateParamObject This function updates the given params object with a key to value pair mapping.
	*				    If the toArray value is true, It creates an Array for duplicate entries otherwise it overwrites the old value.
	*			        This is useful while making a service call which accepts a few parameters of type array.
	*					This function is used to prepare a a map of parameters which can be passed to XMLHttpRequests. 
	* 					The keys in this parameter map will be the name of the parameter to send and the value is the corresponding value for each parameter key.
	* @param {Object} params The parameters object to add name value pairs to.
	* @param {String} key The new key to add.
	* @param {String} value The new value to add to the specified key.
	* @param {Boolean} toArray Set to true to turn duplicate keys into an array, or false to override previous values for a specified key.
	* @param {int} index The index in an array of values for a specified key in which to place a new value.
	*
	* @return {Object} params A parameters object holding name value pairs.
	*
	**/
	updateParamObject:function(params, key, value, toArray, index){
	
	   if(params == null){
		   params = [];
	   }

	   if(params[key] != null && toArray)
	   {
			if(dojo.lang.isArrayLike(params[key]))
			{
				//3rd time onwards
			    if(index != null && index != "")
				{
					//overwrite the old value at specified index
				     params[key][index] = value;
				}
				else
				{
				    params[key].push(value);
			     }
		    }
			else
			{
			     //2nd time
			     var tmpValue = params[key];
			     params[key] = [];
			     params[key].push(tmpValue);
			     params[key].push(value);
		    }
	   }
	   else
	   {
			//1st time
		   if(index != null && index != "" && index != -1)
		   {
		      //overwrite the old value at specified index
		      params[key+"_"+index] = value;
		   }
		   else if(index == -1)
		   {
		      var i = 1;
		      while(params[key + "_" + i] != null)
			  {
			       i++;
		      }
		      params[key + "_" + i] = value;
		   }
		   else
		   {
		      params[key] = value;
		    }
	   }
	   return params;
	 },
	 
	 /**
	  *  This function associates the product id with its first entitledItemId.
	  *  @param {String} productId The id of the product.
	  *  @param {String} entitledItemId The id of the first entitledItem of the product.
	  */
	 setDefaultItem : function(productId,entitledItemId){
		this.defaultItemArray[productId] = entitledItemId;
		
},
	/*
     *	This function retrieves the first entitledItemId of the product.
	 *  @param {String} productId The id of the product.
	 *  
	 *  @return {String} The id of the first entitledItem of the product.
	 */
getDefaultItem : function(productId){
		return this.defaultItemArray[productId];
},


	/**
	* AddBundle2ShopCartAjax This function is used to add a bundle to the shopping cart. This is for the ajax flow which will take a form as input and retrieves all the items catentry IDs and adds them to the form.
	*						 
	* @param {form} form The form which contains all the inputs for the bundle.
	*					 The form is expected to have the following values: 
	*						numberOfProducts The number of products in the bundle.
	*						catEntryId_<index> where index is between 1 and numberOfProduct.
	*						quantity_<index> where index is between 1 and numberOfProduct.
	**/
	AddBundle2ShopCartAjax : function(form){
		
		var params = [];
		//var queryString = dojo.io.encodeForm(dojo.byId(form));

		params.storeId		= this.storeId;
		params.catalogId	= this.catalogId;
		params.langId		= this.langId;
		params.orderId		= ".";
		params.calculationUsage = "-1,-2,-3,-4,-5,-6,-7";
			
		var productCount = form["numberOfProduct"].value;
		for(var i = 1; i <= productCount; i++){
			var catEntryId = form["catEntryId_" + i].value;
			if(this.selectedProducts[catEntryId])
				catEntryId = this.getCatalogEntryIdforProduct(this.selectedProducts[catEntryId]);
			var qty = form["quantity_" + i].value;
			if(qty == null || qty == "" || qty<=0){ MessageHelper.displayErrorMessage(MessageHelper.messages['QUANTITY_INPUT_ERROR']); return;}
			if(qty!=null && qty!='' && catEntryId!=null){
				this.updateParamObject(params,"catEntryId",catEntryId,false,-1);
				this.updateParamObject(params,"quantity",qty,false,-1);
				this.baseItemAddedToCart=true;
			}
			else{
				MessageHelper.displayErrorMessage(MessageHelper.messages['ERR_RESOLVING_SKU']);
				return;
			}
			var contractIdElements = document.getElementsByName('contractSelectForm_contractId_' + catEntryId);
			if (contractIdElements != null && contractIdElements != "undefined") {
				for (j=0; j<contractIdElements.length; j++) {
					if (contractIdElements[j].checked) {
						form["contractId_" + i].value = contractIdElements[j].value;
						break;
					}
				}
			}
			var contractId = form["contractId_" + i].value;
			if (contractId != null && contractId != '') {
				this.updateParamObject(params,"contractId",contractId,false,-1);
			}
		}
		//For Handling multiple clicks
		if(!submitRequest()){
			return;
		}   		
		cursor_wait();		
		wc.service.invoke("AjaxAddOrderItem", params);

	},


	/**
	* AddBundle2ShopCart This function is used to add a bundle to the shopping cart. This is for the non ajax flow which  will take a form as input and submits the form.
	*
	* @param {form} form The form which contains all the inputs for the bundle.
	*					 The form is expected to have the following values:
	*						numberOfProducts The number of products in the bundle.
	*						catEntryId_<index> where index is between 1 and numberOfProduct.
	*						quantity_<index> where index is between 1 and numberOfProduct. 
	*
	**/
	AddBundle2ShopCart : function(form){
		
		form.URL.value = "AjaxOrderItemDisplayView";
		var productCount = form["numberOfProduct"].value;
		for(var i = 1; i <= productCount; i++){
			var catEntryId = form["catEntryId_" + i].value;
			if(this.selectedProducts[catEntryId]){
				catEntryId = this.getCatalogEntryIdforProduct(this.selectedProducts[catEntryId]);
				if(catEntryId != null)
				form["catEntryId_" + i].value = catEntryId;
				else{
					MessageHelper.displayErrorMessage(MessageHelper.messages['ERR_RESOLVING_SKU']);
					return;
				}
			}
			var qty = form["quantity_" + i].value;
			if(qty == null || qty == "" || qty<=0){ MessageHelper.displayErrorMessage(MessageHelper.messages['QUANTITY_INPUT_ERROR']); return;}
			var contractIdElements = document.getElementsByName('contractSelectForm_contractId_' + catEntryId);
			if (contractIdElements != null && contractIdElements != "undefined") {
				for (j=0; j<contractIdElements.length; j++) {
					if (contractIdElements[j].checked) {
						form["contractId_" + i].value = contractIdElements[j].value;
						break;
					}
				}
			}
		}
		
		//For Handling multiple clicks
		if(!submitRequest()){
			return;
		}
		
		form.submit();
	},
	
	
	/**
	* Add2ShopCart This function is used to add to a catalog entry to the shopping cart. This will resolve the catentryId using entitledItemId and adds the item to the cart.
	*			   This function will call AddItem2ShopCart after resolving the entitledItemId to a SKU.
	*
	* @param {String} entitledItemId A DIV containing a JSON object which holds information about a catalog entry. You can reference CachedProductOnlyDisplay.jsp to see how that div is constructed.
	* @param {form} form The form which contains all the inputs for the item. The catEntryId and productId values of the form you pass in
	*					 will be set to the catalog entry Id of the SKU resolved from the list of skus whos defining attributes match those in the {@link fastFinderJS.selectedAttributes} array.
	* @param {int} quantity quantity of the item.
	* @param {String} isPopup If the value is true, then this implies that the function was called from a quick info pop-up.				
	*
	**/
	Add2ShopCart : function(entitledItemId,form,quantity,isPopup){
		var entitledItemJSON;

		if (dojo.byId(entitledItemId)!=null) {
			//the json object for entitled items are already in the HTML. 
			 entitledItemJSON = eval('('+ dojo.byId(entitledItemId).innerHTML +')');
		}else{
			//if dojo.byId(entitledItemId) is null, that means there's no <div> in the HTML that contains the JSON object. 
			//in this case, it must have been set in catalogentryThumbnailDisplay.js when the quick info
			entitledItemJSON = this.getEntitledItemJsonObject(); 
		}
		
		this.setEntitledItems(entitledItemJSON);
		var catalogEntryId = this.getCatalogEntryId();
		if(catalogEntryId!=null){
			if(this.merchandisingProductAssociationAddToCart){
				this.AddAssociation2ShopCart(catalogEntryId,quantity);
				return;
			}
			form.catEntryId.value = catalogEntryId;
			form.productId.value = catalogEntryId;
			this.AddItem2ShopCart(form,quantity);
			hidePopup('second_level_category_popup');
		} else if (isPopup == true){
			dojo.byId('second_level_category_popup').style.zIndex = '1';
			MessageHelper.formErrorHandleClient('addToCartLink', MessageHelper.messages['ERR_RESOLVING_SKU']);		
		} else{
			MessageHelper.displayErrorMessage(MessageHelper.messages['ERR_RESOLVING_SKU']);
		}

	},
	
	
	
	/**
	* AddItem2ShopCart This function is used to add a SKU to the shopping cart.
	*
	* @param {form} form The form which contains all the inputs for the item.
    * 					The form must have the following values:
    *						quantity The quantity of the item that you want to add to the cart.
	* @param {int} quantity The quantity of the item to add to the shopping cart.
	*
	**/
	AddItem2ShopCart : function(form,quantity){
		if(!isPositiveInteger(quantity)){
			MessageHelper.displayErrorMessage(MessageHelper.messages['QUANTITY_INPUT_ERROR']);
			return;
		}
		
		form.quantity.value = quantity;
		
		var contractIdElements = document.getElementsByName('contractSelectForm_contractId');
		if (contractIdElements != null && contractIdElements != "undefined") {
			for (i=0; i<contractIdElements.length; i++) {
				if (contractIdElements[i].checked) {
					form.contractId.value = contractIdElements[i].value;
					break;
				}
			}
		}
		//For Handling multiple clicks
		if(!submitRequest()){
			return;
		}
		
		form.submit();
	},


	/**
	* Add2ShopCartAjax This function is used to add a catalog entry to the shopping cart using an AJAX call. This will resolve the catentryId using entitledItemId and adds the item to the cart.
	*				This function will resolve the SKU based on the entitledItemId passed in and call {@link fastFinderJS.AddItem2ShopCartAjax}.
	* @param {String} entitledItemId A DIV containing a JSON object which holds information about a catalog entry. You can reference CachedProductOnlyDisplay.jsp to see how that div is constructed.
	* @param {int} quantity The quantity of the item to add to the cart.
	* @param {String} isPopup If the value is true, then this implies that the function was called from a quick info pop-up. 	
	* @param {Object} customParams - Any additional parameters that needs to be passed during service invocation.
	*
	**/
	Add2ShopCartAjax : function(entitledItemId,quantity,isPopup,customParams)
	{	
		var entitledItemJSON;

		if (dojo.byId(entitledItemId)!=null) {
			//the json object for entitled items are already in the HTML. 
			 entitledItemJSON = eval('('+ dojo.byId(entitledItemId).innerHTML +')');
		}else{
			//if dojo.byId(entitledItemId) is null, that means there's no <div> in the HTML that contains the JSON object. 
			//in this case, it must have been set in catalogentryThumbnailDisplay.js when the quick info
			entitledItemJSON = this.getEntitledItemJsonObject(); 
		}
		
		this.setEntitledItems(entitledItemJSON);
		var catalogEntryId = this.getCatalogEntryId();
		if(catalogEntryId!=null){
			this.AddItem2ShopCartAjax(catalogEntryId , quantity,customParams);
			this.baseItemAddedToCart=true;
			hidePopup('second_level_category_popup');
		}
		else if (isPopup == true){
			dojo.byId('second_level_category_popup').style.zIndex = '1';
			MessageHelper.formErrorHandleClient('addToCartLinkAjax', MessageHelper.messages['ERR_RESOLVING_SKU']);			
		} else{
			MessageHelper.displayErrorMessage(MessageHelper.messages['ERR_RESOLVING_SKU']);
			this.baseItemAddedToCart=false;
		}
	},
	
	
	/**
	* EmailProductAjax This function is used to email the Product detail page.
	* @param {String} First Name
	* @param {String} Last Name
	* @param {String} Recipient Email Id. 	
	*
	**/
	EmailProductAjax : function(){
		var parameters = {};
		
		var toFName = $('#toFName').val();
		var toLName = $('#toLName').val();
		var toEmail = $('#toEmail').val();

		var fromFName = $('#fromFName').val();
		var fromLName = $('#fromLName').val();
		var fromEmail = $('#fromEmail').val();
		
		var messageToSend = $('#messageToSend').val();
		
		var prodNameForEmail = $('#productNameForEmail').val();
		var prodPageUrlForEmail = $('#pageurlForEmail').val();
		var productEmailSubjectToIntialColleague = $('#productEmailSubjectToIntialColleague').val();
		var productEmailSubjectToColleague = $('#productEmailSubjectToColleague').val();
		var productEmailSubjectToSelf = $('#productEmailSubjectToSelf').val();
		
		var contactParkerHref = $('#contactParkerHref').attr("href");
		var prodNameForEmail = $('#productNameForEmail').val();
		var prodPageUrlForEmail = $('#pageurlForEmail').val();
		var productEmailSubjectToIntialColleague = $('#productEmailSubjectToIntialColleague').val();
		var productEmailSubjectToColleague = $('#productEmailSubjectToColleague').val();
		var productEmailSubjectToSelf = $('#productEmailSubjectToSelf').val();
		
		parameters.toFName = toFName;
		parameters.toLName= toLName;
		parameters.toEmail= toEmail;

		parameters.fromFName = fromFName;
		parameters.fromLName= fromLName;
		parameters.fromEmail= fromEmail;

		parameters.emailMessage= messageToSend;
		

		parameters.prodNameForEmail= prodNameForEmail;
		parameters.prodPageUrlForEmail= prodPageUrlForEmail;
		parameters.productEmailSubjectToIntialColleague= productEmailSubjectToIntialColleague;
		parameters.productEmailSubjectToColleague= productEmailSubjectToColleague;
		parameters.productEmailSubjectToSelf= productEmailSubjectToSelf;
		parameters.contactParkerHref = contactParkerHref;
		
		cursor_wait();		
		wc.service.invoke("AjaxEmailProductForDistributorFullfillment", parameters);
	},
    
	/**
	 * sets the entitledItemJsonObject
	 * @param (object) jsonObject the entitled item JSON objects
	 */
    setEntitledItemJsonObject: function(jsonObject) {
        this.entitledItemJsonObject = jsonObject;
    },
    
    /**
     * retrieves the entitledItemJsonObject
     */
    getEntitledItemJsonObject: function () {
    	return this.entitledItemJsonObject;
    },

	/**
	* ReplaceItemAjax This function is used to replace an item in the shopping cart when the AJAX Checkout flow is enabled. This will be called from the shopping cart and checkout pages.
	*
	* @param {String} entitledItemId A DIV containing a JSON object which holds information about a catalog entry. You can reference CachedProductOnlyDisplay.jsp to see how that div is constructed.
	* @param {int} quantity The quantity of the item to add to the shopping cart.
	*
	**/
	ReplaceItemAjax : function(entitledItemId,quantity){
	
		var entitledItemJSON;

		if (dojo.byId(entitledItemId)!=null) {
			//the json object for entitled items are already in the HTML. 
			 entitledItemJSON = eval('('+ dojo.byId(entitledItemId).innerHTML +')');
		}else{
			//if dojo.byId(entitledItemId) is null, that means there's no <div> in the HTML that contains the JSON object. 
			//in this case, it must have been set in catalogentryThumbnailDisplay.js when the quick info
			entitledItemJSON = this.getEntitledItemJsonObject(); 
		}
		this.setEntitledItems(entitledItemJSON);
		var catalogEntryId = this.getCatalogEntryId();
		var removeOrderItemId = "";
		//if(entitledItemJSON[0] != null){
		//	removeOrderItemId = entitledItemJSON[0].orderItemId_remove;
		//}
		var removeOrderItemId = replaceOrderItemId;
		var typeId = document.getElementById("shipmentTypeId");
		var addressId = "";
		var shipModeId = "";
		if(typeId != null && typeId != ""){
			if(typeId.value == "2"){
				//Multiple shipment..each orderItem will have its own addressId and shipModeId..
				addressId = document.getElementById("MS_ShipmentAddress_"+removeOrderItemId).value;
				shipModeId = document.getElementById("MS_ShippingMode_"+removeOrderItemId).value;
			}
			else {
				//Single Shipment..get the common addressId and shipModeId..
				addressId = document.getElementById("addressId_all").value;
				shipModeId = document.getElementById("shipModeId_all").value;
			}
		}
		if(catalogEntryId!=null){
			if(removeOrderItemId == ""){
				//Just add new catentryId to shop cart in ajax way, since this is AjaxCheckout page
				//This code will never be executed, since we dont have Add To Cart link..
				/*var params = [];
				params.storeId		= this.storeId;
				params.catalogId	= this.catalogId;
				params.langId			= this.langId;
				params.orderId		= ".";
				params.catEntryId	= catalogEntryId;
				params.quantity		= quantity;
				params.addressId = addressId;
				params.shipModeId = shipModeId;
				wc.service.invoke("AjaxAddOrderItem", params);
				*/
			}
			else{
				//Else remove existing catEntryId and then add new one...
				this.ReplaceItemAjaxHelper(catalogEntryId,quantity,removeOrderItemId,addressId,shipModeId);
			}
		}
		else{
				MessageHelper.displayErrorMessage(MessageHelper.messages['ERR_RESOLVING_SKU']);
		}
	},

	/**
	* ReplaceItemNonAjax This function is used to replace an item in the shopping cart when the Non Ajax checkout flow is enabled. This will be called from shopcart and checkout pages.
	* 
	* @param {String} entitledItemId A DIV containing a JSON object which holds information about a catalog entry. You can reference CachedProductOnlyDisplay.jsp to see how that div is constructed.
	* @param {int} quantity The quantity of the item to replace in the shopping cart.
	* @param {form} form The form which contains all the inputs for the item.
	*
	**/ 
	ReplaceItemNonAjax : function(entitledItemId,quantity,form){
	
		var entitledItemJSON;
		if (dojo.byId(entitledItemId)!=null) {
			//the json object for entitled items are already in the HTML. 
			 entitledItemJSON = eval('('+ dojo.byId(entitledItemId).innerHTML +')');
		}else{
			//if dojo.byId(entitledItemId) is null, that means there's no <div> in the HTML that contains the JSON object. 
			//in this case, it must have been set in catalogentryThumbnailDisplay.js when the quick info
			entitledItemJSON = this.getEntitledItemJsonObject(); 
		}
		this.setEntitledItems(entitledItemJSON);
		var catalogEntryId = this.getCatalogEntryId();
		var removeOrderItemId = "";
		//if(entitledItemJSON[0] != null){
		//	removeOrderItemId = entitledItemJSON[0].orderItemId_remove;
		//}
		var removeOrderItemId = replaceOrderItemId;
		if(catalogEntryId!=null){
			if(removeOrderItemId == ""){
				//Prepare form to just add this item.. This code will never be executed...
				//Needed only when we plan to show add to cart link also in the quick info..
				//form.action = "orderChangeServiceItemAdd";
				//form.submit();
			}
			else{
				//Else remove existing catEntryId and then add new one...
				form.orderItemId.value = removeOrderItemId;
				var addressId, shipModeId;
				if(quantity == 0){
					console.debug("An invalid quantity was selected");

				}
				if(form.shipmentTypeId != null && form.shipmenTypeId != ""){
					if(form.shipmentTypeId.value == "2"){
						//Multiple shipment..each orderItem will have its own addressId and shipModeId..
						addressId = document.getElementById("MS_ShipmentAddress_"+removeOrderItemId).value;;
						shipModeId = document.getElementById("MS_ShippingMode_"+removeOrderItemId).value;;
					}
					else {
						//Single Shipment..get the common addressId and shipModeId..
						addressId = document.getElementById("addressId_all").value;
						shipModeId = document.getElementById("shipModeId_all").value;
					}
					form.URL.value = "OrderChangeServiceItemAdd?calculationUsage=-1,-2,-3,-4,-5,-6,-7&catEntryId="+catalogEntryId+"&quantity="+quantity+"&addressId="+addressId+"&shipModeId="+shipModeId+"&URL=OrderChangeServiceShipInfoUpdate?URL="+form.URL.value;
			    }
				else{
					form.URL.value = "OrderChangeServiceItemAdd?calculationUsage=-1,-2,-3,-4,-5,-6,-7&catEntryId="+catalogEntryId+"&quantity="+quantity+"&URL="+form.URL.value;
				}

				//For Handling multiple clicks
				if(!submitRequest()){
					return;
				}
				
				form.submit();
			}
		}
		else{
			MessageHelper.displayErrorMessage(MessageHelper.messages['ERR_RESOLVING_SKU']);
		}
	},

	/**
	* AddItem2ShopCartAjax This function is used to add a single or multiple items to the shopping cart using an ajax call.
							If an array is passed for catEntryIdentifier and quantity parramters, then multiple items can be added.	In this case, catEntryIdentifier[i] corresponds to quantity[i]
							Else, catEntryIdentifier  and quantity parameters represent a single catalog entry.
	*
	* @param {Array|String} catEntryIdentifier An array of catalog entry identifiers or a single catalog entry ID of the item to add to the cart.
	* @param {Array|int} quantity An array of quantities corresponding to the catEntryIdentifier array or a single quantity of the item to add to the cart.
	* @param {Object} customParams - Any additional parameters that needs to be passed during service invocation.
	*
	**/
	AddItem2ShopCartAjax : function(catEntryIdentifier, quantity, customParams)
	{
		
		var params = [];
		params.storeId		= this.storeId;
		params.catalogId	= this.catalogId;
		params.langId		= this.langId;
		params.orderId		= ".";
		params.calculationUsage = "-1";
		if (document.getElementById("parentCatID") != null
				&& document.getElementById("parentCatID") != 'undefined') {
			params.parentCatID = document.getElementById("parentCatID").value;
		}
		if (document.getElementById("xmlResponseKey") != null
				&& document.getElementById("xmlResponseKey") != 'undefined') {
			params.xmlResponseKey = document.getElementById("xmlResponseKey").value;
		}
		if (document.getElementById("isConfigItem") != null
				&& document.getElementById("isConfigItem") != 'undefined') {
			params.isConfigItem = document.getElementById("isConfigItem").value;
		}
		if (document.getElementById("leadTimeAvailability") != null && document.getElementById("leadTimeAvailability") != 'undefined'
            	&& document.getElementById("leadTimeAvailability").value != 'undefined'&& document.getElementById("leadTimeAvailability").value != '') {
			params.leadTime = document.getElementById("leadTimeAvailability").value;
		}
		if (document.getElementById("orderItemType") != null && document.getElementById("orderItemType") != 'undefined') {
			params.lineItemType = document.getElementById("orderItemType").value;
		}
   	    if (document.getElementById("participantDetails") != null && document.getElementById("participantDetails") != 'undefined') {
			params.participantDetails = document.getElementById("participantDetails").value;
		}
		var flag=true;
		var maxAllowedQty=0;

		for (x in this.entitledItems) {
			  if(this.entitledItems[x].catentry_id==catEntryIdentifier)
			  {
				  var maxqty = this.entitledItems[x].maxAllowedQuantity;
			      if(flag)
			      {
			    	maxAllowedQty=maxqty;
			      }
			    flag=false;
			}
		}

		/*if (document.getElementById("itemMaxQty") != null && document.getElementById("itemMaxQty") != 'undefined') {
				var maxqty = document.getElementById("itemMaxQty").value;
		}*/
		//Code when we are not getting any JSON object from CachedItemDisplay and customParams contains the maximum qty that can be added
		if(maxAllowedQty==0&&customParams!='undefined'&&customParams!=''&&customParams!=0){
			maxAllowedQty=customParams;
		}
		//No need to check quantity at client side
		/*if (maxAllowedQty != null && maxAllowedQty < quantity){		
			MessageHelper.displayErrorMessage(MessageHelper.messages['QUANTITY_MAX_ERROR'] + ' ' + maxAllowedQty);
			return; 
		}*/
		if(dojo.isArray(catEntryIdentifier) && dojo.isArray(quantity)){
			for(var i=0; i<catEntryIdentifier.length; i++){
				if(!isPositiveInteger(quantity[i])){
					MessageHelper.displayErrorMessage(MessageHelper.messages['QUANTITY_INPUT_ERROR']);
					return;
				}
				params["catEntryId_" + (i+1)] = catEntryIdentifier[i];
				params["quantity_" + (i+1)]	= quantity[i];
			}
		}
		else{
			if(!isPositiveInteger(quantity)){
				MessageHelper.displayErrorMessage(MessageHelper.messages['QUANTITY_INPUT_ERROR']);
				return;
			}
			params.catEntryId	= catEntryIdentifier;
			params.quantity		= quantity;
		}		

		//Pass any other customParams set by other add on features
		if(customParams != null && customParams != 'undefined'){
			
			for(i in customParams){
				params[i] = customParams[i];
			}			
		}

		var contractIdElements = document.getElementsByName('contractSelectForm_contractId');
		if (contractIdElements != null && contractIdElements != "undefined") {
			for (i=0; i<contractIdElements.length; i++) {
				if (contractIdElements[i].checked) {
					params.contractId = contractIdElements[i].value;
					break;
				}
			}
		}
		
		//For Handling multiple clicks
		if(!submitRequest()){
			return;
		}   
		cursor_wait();		
		if(this.ajaxShopCart){
			var cartCookieStatus = this.checkHeaderCartCookie(quantity);
			if(!cartCookieStatus){
				this.createHeaderCartCookie(quantity);
			}

			wc.service.invoke("AjaxAddOrderItem", params);
			this.baseItemAddedToCart=true;
		}else{
			wc.service.invoke("AjaxAddOrderItem_shopCart", params);
			this.baseItemAddedToCart=true;
		}
		if(document.getElementById("headerShopCartLink")&&document.getElementById("headerShopCartLink").style.display != "none")
		{
			//JSRSunilP. Do nothing as this is always hidden.
			//document.getElementById("headerShopCart").focus();
		}
		else
		{
			if(document.getElementById("headerShopCart1")){
				document.getElementById("headerShopCart1").focus();
			}
		}
		
		var reorderModels = document.getElementsByName("reorderModel");
		var counter;
		for (counter = 0; counter < reorderModels.length; counter++) {
			reorderModels[counter].style.display = "none";
		}

	},
	
	/**
	* ReplaceItemAjaxHelper This function is used to replace an item in the cart. This will be called from the {@link fastFinderJS.ReplaceItemAjax} method.
	*
	* @param {String} catalogEntryId The catalog entry of the item to replace to the cart.
	* @param {int} qty The quantity of the item to add.
	* @param {String} removeOrderItemId The order item ID of the catalog entry to remove from the cart.
	* @param {String} addressId The address ID of the order item.
	* @param {String} shipModeId The shipModeId of the order item.
	*
	**/
	ReplaceItemAjaxHelper : function(catalogEntryId,qty,removeOrderItemId,addressId,shipModeId){
		
		var params = [];
		params.storeId = this.storeId;
		params.catalogId = this.catalogId;
		params.langId = this.langId;
		params.orderItemId	= removeOrderItemId;
		params.orderId = (this.orderId != null && this.orderId != 'undefined' && this.orderId != '')?this.orderId:".";
		params.calculationUsage = "-1,-2,-3,-4,-5,-6,-7";

		var params2 = [];
		params2.storeId = this.storeId;
		params2.catalogId = this.catalogId;
		params2.langId = this.langId;
		params2.catEntryId	= catalogEntryId;
		params2.quantity = qty;
		params2.orderId = (this.orderId != null && this.orderId != 'undefined' && this.orderId != '')?this.orderId:".";
		params2.calculationUsage = "-1,-2,-3,-4,-5,-6,-7";

		var params3 = [];
		params3.storeId = this.storeId;
		params3.catalogId = this.catalogId;
		params3.langId = this.langId;
		params3.orderId = (this.orderId != null && this.orderId != 'undefined' && this.orderId != '')?this.orderId:".";
		params3.calculationUsage = "-1,-2,-3,-4,-5,-6,-7";
		params3.allocate="***";
		params3.backorder="***";
		params3.remerge="***";
		params3.check="*n";
		
		var shipInfoUpdateNeeded = false;
		if(addressId != null && addressId != "" && shipModeId != null && shipModeId != ""){
			params3.addressId = addressId;
			params3.shipModeId = shipModeId;
			shipInfoUpdateNeeded = true;
		}

		//Delcare service for deleting item...
		wc.service.declare({
			id: "AjaxReplaceItem",
			actionId: "AjaxReplaceItem",
			url: "AjaxOrderChangeServiceItemDelete",
			formId: ""

			,successHandler: function(serviceResponse) {
				//Now add the new item to cart..
				if(!shipInfoUpdateNeeded){
					//We dont plan to update addressId and shipMOdeId..so call AjaxAddOrderItem..
					wc.service.invoke("AjaxAddOrderItem", params2);
				}
				else{
					//We need to update the adderessId and shipModeId..so call our temp service to add..
					wc.service.invoke("AjaxAddOrderItemTemp", params2);
				}
			}

			,failureHandler: function(serviceResponse) {
				if (serviceResponse.errorMessage) {
							 MessageHelper.displayErrorMessage(serviceResponse.errorMessage);
					  } else {
							 if (serviceResponse.errorMessageKey) {
									MessageHelper.displayErrorMessage(serviceResponse.errorMessageKey);
							 }
					  }
					  cursor_clear();
			}

		});

		//Delcare service for adding item..
		wc.service.declare({
			id: "AjaxAddOrderItemTemp",
			actionId: "AjaxAddOrderItemTemp",
			url: "AjaxOrderChangeServiceItemAdd",
			formId: ""

			,successHandler: function(serviceResponse) {
				//Now item is added.. call update to set addressId and shipModeId...
				wc.service.invoke("OrderItemAddressShipMethodUpdate", params3);
			}

			,failureHandler: function(serviceResponse) {
				MessageHelper.displayErrorMessage(serviceResponse.errorMessageKey);
			}
		});

		//For Handling multiple clicks
		if(!submitRequest()){
			return;
		}   
		cursor_wait();
		wc.service.invoke("AjaxReplaceItem",params);
	},
		
	/**
	* AddBundle2WishList This function is used to add a bundle to the wish list and it can be called by the product/bundle/package details pages.
	*
	* @param {form} form The form which contains all the inputs for the bundle.
	*
	**/	
	AddBundle2WishList : function(form){
		if (!isAuthenticated) { 
			setWarningMessageCookie('WISHLIST_GUEST_ADDITEM');
		}
		var productCount = form["numberOfProduct"].value; 
		for(var i = 1; i <= productCount; i++){
			var catEntryId = form["catEntryId_" + i].value;
			if(this.selectedProducts[catEntryId]){
				catEntryId = this.getCatalogEntryIdforProduct(this.selectedProducts[catEntryId]);
				if(catEntryId != null)
				form["catEntryId_" + i].value = catEntryId;
				else{
					MessageHelper.displayErrorMessage(MessageHelper.messages['ERR_RESOLVING_SKU']);
					return;
				}
			}
		}
			form.action="InterestItemAdd";
			form.page.value="customerlinkwishlist";
		if (this.ajaxMyAccount){
			if(this.userType=='G'){
				form.URL.value='InterestItemDisplay';
			}else {
				form.URL.value='AjaxLogonForm';
			}
		}else{
			if(this.userType=='G'){
				form.URL.value='InterestItemDisplay';
			}else {
				form.URL.value='NonAjaxAccountWishListDisplayView';
			}
		}
		//For Handling multiple clicks
		if(!submitRequest()){
			return;
		}
		
		form.submit();
	},
	
	/**
	* AddBundle2WishListAjax This fuction is used to add a bundle to the wish list using the ajax flow and it is called by the product/bundle/package details pages.
	*
	* @param {form} form The form which contains all the inputs for the bundle.
	*
	**/
	AddBundle2WishListAjax : function(form){
		if (!isAuthenticated) { 
			setWarningMessageCookie('WISHLIST_GUEST_ADDITEM');
		}
		var params = [];
		//var queryString = dojo.io.encodeForm(dojo.byId(form));

		params.storeId		= this.storeId;
		params.catalogId	= this.catalogId;
		params.langId		= this.langId;
		params.updateable	= 0;
		params.orderId		= ".";
			
		var catEntryArray = [];
		catEntryArray = form.catEntryIDS.value.toString().split(",");
		
		for(var i = 0; i < catEntryArray.length; i++){
			var qty = document.getElementById("quantity_" + catEntryArray[i]).value;
			var catEntryId = catEntryArray[i];
			if(this.selectedProducts[catEntryArray[i]])
				catEntryId = this.getCatalogEntryIdforProduct(this.selectedProducts[catEntryArray[i]]);
			if(qty==0 || qty == null) qty = 1;
			if(qty!=null && qty!='' && catEntryId!=null){
				this.updateParamObject(params,"catEntryId",catEntryId,false,-1);
				this.updateParamObject(params,"quantity",qty,false,-1);
			}
			else{
				MessageHelper.displayErrorMessage(MessageHelper.messages['ERR_RESOLVING_SKU']);
				return;
			}
		}
		//For Handling multiple clicks
		if(!submitRequest()){
			return;
		}   		
		cursor_wait();		
		wc.service.invoke("AjaxInterestItemAdd", params);

	},
	
	/**
	* Add2WishListAjaxByID. This function is used to add a catalog entry to the wish list using ajax by passing in a catalog entry ID.
	*
	* @param {int} catalogEntryId The catalog entry ID of the catalog entry.
	*
	**/
	Add2WishListAjaxByID:function(catalogEntryId)
	{
		if(catalogEntryId!=null){
			if (!isAuthenticated) { 
				setWarningMessageCookie('WISHLIST_GUEST_ADDITEM');
			}
			var params = [];
			params.storeId		= this.storeId;
			params.catalogId	= this.catalogId;
			params.langId			= this.langId;
			params.catEntryId	= catalogEntryId;
			params.updateable	= 0;
			params.URL = "SuccessfulAJAXRequest";
			if(document.getElementById("controllerURLWishlist")!=null && document.getElementById("controllerURLWishlist")!='undefined')
					CommonControllersDeclarationJS.setControllerURL("WishlistDisplay_Controller",document.getElementById("controllerURLWishlist").value);

			//For Handling multiple clicks
			if(!submitRequest()){
				return;
			}   
			cursor_wait();			
			if(this.ajaxShopCart)
				wc.service.invoke("AjaxInterestItemAdd", params);
			else
				wc.service.invoke("AjaxInterestItemAdd_shopCart", params);
		}
		else MessageHelper.displayErrorMessage(MessageHelper.messages['ERR_RESOLVING_SKU']);
	},
	
	/**
	* Add2WishListAjax This function is used to add an item to the wishlist using ajax by passing in the id of an HTML element containing a JSON object representing a catalog entry.
	*				   This fuction is called by product/bundle/package detail pages.
	* 
	* @param {HTMLDivElement} entitledItemId A DIV containing a JSON object which holds information about a catalog entry. You can reference CachedProductOnlyDisplay.jsp to see how that div is constructed.
	*
	**/
	Add2WishListAjax:function(entitledItemId)
	{
		if (!isAuthenticated) { 
			setWarningMessageCookie('WISHLIST_GUEST_ADDITEM');
		}
		var entitledItemJSON;

		if (dojo.byId(entitledItemId)!=null) {
			//the json object for entitled items are already in the HTML. 
			 entitledItemJSON = eval('('+ dojo.byId(entitledItemId).innerHTML +')');
		}else{
			//if dojo.byId(entitledItemId) is null, that means there's no <div> in the HTML that contains the JSON object. 
			//in this case, it must have been set in catalogentryThumbnailDisplay.js when the quick info
			entitledItemJSON = this.getEntitledItemJsonObject(); 
		}
		this.setEntitledItems(entitledItemJSON);
		
		
		
		var catalogEntryId = this.getCatalogEntryId();
		
		this.Add2WishListAjaxByID(catalogEntryId);
		
	},
	
	/**
	* AddItem2WishListAjax. This function is used to add an item to the wishlist using AJAX by passing in its catentryId. 
	* 						This function can be called by item detail page.
	*
	* @param {String} itemId The catalog entry ID of the catalog entry to add to the wish list.
	*
	**/
	AddItem2WishListAjax:function(itemId)
	{
		if (!isAuthenticated) { 
			setWarningMessageCookie('WISHLIST_GUEST_ADDITEM');
		}
		var params = [];
		params.storeId		= this.storeId;
		params.catalogId	= this.catalogId;
		params.langId			= this.langId;
		params.catEntryId	= itemId;
		params.updateable	= 0;
		params.URL = "SuccessfulAJAXRequest";
		if(document.getElementById("controllerURLWishlist")!=null && document.getElementById("controllerURLWishlist")!='undefined')
					CommonControllersDeclarationJS.setControllerURL("WishlistDisplay_Controller",document.getElementById("controllerURLWishlist").value);

		//For Handling multiple clicks
		if(!submitRequest()){
			return;
		}   		
		cursor_wait();			
		if(this.ajaxShopCart)
			wc.service.invoke("AjaxInterestItemAdd", params);
		else
			wc.service.invoke("AjaxInterestItemAdd_shopCart", params);
	},

	/**
	* Add2WishList This function is used to add a catalog entry to the wish list using the non ajax flow by passing in the ID of an HTML element containing a JSON which represents a catalog entry 
	*			   This fuction is called by the product/bundle/package detail pages.
	*
	* @param {String} entitledItemId A DIV containing a JSON object which holds information about a catalog entry. You can reference CachedProductOnlyDisplay.jsp to see how that div is constructed.
	* @param {form} form form to submit the request.
	*
	**/
	Add2WishList:function(entitledItemId,form)
	{
		if (!isAuthenticated) { 
			setWarningMessageCookie('WISHLIST_GUEST_ADDITEM');
		}
		var entitledItemJSON;

		if (dojo.byId(entitledItemId)!=null) {
			//the json object for entitled items are already in the HTML. 
			 entitledItemJSON = eval('('+ dojo.byId(entitledItemId).innerHTML +')');
		}else{
			//if dojo.byId(entitledItemId) is null, that means there's no <div> in the HTML that contains the JSON object. 
			//in this case, it must have been set in catalogentryThumbnailDisplay.js when the quick info
			entitledItemJSON = this.getEntitledItemJsonObject(); 
		}
		this.setEntitledItems(entitledItemJSON);
		var catalogEntryId = this.getCatalogEntryId();
		this.Add2WishListByID(catalogEntryId,form);
	},


	/**
	* Add2WishListByID Add a catalog entry to the wish list using the non-AJAX flow. This fuction is called by the product/bundle/package detail pages.
	*
	* @param {String} catalogEntryId The catalog entry ID of the catalog entry to be added.
	* @param {form} form  form to submit the request.
	*
	**/
	Add2WishListByID:function(catalogEntryId,form)
	{
		if (!isAuthenticated) { 
			setWarningMessageCookie('WISHLIST_GUEST_ADDITEM');
		}
		if(catalogEntryId!=null){
			form.productId.value = catalogEntryId;
			form.catEntryId.value = catalogEntryId;
			form.action="InterestItemAdd";
			form.page.value="customerlinkwishlist";
		if (this.ajaxMyAccount){
			if(this.userType=='G'){
				form.URL.value='InterestItemDisplay';
			}else {
				form.URL.value='AjaxLogonForm';
			}
		}else{
			if(this.userType=='G'){
				form.URL.value='InterestItemDisplay';
			}else {
				form.URL.value='NonAjaxAccountWishListDisplayView';
			}
		}
			form.quantity.value = "1";
			
			//For Handling multiple clicks
			if(!submitRequest()){
				return;
			}
			
			form.submit();
		}
		else MessageHelper.displayErrorMessage(MessageHelper.messages['ERR_RESOLVING_SKU']);
	},
	
	
	/** 
	* AddItem2WishList Add a SKU to the wish list using the non-AJAX flow. This function is called by the item detail page.
	*
	* @param {form} form The form to submit the request.
	*
	**/
	AddItem2WishList:function(form)
	{
		if (!isAuthenticated) { 
			setWarningMessageCookie('WISHLIST_GUEST_ADDITEM');
		}
		form.action="InterestItemAdd"
		form.quantity.value = "1";
		form.page.value="customerlinkwishlist";
		if (this.ajaxMyAccount){
			if(this.userType=='G'){
				form.URL.value='InterestItemDisplay';
			}else {
				form.URL.value='AjaxLogonForm';
			}
		}else{
			if(this.userType=='G'){
				form.URL.value='InterestItemDisplay';
			}else {
				form.URL.value='NonAjaxAccountWishListDisplayView';
			}
		}
		//For Handling multiple clicks
		if(!submitRequest()){
			return;
		}
			
		form.submit();
	},
	
	/**
	* loadContentURL Sets the URL of the page to load into CategoryDisplay_Controller which in turn is used to display categories
	* 				 on the CategoryDisplay.jsp and DepartmentDisplay.jsp. The HistoryTracker is also updated.
	*
	* @param {String} contentURL The URL to load contents from.
	*
	**/
	loadContentURL:function(contentURL){
		
		//For Handling multiple clicks
		if(!submitRequest()){
			return;
		}   		
		cursor_wait();
		CommonControllersDeclarationJS.setControllerURL('CategoryDisplay_Controller',contentURL);		
		wc.render.updateContext("CategoryDisplay_Context");
	},
	
	
	/**
	* loadSubCategoryContentURL Sets the URL of the page to load into SubCategoryDisplay_Controller which in turn is used to display sub categories 
	* 							on the CategoryDisplay.jsp and DepartmentDisplay.jsp. The HistoryTracker is also updated.
	* 
	* @param {String} contentURL The URL to display for a sub category.
	*
	**/
	loadSubCategoryContentURL:function(contentURL){
		
		MessageHelper.hideAndClearMessage();

		//For Handling multiple clicks
		if(!submitRequest()){
			return;
		}   		
		cursor_wait();
		CommonControllersDeclarationJS.setControllerURL('SubCategoryDisplay_Controller',contentURL);	
		wc.render.updateContext("SubCategoryDisplay_Context");
	},
	
	/**
	* goBack Called when the back button is clicked in the browser. 
	*		 Uses the changeUrl set by the HistoryTracker and calls the loadContentURL method so that the state of the page get 
	* 		 loaded from a previous state in the page history.
	**/
	goBack:function(){
		
		categoryDisplayJS.loadContentURL(this.changeUrl);
		categoryDisplayJS.isHistory=true;

	},


	/**
	* goForward Called when the forward button is clicked in the browser. 
	*			Uses the changeUrl set by HistoryTracker and calls the loadContentURL method so that the state of the page gets
	*           loaded from the next available point in the page history.
	**/
	goForward:function(){
		
		categoryDisplayJS.loadContentURL(this.changeUrl);
		isHistory=true;
	},


	/**
	* HistoryTracker Used to track the history for the browser back and forward buttons.
	*
	* @param {String} elementId HistoryTracker id.
	* @param {String} changeUrl The change url of the current state.
	*
	**/
	HistoryTracker:function(elementId, changeUrl){
	
		this.elementId = elementId; 
		this.changeUrl =  changeUrl;

	},
	
	/**
	* processBookmarkURL Processes the bookmark using the bookmarkId which is stored in location.hash.
	**/
	processBookmarkURL : function(){
		
			var bookmarkId = location.hash;	
			if(bookmarkId){					        
				bookmarkId = bookmarkId.substring(1, bookmarkId.length);
			}   
			if(bookmarkId){
				var indexOfIdentifier = bookmarkId.indexOf("identifier", 0);
				if ( indexOfIdentifier >= 0) {
					var realUrl = bookmarkId.substring(0, indexOfIdentifier - 1);
				}
			}

			if(bookmarkId == null || bookmarkId == ""){

			}
	},
	
	
	/**
	* initializeMerchandisingAssociation Since the merchandising associations are only displayed one at a time with a scrolling widget this method
	*									 will initialize that widget with a specified starting index represented by thumbnailIndex so that the correct 
	*									 merchandising association is displayed first.
	*									 This function is called on MerchandisingAssociationsDisplay.jsp.s
	* 
	* @param {String} thumbnailIndex The index of the association that needs to be displayed.
	*
	**/
	initializeMerchandisingAssociation:function(thumbnailIndex){
	
	var associationDisplay = document.getElementById("marchandisingAssociationDisplay");
	var totalPriceMsg = document.getElementById("totalPriceMsg").value;
	var baseCatEntryJSON = eval('('+ dojo.byId("baseCatEntryDetails").innerHTML +')');
	this.baseCatalogEntryDetails = baseCatEntryJSON;
	var basePrice=this.baseCatalogEntryDetails[0].baseCatEntry_Price;
	this.totalAssociationCount= this.baseCatalogEntryDetails[0].totalAssociations;
	var identifierJSON = "associatedCatEntries_"+thumbnailIndex;
	var associationEntryJSON = eval('('+ dojo.byId(identifierJSON).innerHTML +')');
	this.merchandisingAssociationItems = associationEntryJSON;
	var totalPrice = parseFloat(basePrice)+ parseFloat(this.merchandisingAssociationItems[0].catEntry_Price);
	var dragType = "";
		
	if(this.merchandisingAssociationItems[0].catEntry_Type =='ProductBean'){
		dragType = "product";
	}else if (this.merchandisingAssociationItems[0].catEntry_Type =='ItemBean'){
		dragType = "item";
	}else if (this.merchandisingAssociationItems[0].catEntry_Type =='PackageBean'){
		dragType = "package";
	}else if (this.merchandisingAssociationItems[0].catEntry_Type =='BundleBean'){
		dragType = "bundle";
	}
//Creates the inner HTML of the associated item determined by the thumbnailIndex which needs to be displayed in the page.
var widgetHTML = "";
if(document.getElementById('addToCartLink')){
var url = "AjaxOrderItemDisplayView?storeId="+this.storeId+"&catalogId="+this.catalogId+"&langId="+this.langId;
						widgetHTML = widgetHTML
						+"<form name='OrderItemAddForm_"+this.merchandisingAssociationItems[0].catEntry_Identifier+"' action='OrderChangeServiceItemAdd' method='post' id='OrderItemAddForm_"+this.merchandisingAssociationItems[0].catEntry_Identifier+"'>\n"
						+"<input type='hidden' name='storeId' value='"+this.storeId+"' id='OrderItemAddForm_storeId_"+this.merchandisingAssociationItems[0].catEntry_Identifier+"'/>\n"
						+"<input type='hidden' name='orderId' value='.' id='OrderItemAddForm_orderId_"+this.merchandisingAssociationItems[0].catEntry_Identifier+"'/>\n"
						+"<input type='hidden' name='catalogId' value='"+this.catalogId+"' id='OrderItemAddForm_orderId_"+this.merchandisingAssociationItems[0].catEntry_Identifier+"'/>\n"
						+"<input type='hidden' name='URL' value='"+ url + "' id='OrderItemAddForm_url_"+this.merchandisingAssociationItems[0].catEntry_Identifier+"'/>\n"
						+"<input type='hidden' name='errorViewName' value='InvalidInputErrorView' id='OrderItemAddForm_errorViewName_"+this.merchandisingAssociationItems[0].catEntry_Identifier+"'/>\n"
						+"<input type='hidden' name='catEntryId' value='"+this.merchandisingAssociationItems[0].catEntry_Identifier+"' id='OrderItemAddForm_catEntryId_"+this.merchandisingAssociationItems[0].catEntry_Identifier+"'/>\n"
						+"<input type='hidden' name='productId' value='"+this.merchandisingAssociationItems[0].catEntry_Identifier+"' id='OrderItemAddForm_productId_"+this.merchandisingAssociationItems[0].catEntry_Identifier+"'/>\n"
						+"<input type='hidden' value='1' name='quantity' id='OrderItemAddForm_quantity_"+this.merchandisingAssociationItems[0].catEntry_Identifier+"'/>\n"
						+"<input type='hidden' value='' name='page' id='OrderItemAddForm_page_"+this.merchandisingAssociationItems[0].catEntry_Identifier+"'/>\n"
						+"<input type='hidden' value='-1,-2,-3,-4,-5,-6,-7' name='calculationUsage' id='OrderItemAddForm_calcUsage_"+this.merchandisingAssociationItems[0].catEntry_Identifier+"'/>\n"
						+"<input type='hidden' value='0' name='updateable' id='OrderItemAddForm_updateable_"+this.merchandisingAssociationItems[0].catEntry_Identifier+"'/>\n"
						+"<input type='hidden' value='' name='giftListId' id='OrderItemAddForm_giftListId_"+this.merchandisingAssociationItems[0].catEntry_Identifier+"'/>\n"
						+"</form>\n";
						}
widgetHTML = widgetHTML					
			+"<div class='scroller' id='WC_CategoryDisplayJS_div_1'>";
			if(this.totalAssociationCount > 1){
				if(this.associationThumbnailIndex < this.totalAssociationCount){
					widgetHTML = widgetHTML
					+"		<a href='Javascript:categoryDisplayJS.showNextAssociation()'  id='WC_ProductAssociation_UpArrow_Link_1'>";
				}
				widgetHTML = widgetHTML
				+"		<img src='"+this.baseCatalogEntryDetails[0].storeImage_Path+"i_up_arrow.png' alt='"+this.displayNextAssociation+"'/></a>";
			}
			widgetHTML = widgetHTML +" <br />"
			+"<div id='baseContent_"+this.merchandisingAssociationItems[0].catEntry_Identifier+"'";
			if(this.merchandisingAssociationItems[0].showProductQuickView == 'true'){
				widgetHTML = widgetHTML
				+" onmouseover='showPopupButton("+this.merchandisingAssociationItems[0].catEntry_Identifier+");' onmouseout='hidePopupButton("+this.merchandisingAssociationItems[0].catEntry_Identifier+");'>";
			}else{
				widgetHTML = widgetHTML
				+" >";
			}
			if(this.merchandisingAssociationItems[0].productDragAndDrop == 'true'){
				widgetHTML = widgetHTML
					+" <div dojoType='dojo.dnd.Source' jsId='dndSource' id="+this.merchandisingAssociationItems[0].catEntry_Identifier+" copyOnly='true' dndType='"+dragType+"'>"
					+"		<div class='dojoDndItem' dndType='"+dragType+"' id='WC_CategoryDisplayJS_div_draganddrop'>";
			}
			widgetHTML = widgetHTML
			+"	<a href='"+this.merchandisingAssociationItems[0].catEntry_ProductLink+"'  id='img"+this.merchandisingAssociationItems[0].catEntry_Identifier+"' onfocus='showPopupButton("+this.merchandisingAssociationItems[0].catEntry_Identifier+");'>";
					if(this.merchandisingAssociationItems[0].productDragAndDrop == 'true' && dojo.isIE == 6)
					{
						widgetHTML = widgetHTML
						+"<iframe class='productDnDIFrame' scrolling='no' frameborder='0' src='"+getImageDirectoryPath()+"images/empty.gif'></iframe>";
					}
			widgetHTML = widgetHTML
			+"		<img src='"+this.merchandisingAssociationItems[0].catEntry_Thumbnail+"' alt='"+this.merchandisingAssociationItems[0].catEntry_ShortDescription+"' class='img' width='70' height='70'/>"
			+"	</a><br />";
			if(this.merchandisingAssociationItems[0].productDragAndDrop == 'true'){
				widgetHTML = widgetHTML
					+"		</div>"
					+"	</div>";
			}
			if(this.merchandisingAssociationItems[0].showProductQuickView == 'false') 
			{
				widgetHTML = widgetHTML
				+" <div id='popupButton_"+this.merchandisingAssociationItems[0].catEntry_Identifier+"' class='main_quickinfo_button'>"
					+"<span class='secondary_button' >\n"
						+"<span class='button_container' >\n"
							+"<span class='button_bg' >\n"
								+"<span class='button_top'>\n"
									+"<span class='button_bottom'>\n"
										+"<a id='QuickInfoButton_"+this.merchandisingAssociationItems[0].catEntry_Identifier+"' href='#' onclick='javaScript:var actionListImageAcct = new popupActionProperties(); actionListImageAcct.showWishList="+this.merchandisingAssociationItems[0].associationProductBuyable+"; actionListImageAcct.showAddToCart="+this.merchandisingAssociationItems[0].associationProductBuyable+"; showPopup("+this.merchandisingAssociationItems[0].catEntry_Identifier+",event,null,null,actionListImageAcct);' onkeypress='javaScript:var actionListImageAcct = new popupActionProperties(); actionListImageAcct.showWishList="+this.merchandisingAssociationItems[0].associationProductBuyable+"; actionListImageAcct.showAddToCart="+this.merchandisingAssociationItems[0].associationProductBuyable+"; showPopup("+this.merchandisingAssociationItems[0].catEntry_Identifier+",event,null,null,actionListImageAcct);' onblur='hidePopupButton("+this.merchandisingAssociationItems[0].catEntry_Identifier+");' role='wairole:button' waistate:haspopup='true'>"+this.merchandisingAssociationItems[0].showProductQuickViewLable+"</a>"
									+"</span>\n"
								+"</span>\n"
							+"</span>\n"
						+"</span>\n"
					+"</span>\n"										
				+"</div>\n";
			}
			widgetHTML = widgetHTML
			+"</div>";	
		
			if(this.totalAssociationCount > 1){
				if(this.associationThumbnailIndex > 1 ){
					widgetHTML = widgetHTML
					+"		<a href='Javascript:categoryDisplayJS.showPreviousAssociation()'  id='WC_ProductAssociation_DownArrow_Link_1'>";
				}
				widgetHTML = widgetHTML
				+"		<img src='"+this.baseCatalogEntryDetails[0].storeImage_Path+"i_down_arrow.png' alt='"+this.displayPrevAssociation+"'/></a>";
			}
			
			var comboText = this.baseCatalogEntryDetails[0].associatedProductsName.replace(/%0/, this.baseCatalogEntryDetails[0].baseCatEntry_Name);
			comboText = comboText.replace(/%1/, this.merchandisingAssociationItems[0].catEntry_Name);
			
			widgetHTML = widgetHTML
			+"</div>"
			+"<div class='combo_text' id='WC_CategoryDisplayJS_div_2'>\n"
			+"	<h1 id='maHeader' class='status_msg'>"+ comboText +"</h1>\n"
			+"	<span id='maPrice' class='grey'>"+totalPriceMsg+dojo.currency.format(totalPrice.toFixed(2), {currency: this.baseCatalogEntryDetails[0].currency})+"</span>\n"
			+"</div>\n";
			widgetHTML = widgetHTML
			+"<input type='hidden' id='compareImgPath_"+this.merchandisingAssociationItems[0].catEntry_Identifier+"' value='"+this.merchandisingAssociationItems[0].catEntry_Thumbnail_compare+"'/>"
			+"<input type='hidden' id='compareProductDetailsPath_"+this.merchandisingAssociationItems[0].catEntry_Identifier+"' value='"+this.merchandisingAssociationItems[0].catEntry_ProductLink+"'/>"
			+"<input type='hidden' id='compareImgDescription_"+this.merchandisingAssociationItems[0].catEntry_Identifier+"' value='"+this.merchandisingAssociationItems[0].catEntry_ShortDescription+"'/>";
			associationDisplay.innerHTML=null;
			associationDisplay.innerHTML=widgetHTML;
			dojo.parser.parse(associationDisplay);
},


	/**
	* showNextAssociation Displays the next association in the association array. No action is performed if it is already at the last item.
	*				      This function is used with the merchandising association widget on the MerchandisingAssociationDisplay.jsp to display the next
	*					  association available.
	**/
	showNextAssociation : function(){
		
		if(this.associationThumbnailIndex < this.totalAssociationCount){
			this.associationThumbnailIndex = this.associationThumbnailIndex+1;
			this.initializeMerchandisingAssociation(this.associationThumbnailIndex);
		}
	},

	/**
	* showPreviousAssociation Displays the previous association in the association array. No action is performed if it is already the first item.
	*				      This function is used with the merchandising association widget on the MerchandisingAssociationDisplay.jsp to display the previous
	*					  association available.
	**/
	showPreviousAssociation : function(){
		
	if(this.associationThumbnailIndex > 1 ){
			this.associationThumbnailIndex = this.associationThumbnailIndex-1;
			this.initializeMerchandisingAssociation(this.associationThumbnailIndex);
		}
	},

	/**
	* AddAssociation2ShopCartAjax Adds the associated product to the shopping cart when AjaxAddToCart is enabled.
	*
	* @param {String} baseProductId The catalog entry ID of the parent product.
	* @param {int} baseProductQuantity The quantity of the parent product to add.
	*
	**/
	AddAssociation2ShopCartAjax:function(baseProductId,baseProductQuantity){
	
		var identifierJSON = "associatedCatEntries_"+this.associationThumbnailIndex;
		//Get the associated item from the JSON object.
		var associationEntryJSON = eval('('+ dojo.byId(identifierJSON).innerHTML +')');
		this.merchandisingAssociationItems = associationEntryJSON;
		this.baseItemAddedToCart = false;
		//Add the parent product to the cart.
		if(this.merchandisingAssociationItems[0].catEntry_Type=='ProductBean'){
			this.Add2ShopCartAjax(baseProductId,baseProductQuantity);
			if(this.baseItemAddedToCart){
				//Show the pop-up to select the attributes of the associated product.
				showPopup(this.merchandisingAssociationItems[0].catEntry_Identifier,function(e){return e;},'marchandisingAssociationDisplay');
			}
		}else if (this.merchandisingAssociationItems[0].catEntry_Type=='ItemBean' || this.merchandisingAssociationItems[0].catEntry_Type=='PackageBean' || this.merchandisingAssociationItems[0].catEntry_Type=='BundleBean'){
			//Get the associated item from the JSON object.
			var entitledItemJSON = eval('('+ dojo.byId(baseProductId).innerHTML +')');
			this.setEntitledItems(entitledItemJSON);
			var catalogEntryId = this.getCatalogEntryId();
			var params = [];
				params.storeId		= this.storeId;
				params.catalogId	= this.catalogId;
				params.langId			= this.langId;
				params.orderId		= ".";
				params.calculationUsage = "-1,-2,-3,-4,-5,-6,-7";
			if(catalogEntryId!=null){
				this.updateParamObject(params,"catEntryId",catalogEntryId,false,-1);
				this.updateParamObject(params,"quantity",baseProductQuantity,false,-1);
				if(this.merchandisingAssociationItems[0].catEntry_Type=='BundleBean'){
					var form = document.getElementById(this.merchandisingAssociationItems[0].catEntry_BundleFormId);
					var catEntryArray = [];
					// add the individual bundle items to the request.
					catEntryArray = form.catEntryIDS.value.toString().split(",");
					for(var i = 0; i < catEntryArray.length; i++){
						var qty = document.getElementById("quantity_" + catEntryArray[i]).value;
						var catEntryId = catEntryArray[i];
						if(this.getDefaultItem(catEntryArray[i]))
							catEntryId = this.getDefaultItem(catEntryArray[i]);
						if(qty==0 || qty == null) qty = 1;
						if(qty!=null && qty!='' && catEntryId!=null){
							this.updateParamObject(params,"catEntryId",catEntryId,false,-1);
							this.updateParamObject(params,"quantity",qty,false,-1);
						}else{
							MessageHelper.displayErrorMessage(MessageHelper.messages['ERR_RESOLVING_SKU']);
							return;
						}
					}
				}else{
					this.updateParamObject(params,"catEntryId",this.merchandisingAssociationItems[0].catEntry_Identifier,false,-1);
					this.updateParamObject(params,"quantity",1,false,-1);
				}
			}else{
				MessageHelper.displayErrorMessage(MessageHelper.messages['ERR_RESOLVING_SKU']);
				return;
			}
			//For Handling multiple clicks
			if(!submitRequest()){
				return;
			}   		
			cursor_wait();				
			//Invoke service to add to the cart.
			wc.service.invoke("AjaxAddOrderItem", params);
		}
	},

	/**
	* AddMarchandisingAssociation2ShopCart Adds the associated product to the shopping cart when AjaxAddToCart is disabled.
	*
	* @param {String} entitledItemId A DIV containing a JSON object which holds information about a catalog entry. You can reference CachedProductOnlyDisplay.jsp to see how that div is constructed.
	* @param {form} form The form which contains the details of the item that needs to be added to the cart. This method will set the quanitty, catEntryId_1, productId_1 as well as
	*					 quantity_2, catEntryId_2 and productId_2 values in the form based on the values from the quantity you enter into this method and the catalog entry ID 
	* 					 resolved from retrieving the catalog entry ID of the entitled item passed in.						
	* @param {int} quantity The quantity of the parent product to add.
	*
	**/
	AddMarchandisingAssociation2ShopCart : function(entitledItemId,form,quantity){
	
	var identifierJSON = "associatedCatEntries_"+this.associationThumbnailIndex;
	var associationEntryJSON = eval('('+ dojo.byId(identifierJSON).innerHTML +')');
	this.merchandisingAssociationItems = associationEntryJSON;
	//get the item form the JSON object	
	var entitledItemJSON;

	if (dojo.byId(entitledItemId)!=null) {
		//the json object for entitled items are already in the HTML. 
		 entitledItemJSON = eval('('+ dojo.byId(entitledItemId).innerHTML +')');
	}else{
		//if dojo.byId(entitledItemId) is null, that means there's no <div> in the HTML that contains the JSON object. 
		//in this case, it must have been set in catalogentryThumbnailDisplay.js when the quick info
		entitledItemJSON = this.getEntitledItemJsonObject(); 
	}
	this.setEntitledItems(entitledItemJSON);
	var catalogEntryId_1 = this.getCatalogEntryId();
	//Add the product to the cart if the product attributes are selected otherwise show the pop-up dialog.	
	if(this.merchandisingAssociationItems[0].catEntry_Type=='ProductBean'){
		if(catalogEntryId_1!=null){
			form.catEntryId_1.value = catalogEntryId_1;
			form.productId_1.value = catalogEntryId_1;
			form.quantity_1.value = quantity;
			this.merchandisingProductAssociationAddToCart = true;
			this.merchandisingProductAssociationForm = form;
			showPopup(this.merchandisingAssociationItems[0].catEntry_Identifier,function(e){return e;},'marchandisingAssociationDisplay');
		}else{
			MessageHelper.displayErrorMessage(MessageHelper.messages['ERR_RESOLVING_SKU']);
			return;
		}
	}else if (this.merchandisingAssociationItems[0].catEntry_Type=='ItemBean' || this.merchandisingAssociationItems[0].catEntry_Type=='PackageBean' || this.merchandisingAssociationItems[0].catEntry_Type=='BundleBean'){
		//Add the  items to the shop cart.
		if(catalogEntryId_1!=null){
			form.catEntryId_1.value = catalogEntryId_1;
			form.productId_1.value = catalogEntryId_1;
			form.quantity_1.value = quantity;
			if(this.merchandisingAssociationItems[0].catEntry_Type=='BundleBean'){
				// add the individual bundle items to the request.
				var bundleForm = document.getElementById(this.merchandisingAssociationItems[0].catEntry_BundleFormId);
				var catEntryArray = [];
				catEntryArray = bundleForm.catEntryIDS.value.toString().split(",");
				var catEntryCount = 3;
				for(var i = 0; i < catEntryArray.length; i++){
					var qty = document.getElementById("quantity_" + catEntryArray[i]).value;
					var catEntryId = catEntryArray[i];
					if(this.getDefaultItem(catEntryArray[i]))
							catEntryId = this.getDefaultItem(catEntryArray[i]);
					if(qty==0 || qty == null) qty = 1;
					if(qty!=null && qty!='' && catEntryId!=null){
						if(i==0){
							form.catEntryId_2.value = catEntryId;
							form.productId_2.value = catEntryId;
							form.quantity_2.value = qty;	
						}else{
							var input1 = document.createElement("input");
							input1.setAttribute("id", "OrderAssociationItemAddForm_catEntryId_"+catEntryId);
							input1.setAttribute("type", "hidden");
							input1.setAttribute("name", "catEntryId_"+catEntryCount);
							input1.setAttribute("value", catEntryId);
							form.appendChild(input1);
							var input2 = document.createElement("input");
							input2.setAttribute("id", "OrderAssociationItemAddForm_productId_"+catEntryId);
							input2.setAttribute("type", "hidden");
							input2.setAttribute("name", "productId_"+catEntryCount);
							input2.setAttribute("value", catEntryId);
							form.appendChild(input2);
							var quantity1 = document.createElement("input");
							quantity1.setAttribute("id", "OrderAssociationItemAddForm_quantity_"+catEntryId);
							quantity1.setAttribute("type", "hidden");
							quantity1.setAttribute("name", "quantity_"+catEntryCount);
							quantity1.setAttribute("value", "1");
							form.appendChild(quantity1);
							catEntryCount = catEntryCount+1;
						}
						
					}else{
						MessageHelper.displayErrorMessage(MessageHelper.messages['ERR_RESOLVING_SKU']);
						return;
					}
				}
			}else{
				form.catEntryId_2.value = this.merchandisingAssociationItems[0].catEntry_Identifier;
				form.productId_2.value = this.merchandisingAssociationItems[0].catEntry_Identifier;
				form.quantity_2.value = "1";
			}
			
			//For Handling multiple clicks
			if(!submitRequest()){
				return;
			}

			// submit the form to add the items to the shop cart.
			form.submit();	
		}else{
			MessageHelper.displayErrorMessage(MessageHelper.messages['ERR_RESOLVING_SKU']);
			return;
		}
		}
	},

	/** 
	* AddAssociation2ShopCart Adds an associated product to the shopping cart. This function is called by other functions in the FastFinderDisplay.js such as Add2ShopCart().
	* 
	* @param {String} associatedItemId The catalog entry ID of the associated item.
	* @param {int} quantity The quantity of the associated item to add.
	*
	**/
	AddAssociation2ShopCart:function(associatedItemId,quantity){
	
	var form = this.merchandisingProductAssociationForm;
	this.merchandisingProductAssociationAddToCart = false;
	if(this.isParentBundleBean){
		// add the individual bundle items to the request.
		var catEntryArray = [];
		catEntryArray = form.catEntryIDS.value.toString().split(",");
		var bundleItemsCount = 1;
		for(var i = 0; i < catEntryArray.length; i++){
			var qty = document.getElementById("quantity_" + catEntryArray[i]).value;
			var catEntryId = catEntryArray[i];
			if(this.selectedProducts[catEntryArray[i]])
				catEntryId = this.getCatalogEntryIdforProduct(this.selectedProducts[catEntryArray[i]]);
			if(qty==0 || qty == null) qty = 1;
			if(qty!=null && qty!='' && catEntryId!=null){
				var input1 = document.createElement("input");
				input1.setAttribute("id", "OrderItemAddForm_catEntryId_"+catEntryId);
				input1.setAttribute("type", "hidden");
				input1.setAttribute("name", "catEntryId_"+bundleItemsCount);
				input1.setAttribute("value", catEntryId);
				bundleItemsCount = bundleItemsCount + 1;
				form.appendChild(input1);
			}else{
				MessageHelper.displayErrorMessage(MessageHelper.messages['ERR_RESOLVING_SKU']);
				return;
			}
		}
		var input2 = document.createElement("input");
		input2.setAttribute("id", "OrderItemAddForm_catEntryId_"+associatedItemId);
		input2.setAttribute("type", "hidden");
		input2.setAttribute("name", "catEntryId_"+bundleItemsCount);
		input2.setAttribute("value", associatedItemId);
		form.appendChild(input2);
		var quantity1 = document.createElement("input");
		quantity1.setAttribute("id", "OrderItemAddForm_quantity_"+associatedItemId);
		quantity1.setAttribute("type", "hidden");
		quantity1.setAttribute("name", "quantity_"+bundleItemsCount);
		quantity1.setAttribute("value", quantity);
		form.appendChild(quantity1);
		form.URL.value = "AjaxOrderItemDisplayView";
		this.isParentBundleBean = false;
	}else{
		form.catEntryId_2.value = associatedItemId;
		form.productId_2.value = associatedItemId;
		form.quantity_2.value = quantity;
	}
	
	//For Handling multiple clicks
	if(!submitRequest()){
		return;
	}
	
	// submit the form to add the items to the shop cart.
	form.submit();
	this.merchandisingProductAssociationForm = "";
	},

	/**
	* AddAssociationItem2ShopCartAjax Adds the associated item to the shopping cart when AjaxAddToCart is enabled.
	*								  This function is called from MerchandisingAssociationsDisplay.jsp to add an associated item to the shopping cart.
	*
	* @param {String} baseItemId The catalog entry ID of the item to add.
	* @param {int} baseItemQuantity The quantity to add.
	*
	**/
	AddAssociationItem2ShopCartAjax:function(baseItemId , baseItemQuantity){
	
	var identifierJSON = "associatedCatEntries_"+this.associationThumbnailIndex;
	//get the item form the JSON object	
	var associationEntryJSON = eval('('+ dojo.byId(identifierJSON).innerHTML +')');
	this.merchandisingAssociationItems = associationEntryJSON;
	this.baseItemAddedToCart = false;
	//Add the parent item to the cart and if the associated catentry is a product bean then show the pop-up dialog.
	if(this.merchandisingAssociationItems[0].catEntry_Type=='ProductBean'){
		this.AddItem2ShopCartAjax(baseItemId,baseItemQuantity);
		if(this.baseItemAddedToCart){
			showPopup(this.merchandisingAssociationItems[0].catEntry_Identifier,function(e){return e;},'marchandisingAssociationDisplay');
		}
	}else if (this.merchandisingAssociationItems[0].catEntry_Type=='ItemBean' || this.merchandisingAssociationItems[0].catEntry_Type=='PackageBean' || this.merchandisingAssociationItems[0].catEntry_Type=='BundleBean'){
			var params = [];
				params.storeId		= this.storeId;
				params.catalogId	= this.catalogId;
				params.langId			= this.langId;
				params.orderId		= ".";
				params.calculationUsage = "-1,-2,-3,-4,-5,-6,-7";
			this.updateParamObject(params,"catEntryId",baseItemId,false,-1);
			this.updateParamObject(params,"quantity",baseItemQuantity,false,-1);
			// add the individual bundle items to the request.
			if(this.merchandisingAssociationItems[0].catEntry_Type=='BundleBean'){
				var form = document.getElementById(this.merchandisingAssociationItems[0].catEntry_BundleFormId);
				var catEntryArray = [];
				catEntryArray = form.catEntryIDS.value.toString().split(",");
				for(var i = 0; i < catEntryArray.length; i++){
					var qty = document.getElementById("quantity_" + catEntryArray[i]).value;
					var catEntryId = catEntryArray[i];
					if(this.getDefaultItem(catEntryArray[i]))
							catEntryId = this.getDefaultItem(catEntryArray[i]);
					if(qty==0 || qty == null) qty = 1;
					if(qty!=null && qty!='' && catEntryId!=null){
						this.updateParamObject(params,"catEntryId",catEntryId,false,-1);
						this.updateParamObject(params,"quantity",qty,false,-1);
					}else{
						MessageHelper.displayErrorMessage(MessageHelper.messages['ERR_RESOLVING_SKU']);
						return;
					}
				}
			}else{
				this.updateParamObject(params,"catEntryId",this.merchandisingAssociationItems[0].catEntry_Identifier,false,-1);
				this.updateParamObject(params,"quantity",1,false,-1);
			}
			
			//For Handling multiple clicks
			if(!submitRequest()){
				return;
			} 			
			cursor_wait();			
			//Invoke service to add item to the cart.
			wc.service.invoke("AjaxAddOrderItem", params);
		}
	},

	/**
	* AddAssociationItem2ShopCart Adds the parent item with associated catentry to the shopping cart when AjaxAddToCart is disabled.
	*
	* @param {form} form The form which contains the details of the item that needs to be added to the cart. The {@link fastFinderJS.merchandisingProductAssociationForm}
	*				      is set to the the form passed in. The forms quanitity_1 and quantity_2 values are set according to the values passed in 
	*					  for quantity and the value of the quantity_<catEntryId> element for the two quantity values respectively. The catEntryId_2 and productId_2 values
	*					  are also set. 
	* @param {int} quantity The quantity of the item to add to the cart.
	*
	**/
	AddAssociationItem2ShopCart : function(form,quantity){

	var identifierJSON = "associatedCatEntries_"+this.associationThumbnailIndex;
	//Get the associated item from the JSON object.
	var associationEntryJSON = eval('('+ dojo.byId(identifierJSON).innerHTML +')');
	this.merchandisingAssociationItems = associationEntryJSON;
	//Add the parent item to the cart and if the associated catentry is a product bean then show the pop-up dialog.
	if(this.merchandisingAssociationItems[0].catEntry_Type=='ProductBean'){
		if(quantity) form.quantity_1.value = quantity;
		this.merchandisingProductAssociationAddToCart = true;
		this.merchandisingProductAssociationForm = form;
		showPopup(this.merchandisingAssociationItems[0].catEntry_Identifier,function(e){return e;},'marchandisingAssociationDisplay');
	}else if (this.merchandisingAssociationItems[0].catEntry_Type=='ItemBean' || this.merchandisingAssociationItems[0].catEntry_Type=='PackageBean' || this.merchandisingAssociationItems[0].catEntry_Type=='BundleBean'){
		if(quantity) form.quantity_1.value = quantity;
			// add the individual bundle items to the request.
			if(this.merchandisingAssociationItems[0].catEntry_Type=='BundleBean'){
				var bundleForm = document.getElementById(this.merchandisingAssociationItems[0].catEntry_BundleFormId);
				var catEntryArray = [];
				catEntryArray = bundleForm.catEntryIDS.value.toString().split(",");
				var catEntryCount = 3;
				for(var i = 0; i < catEntryArray.length; i++){
					var qty = document.getElementById("quantity_" + catEntryArray[i]).value;
					var catEntryId = catEntryArray[i];
					if(this.getDefaultItem(catEntryArray[i]))
							catEntryId = this.getDefaultItem(catEntryArray[i]);
					if(qty==0 || qty == null) qty = 1;
						if(i==0){
							form.catEntryId_2.value = catEntryId;
							form.productId_2.value = catEntryId;
							form.quantity_2.value = qty;	    
						}else{
							var input1 = document.createElement("input");
							input1.setAttribute("id", "OrderAssociationItemAddForm_catEntryId_"+catEntryId);
							input1.setAttribute("type", "hidden");
							input1.setAttribute("name", "catEntryId_"+catEntryCount);
							input1.setAttribute("value", catEntryId);
							form.appendChild(input1);
							var input2 = document.createElement("input");
							input2.setAttribute("id", "OrderAssociationItemAddForm_productId_"+catEntryId);
							input2.setAttribute("type", "hidden");
							input2.setAttribute("name", "productId_"+catEntryCount);
							input2.setAttribute("value", catEntryId);
							form.appendChild(input2);
							var quantity1 = document.createElement("input");
							quantity1.setAttribute("id", "OrderAssociationItemAddForm_quantity_"+catEntryId);
							quantity1.setAttribute("type", "hidden");
							quantity1.setAttribute("name", "quantity_"+catEntryCount);
							quantity1.setAttribute("value", "1");
							form.appendChild(quantity1);
							catEntryCount = catEntryCount+1;
						}
					}
			}else{
				form.catEntryId_2.value = this.merchandisingAssociationItems[0].catEntry_Identifier;
				form.productId_2.value = this.merchandisingAssociationItems[0].catEntry_Identifier;
				form.quantity_2.value = "1";
			}
			
			//For Handling multiple clicks
			if(!submitRequest()){
				return;
			}
			
			//submit the form to add the item to the cart.
			form.submit();	
		}
	},

	/**
	* AddAssociationBundle2ShopCartAjax Adds the parent bundle and associated products to the shopping cart when AjaxAddToCart is enabled.
	*									This function is used on MerchandisingAssociationsDisplay.jsp.
	*
	* @param {form} form The form which contains the details of the catalog entries that need to be added to the cart.
	* 				      This form is expected to have a comma separated list of catalog entry IDs of catalog entries in the bundle which should be added to the shopping cart.
	*
	**/
	AddAssociationBundle2ShopCartAjax:function(form){

	var identifierJSON = "associatedCatEntries_"+this.associationThumbnailIndex;
	//Get the associated item from the JSON object.
	var associationEntryJSON = eval('('+ dojo.byId(identifierJSON).innerHTML +')');
	this.merchandisingAssociationItems = associationEntryJSON;
	this.baseItemAddedToCart = false;
//Add the parent bundle to the cart and show the pop-up dialog for the associated product.
			
			var params = [];
			
			params.storeId		= this.storeId;
			params.catalogId	= this.catalogId;
			params.langId		= this.langId;
			params.orderId		= ".";
			params.calculationUsage = "-1,-2,-3,-4,-5,-6,-7";
		// add the individual bundle items of the parent bundle to the request.
			var catEntryArray = [];
			catEntryArray = form.catEntryIDS.value.toString().split(",");
			for(var i = 0; i < catEntryArray.length; i++){
				var qty = document.getElementById("quantity_" + catEntryArray[i]).value;
				var catEntryId = catEntryArray[i];
				if(this.getDefaultItem(catEntryArray[i]))
							catEntryId = this.getDefaultItem(catEntryArray[i]);
				if(qty==0 || qty == null) qty = 1;
				if(qty!=null && qty!='' && catEntryId!=null){
					this.updateParamObject(params,"catEntryId",catEntryId,false,-1);
					this.updateParamObject(params,"quantity",qty,false,-1);
					this.baseItemAddedToCart = "true";
				}else{
					MessageHelper.displayErrorMessage(MessageHelper.messages['ERR_RESOLVING_SKU']);
					return;
				}
			}
			// add the individual bundle items of the associated bundle to the request.
			if(this.merchandisingAssociationItems[0].catEntry_Type=='BundleBean'){
					var bundleForm = document.getElementById(this.merchandisingAssociationItems[0].catEntry_BundleFormId);
					var innerCatEntryArray = [];
					innerCatEntryArray = bundleForm.catEntryIDS.value.toString().split(",");
					for(var i = 0; i < innerCatEntryArray.length; i++){
						var qty = document.getElementById("quantity_" + innerCatEntryArray[i]).value;
						var innerCatEntryId = innerCatEntryArray[i];
						if(this.getDefaultItem(innerCatEntryArray[i]))
							innerCatEntryId = this.getDefaultItem(innerCatEntryArray[i]);
						if(qty==0 || qty == null) qty = 1;
						if(qty!=null && qty!='' && innerCatEntryId!=null){
							this.updateParamObject(params,"catEntryId",innerCatEntryId,false,-1);
							this.updateParamObject(params,"quantity",qty,false,-1);
						}else{
							MessageHelper.displayErrorMessage(MessageHelper.messages['ERR_RESOLVING_SKU']);
							return;
						}
					}
				}else if(this.merchandisingAssociationItems[0].catEntry_Type=='PackageBean' || this.merchandisingAssociationItems[0].catEntry_Type=='ItemBean'){
					this.updateParamObject(params,"catEntryId",this.merchandisingAssociationItems[0].catEntry_Identifier,false,-1);
					this.updateParamObject(params,"quantity",1,false,-1);
				}
			//For Handling multiple clicks
			if(!submitRequest()){
				return;
			}   
			cursor_wait();			
			//Invoke service to add to the cart.
			wc.service.invoke("AjaxAddOrderItem", params);
	
	   if(this.merchandisingAssociationItems[0].catEntry_Type=='ProductBean'){
		   showPopup(this.merchandisingAssociationItems[0].catEntry_Identifier,function(e){return e;},'marchandisingAssociationDisplay');
	   }
},

/** 
* Sets the orderID if it is not already set on the Current Order page. 
* The order ID is used to determine which order to act upon such as in the case of replacing an order item in an order.
* @param {String} orderId The orderID to use.
*/
setOrderId : function(orderId)
{
	this.orderId = orderId;
},

	/**
	* AddAssociationBundle2ShopCart Adds the parent bundle and associated product to the shopping cart when AjaxAddToCart is disabled.
	*								This function is used on MerchandisingAssociationsDisplay.jsp. 
	* 
	* @param {form} form The form which contains the details of the catalog entries that need to be added to the cart.
	* 						The {@link fastFinderJS.merchandisingProductAssociationForm} is set to the form passed in.
	*						The form is expected to have a value for catEntryIDS which is a list of catalog entry IDs of the catalog entries in the bundle which should be
	*						added to the shopping cart.
	*
	**/
	AddAssociationBundle2ShopCart : function(form){
	
	var identifierJSON = "associatedCatEntries_"+this.associationThumbnailIndex;
	//get the item form the JSON object	
	var associationEntryJSON = eval('('+ dojo.byId(identifierJSON).innerHTML +')');
	this.merchandisingAssociationItems = associationEntryJSON;
	this.isParentBundleBean = true;
	//Add the parent bundle to the cart and show the pop-up dialog for the associated product.
	if(this.merchandisingAssociationItems[0].catEntry_Type=='ProductBean'){
		this.merchandisingProductAssociationAddToCart = true;
		this.merchandisingProductAssociationForm = form;
		var catEntryArray = [];
		// add the individual bundle items of the parent bundle to the request.
		catEntryArray = form.catEntryIDS.value.toString().split(",");
		var bundleItemsCount = 1;
		for(var i = 0; i < catEntryArray.length; i++){
			var qty = document.getElementById("quantity_" + catEntryArray[i]).value;
			var catEntryId = catEntryArray[i];
			if(this.getDefaultItem(catEntryArray[i]))
							catEntryId = this.getDefaultItem(catEntryArray[i]);
			if(catEntryId != null)
							form["catEntryId_" + catEntryArray[i]].value = catEntryId;				
			else{
					MessageHelper.displayErrorMessage(MessageHelper.messages['ERR_RESOLVING_SKU']);
					return;
			}
			bundleItemsCount = bundleItemsCount + 1;
			
		}
		showPopup(this.merchandisingAssociationItems[0].catEntry_Identifier,function(e){return e;},'marchandisingAssociationDisplay');
	}else if (this.merchandisingAssociationItems[0].catEntry_Type=='ItemBean' || this.merchandisingAssociationItems[0].catEntry_Type=='PackageBean' || this.merchandisingAssociationItems[0].catEntry_Type=='BundleBean'){
		var catEntryArray = [];
		// add the individual bundle items of the parent bundle to the request.
		catEntryArray = form.catEntryIDS.value.toString().split(",");
		var bundleItemsCount = 1;
		for(var i = 0; i < catEntryArray.length; i++){
			var qty = document.getElementById("quantity_" + catEntryArray[i]).value;
			var catEntryId = catEntryArray[i];
			if(this.getDefaultItem(catEntryArray[i]))
							catEntryId = this.getDefaultItem(catEntryArray[i]);
			if(catEntryId != null)
							form["catEntryId_" + catEntryArray[i]].value = catEntryId;				
			else{
					MessageHelper.displayErrorMessage(MessageHelper.messages['ERR_RESOLVING_SKU']);
					return;
			}
			bundleItemsCount = bundleItemsCount + 1;
			
		}
		if(this.merchandisingAssociationItems[0].catEntry_Type=='BundleBean'){
			// add the individual bundle items of the associated bundle to the request.
			var bundleForm = document.getElementById(this.merchandisingAssociationItems[0].catEntry_BundleFormId);
			var innerCatEntryArray = [];
			innerCatEntryArray = bundleForm.catEntryIDS.value.toString().split(",");
			for(var i = 0; i < innerCatEntryArray.length; i++){
				var qty = document.getElementById("quantity_" + innerCatEntryArray[i]).value;
				var innerCatEntryId = innerCatEntryArray[i];
				if(this.getDefaultItem(innerCatEntryArray[i])){
							innerCatEntryId = this.getDefaultItem(innerCatEntryArray[i]);
							}
				if(qty==0 || qty == null) qty = 1;
				if(qty!=null && qty!='' && innerCatEntryId!=null){
					var input2 = document.createElement("input");
					input2.setAttribute("id", "OrderItemAddForm_catEntryId_"+innerCatEntryId);
					input2.setAttribute("type", "hidden");
					input2.setAttribute("name", "catEntryId_"+bundleItemsCount);
					input2.setAttribute("value", innerCatEntryId);
					form.appendChild(input2);
					var quantity2 = document.createElement("input");
					quantity2.setAttribute("id", "OrderItemAddForm_quantity_"+innerCatEntryId);
					quantity2.setAttribute("type", "hidden");
					quantity2.setAttribute("name", "quantity_"+bundleItemsCount);
					quantity2.setAttribute("value", "1");
					form.appendChild(quantity2);
					bundleItemsCount = bundleItemsCount + 1;
				}else{
					MessageHelper.displayErrorMessage(MessageHelper.messages['ERR_RESOLVING_SKU']);
					return;
				}
			}
		}else{
			var input2 = document.createElement("input");
			input2.setAttribute("id", "OrderItemAddForm_catEntryId_"+this.merchandisingAssociationItems[0].catEntry_Identifier);
			input2.setAttribute("type", "hidden");
			input2.setAttribute("name", "catEntryId_"+bundleItemsCount);
			input2.setAttribute("value", this.merchandisingAssociationItems[0].catEntry_Identifier);
			form.appendChild(input2);
			var quantity2 = document.createElement("input");
			quantity2.setAttribute("id", "OrderItemAddForm_quantity_"+this.merchandisingAssociationItems[0].catEntry_Identifier);
			quantity2.setAttribute("type", "hidden");
			quantity2.setAttribute("name", "quantity_"+bundleItemsCount);
			quantity2.setAttribute("value", "1");
			form.appendChild(quantity2);
		}
		form.URL.value = "AjaxOrderItemDisplayView";
		
		//For Handling multiple clicks
		if(!submitRequest()){
			return;
		}
		
		//submit the form to add to cart.
		form.submit();
	}
	
},

	/**
	 * Resolves the SKU and adds the item to a new requisition list.
	 *  
	 * @param {String} entitledItemId The catalog entry ID of the item to add to the requisition list.
	 * @param {String} quantityElemId The ID of the Quantity field.
	 * @param {String} currentPage The URL of the current page. When a customer clicks Cancel on the requisition list creation page, they are redirected to the current page.
	 */
	addToNewListFromProductDetail:function (entitledItemId,quantityElemId,currentPage) {
		MessageHelper.hideAndClearMessage();
		var entitledItemJSON;

		if (dojo.byId(entitledItemId)!=null) {
			//the json object for entitled items are already in the HTML. 
			 entitledItemJSON = eval('('+ dojo.byId(entitledItemId).innerHTML +')');
		}else{
			//if dojo.byId(entitledItemId) is null, that means there's no <div> in the HTML that contains the JSON object. 
			//in this case, it must have been set in catalogentryThumbnailDisplay.js when the quick info
			entitledItemJSON = this.getEntitledItemJsonObject(); 
		}
		this.setEntitledItems(entitledItemJSON);
		var catalogEntryId = this.getCatalogEntryId();
		if(catalogEntryId!=null){
			this.addItemToNewListFromProductDetail(catalogEntryId, quantityElemId, currentPage);
		}
		else{
			MessageHelper.displayErrorMessage(MessageHelper.messages['ERR_RESOLVING_SKU_REQ_LIST']);
			//Close the quick info pop-up if it exists
			if(dijit.byId('second_level_category_popup') != null){
				hidePopup('second_level_category_popup');
			}
			return;			
		}
	},
	
	/**
	 * Adds the item to a new requisition list.
	 *  
	 * @param {String} catalogEntryId The resolved catalog entry ID of the item to add to the requisition list.
	 * @param {String} quantityElemId The ID of the Quantity field.
	 * @param {String} currentPage The URL of the current page. When a customer clicks Cancel on the requisition list creation page, they are redirected to the current page.
	 */
	addItemToNewListFromProductDetail:function (catalogEntryId,quantityElemId,currentPage) {
		MessageHelper.hideAndClearMessage();
		if(catalogEntryId!=null){
			var quantity = document.getElementById(quantityElemId).value;
			if (quantity == null || quantity == "" || quantity<=0 || !RequisitionList.isNumber(quantity)) {
				MessageHelper.displayErrorMessage(MessageHelper.messages['QUANTITY_INPUT_ERROR']);
				//Close the quick info pop-up if it exists
				if(dijit.byId('second_level_category_popup') != null){
					hidePopup('second_level_category_popup');
				}
				return;
			}
			if(this.ajaxMyAccount){
				var URL = "AjaxLogonForm?page=createrequisitionlist";
			} else {
				var URL = "RequisitionListDetailView?editable=true&newList=true";
			}
			
			//using the form because the previousPage url can be very long
			var formObj = document.createElement("form");
			formObj.setAttribute("method","POST");
			
			var input = document.createElement("input");
			input.setAttribute("type", "hidden");
			input.setAttribute("value", currentPage);
			input.setAttribute("name", "previousPage");
			formObj.appendChild(input);
			
			formObj.action = URL + "&catEntryId="+catalogEntryId +"&quantity="+quantity+ "&storeId=" + this.storeId +"&catalogId=" + this.catalogId + "&langId=" + this.langId;
			
			document.body.appendChild(formObj); // have to add this form to the body node before submitting.
			formObj.submit();
		}
		else{
			MessageHelper.displayErrorMessage(MessageHelper.messages['ERR_RESOLVING_SKU_REQ_LIST']);
		}
	},	
	
	/**
	 * Adds the bundle to a new requisition list.
	 *  
	 * @param {form} form The form that contains all of the inputs for the bundle.
	 * @param {String} currentPage The URL of the current page. When a customer clicks Cancel on the requisition list creation page, they are redirected to the current page.
	 */
	addBundleToNewListFromProductDetail:function (form,currentPage) {
		var productCount = form["numberOfProduct"].value;
		var URL = "";
		if(this.ajaxMyAccount){
			URL = "AjaxLogonForm?page=createrequisitionlist";
		} else {
			URL = "RequisitionListDetailView?editable=true&newList=true";
		}	
		
		for(var i = 1; i <= productCount; i++){
			var catEntryId = form["catEntryId_" + i].value;
			if(this.selectedProducts[catEntryId]) {
				catEntryId = this.getCatalogEntryIdforProduct(this.selectedProducts[catEntryId]);
			}
			
			var qty = form["quantity_" + i].value;
			if(qty == null || qty == "" || qty<=0 || !RequisitionList.isNumber(qty)){ 
				MessageHelper.displayErrorMessage(MessageHelper.messages['QUANTITY_INPUT_ERROR']); 
				return;
			} else if(catEntryId!=null){			
				URL = URL + "&catEntryId=" + catEntryId + "&quantity=" + qty;
			} else{
				MessageHelper.displayErrorMessage(MessageHelper.messages['ERR_RESOLVING_SKU_REQ_LIST']);
				return;
			}
		}
		
		var input = document.createElement("input");
		input.setAttribute("type", "hidden");
		input.setAttribute("value", currentPage);
		input.setAttribute("name", "previousPage");
		form.appendChild(input);		
		
		URL = URL +"&numberOfProduct="+form.numberOfProduct.value+ "&storeId=" + this.storeId +"&catalogId=" + this.catalogId + "&langId=" + this.langId; 
		form.action=URL;
		form.submit();
	},	
	
	/**
	* Resolves the SKU and adds the item to an existing requisition list.
	*
	* @param {string} entitledItemId The catalog entry ID of the item to add to the requisition list.
	* @param {string} quantityElemId The ID of the Quantity field.
	* @param {boolean} ajaxAddToCart Indicates whether the AJAX Add to Cart flexflow is enabled.
	*/
	addToExistingRequisitionList:function (entitledItemId,quantityElemId,ajaxAddToCart) {
		//resolve the SKU for the product
				var entitledItemJSON;

		if (dojo.byId(entitledItemId)!=null) {
			//the json object for entitled items are already in the HTML. 
			 entitledItemJSON = eval('('+ dojo.byId(entitledItemId).innerHTML +')');
		}else{
			//if dojo.byId(entitledItemId) is null, that means there's no <div> in the HTML that contains the JSON object. 
			//in this case, it must have been set in catalogentryThumbnailDisplay.js when the quick info
			entitledItemJSON = this.getEntitledItemJsonObject(); 
		}
		this.setEntitledItems(entitledItemJSON);
		var catalogEntryId = this.getCatalogEntryId();
		
		if(catalogEntryId!=null){
			//Add the resolved SKU to the selected requisition list
			this.addItemToExistingRequisitionList(catalogEntryId,quantityElemId,ajaxAddToCart);
		} else{
			MessageHelper.displayErrorMessage(MessageHelper.messages['ERR_RESOLVING_SKU_REQ_LIST']);
		}
	},	
	
	/** 
	* Adds the bundle to an existing requisition list.
	*
	* @param {form} form The form that contains all of the inputs for the bundle.
	* @param {boolean} ajaxAddToCart Indicates whether the AJAX Add to Cart flexflow is enabled.
	*/
	addBundleToExistingRequisitionList:function(form,ajaxAddToCart){
		//Get all the requisition list radio button inputs
		var reqListSelection = document.getElementsByName("RequisitionListTableDisplay_RequisitionListSelection");
		
		//Retrieve the requisition list id from the radio button selection
		for (var i=0; i<reqListSelection.length; i++) {
			if (reqListSelection.item(i).checked) {
				var requisitionListId = reqListSelection.item(i).value;
			} 
		}
		
		if(ajaxAddToCart){
			var params = [];
	
			params.storeId		= this.storeId;
			params.catalogId	= this.catalogId;
			params.langId		= this.langId;
			params["requisitionListId"] = requisitionListId;
				
			var productCount = form["numberOfProduct"].value;
			for(var i = 1; i <= productCount; i++){
				var catEntryId = form["catEntryId_" + i].value;
				if(this.selectedProducts[catEntryId]) {
					catEntryId = this.getCatalogEntryIdforProduct(this.selectedProducts[catEntryId]);
				}
				
				var qty = form["quantity_" + i].value;
				if(qty == null || qty == "" || qty<=0 || !RequisitionList.isNumber(qty)){ 
					MessageHelper.displayeErrorMessage(MessageHelper.messages['QUANTITY_INPUT_ERROR']); 
					return;
				} else if(qty!=null && qty!='' && catEntryId!=null){
					this.updateParamObject(params,"catEntryId",catEntryId,false,-1);
					this.updateParamObject(params,"quantity",qty,false,-1);
					this.baseItemAddedToCart=true;
				} else{
					MessageHelper.displayErrorMessage(MessageHelper.messages['ERR_RESOLVING_SKU_REQ_LIST']);
					return;
				}
			}
			//For Handling multiple clicks
			if(!submitRequest()){
				return;
			}   		
			cursor_wait();		
			wc.service.invoke("requisitionListAddItem_popup", params);
		} else {
			form.action = "RequisitionListItemUpdate?requisitionListId="+requisitionListId;
			
			if(this.ajaxMyAccount){
				form.URL.value = "AjaxLogonForm?page=editrequisitionlist&requisitionListId=" + requisitionListId + "&editable=true";
			} else {
				form.URL.value = "RequisitionListDetailView?requisitionListId=" + requisitionListId + "&editable=true";
			}			
			
			//For Handling multiple clicks
			if(!submitRequest()){
				return;
			}   		
			cursor_wait();
			form.submit();
		}	
	},	

	/**
	* Adds the resolved SKU of an item to an existing requisition list.
	* Assumes that the catalogEntryId is a resolved SKU.
	*
	* @param {string} catalogEntryId The resolved catalog entry ID of the item to add to the requisition list.
	* @param {string} quantityElemId The ID of the Quantity field.
	* @param {boolean} ajaxAddToCart Indicates whether the AJAX Add to Cart flexflow is enabled.
	*/
	addItemToExistingRequisitionList:function (catalogEntryId,quantityElemId,ajaxAddToCart) {
		if(catalogEntryId!=null){
			//Validate the quantity value
			var quantity = document.getElementById(quantityElemId).value;
			if (!RequisitionList.isNumber(quantity) || quantity <= 0) {
				if(quantityElemId == "productPopUpQty"){
					MessageHelper.displayErrorMessage(MessageHelper.messages['QUANTITY_INPUT_ERROR']);
					//Close the quick info pop-up if it exists
					if(dijit.byId('second_level_category_popup') != null){
						hidePopup('second_level_category_popup');
					}
					return;
				} else {
					MessageHelper.formErrorHandleClient(quantityElemId,MessageHelper.messages["QUANTITY_INPUT_ERROR"]); 
					return;
				}
			}		
	
			//Get all the requisition list radio button inputs
			var reqListSelection = document.getElementsByName("RequisitionListTableDisplay_RequisitionListSelection");
			
			//Retrieve the requisition list id from the radio button selection
			for (var i=0; i<reqListSelection.length; i++) {
				if (reqListSelection.item(i).checked) {
					var requisitionListId = reqListSelection.item(i).value;
				} 
			}
						
			//For Ajax "Add to Cart" flexflow, add item and remain on the same page
			if(ajaxAddToCart){
				var params = {};
				
				params["requisitionListId"] = requisitionListId;
				params["catEntryId"] = catalogEntryId;
				params["quantity"] = quantity;
				params.storeId = this.storeId;
				params.catalogId = this.catalogId;
				params.langId = this.langId;
				
				/*For Handling multiple clicks. */
				if(!submitRequest()){
					return;
				}			
				cursor_wait();
				wc.service.invoke('requisitionListAddItem_popup',params);				
			} else { 
				//For Non-Ajax add to cart
				var form = document.forms["RequisitionListPopupForm"];
				form.requisitionListId.value = requisitionListId;
				form.quantity.value = quantity;
				form.catEntryId.value = catalogEntryId;
				
				if(this.ajaxMyAccount){
					form.URL.value = "AjaxLogonForm?page=editrequisitionlist&requisitionListId=" + requisitionListId + "&editable=true";
				} else {
					form.URL.value = "RequisitionListDetailView?requisitionListId=" + requisitionListId + "&editable=true";
				}
				
				/*For Handling multiple clicks. */
				if(!submitRequest()){
					return;
				}			
				cursor_wait();
				form.submit();
			}
		} else{
			MessageHelper.displayErrorMessage(MessageHelper.messages['ERR_RESOLVING_SKU_REQ_LIST']);
		}		
	},
	
	/**
	* Sets the currentPageType variable. 
	* This variable determines the type of catalog pages that are being viewed, such as product or item pages.
	*
	* @param {Boolean} pageType Indicates the type of catalog page viewed by the customer.
	*
	**/
	setCurrentPageType:function(pageType){
		this.currentPageType = pageType;
	},	
	
	/**
	* Sets the currentCatalogEntryId variable. 
	* This variable stores the catalogEntryId of the catalog item being viewed.
	*
	* @param {Boolean} catalogEntryId The ID of the new catalog item viewed by the customer.
	*
	**/
	setCurrentCatalogEntryId:function(catalogEntryId){
		this.currentCatalogEntryId = catalogEntryId;
	},
	
	/**
	 * Submits a category subscription request.
	 * If AjaxAddToCart is enabled, then invoke the AjaxCategorySubscribe service; otherwise submit the form and reload the page.
	 * 
	 * @param {String} formId The form Id.
	 * @param {Boolean} ajaxEnabled A true/false value that indicates if AjaxAddToCart is enabled.
	 */
	handleCategorySubscription:function(formId, ajaxEnabled){
		if(ajaxEnabled == true || ajaxEnabled == "true"){
			var form = document.forms[formId];
			var params = {};
			params["DM_ReqCmd"] = form.DM_ReqCmd.value;
			params["storeId"] = form.storeId.value;
			params["catalogId"] = form.catalogId.value;
			params["langId"] = form.langId.value;
			params["categoryId"] = form.categoryId.value;
			if(!submitRequest()){
				return;
			}
			cursor_wait();
			wc.service.invoke("AjaxCategorySubscribe", params);
		}else{
			var form = document.forms[formId];
			form.URL.value = location.href;
			form.submit();
		}
	},
	
	submitUrlToPortal:function(path, method) {
		method = method || "post";
		var el = document.getElementById("WC_BreadCrumbTrailDisplay_div_1").getElementsByTagName("A");
		// Create JSON object that will be passed as a post parameter.
		var arrayBreadCrumbs = new Array();
		var postData = "{";
		var arrayLenght = el.length;
		for (var i=0; i<el.length; i++) {
			arrayBreadCrumbs[i] = el[i].name;
			var valueHREF = el[i].href;
			if(valueHREF.indexOf('(') > 0) {
				// Split by small bracket and take second part. Ignore 'javascript:'
				var aa = valueHREF.split('(')[1];
				// Split by ',' and take first part to ignore storeId and catalogId.
				var bb = aa.split(',')[0];
				// Remove the inverted comma from the beginning and end of the string.
				var cc = bb.substr(1,bb.length - 2);
				valueHREF = cc;
			}
			var brName = el[i].name;
			// Remove all the commas from the bread crumb name.
			brName = brName.replace(/\,/g, "");
			postData = postData+"\""+valueHREF+"\""+":"+"\""+brName+"\"";
			if(i < arrayLenght - 1) {
				postData = postData + ",";
			}
		}
		//Start for last category in the bread crumb which is not a link.
		if(typeof(document.getElementById("brLastCategory")) != 'undefined' && document.getElementById("brLastCategory") != null)
		{
			var currentPath = window.location.href;
			var lastEntry = document.getElementById("brLastCategory").title;
			// Remove all the commas from the bread crumb name.
			lastEntry = lastEntry.replace(/\,/g, "");
			var entryFound = false;
			if(null !=lastEntry && lastEntry.length > 0) {
				for (j=0; j<arrayBreadCrumbs.length; j++) {
					if(lastEntry == arrayBreadCrumbs[j]) {
						entryFound = true;
						break;
					}
				}
				if(!entryFound) {
					postData = postData+","+"\""+currentPath+"\""+":"+"\""+lastEntry+"\"";
				}
			}
		}
		//End
		postData = postData + "}";
		// End Create JSON Object
		// Create a HTML for that will be subimitted with post.
		var form = document.createElement('form');
		//Move the submit function to another variable
		//so that it doesn't get overwritten.
		form._submit_function_ = form.submit;
		form.setAttribute("method", method);
		form.setAttribute("action", path);
		// Create on hidden input element it will carry the JSON object.
		var input = document.createElement('input');
		input.type = 'hidden';
		input.name = "breadcrumbJSON";
		input.value = postData;
		form.appendChild(input);
		document.body.appendChild(form);
		form._submit_function_(); //Call the renamed function.
	},
	
	/**
	 * Check whether the mini cart cookies need to be updated or not.
	 * 
	 */
	checkHeaderCartCookie:function(quantity){
	
		var currentHost = window.location.hostname;
		var domainValue = "";
		var isHostContainsCom = currentHost.indexOf("com");
		
		if(isHostContainsCom != -1){
			domainValue = ".parker.com";
		}else{
			domainValue = ".parker.corp";
		}
	
		var existingHeaderCartCookieVal = getCookie("cart_"+this.storeId+"_count");
		if(quantity != null && quantity != undefined){
			quantity = quantity.replace(",", "");
		}
		if(existingHeaderCartCookieVal != null && existingHeaderCartCookieVal != undefined){
			existingHeaderCartCookieVal = existingHeaderCartCookieVal.replace(",", "");
		}
		var totalQuantity = parseInt(existingHeaderCartCookieVal) + parseInt(quantity);
		
		if(existingHeaderCartCookieVal != undefined && existingHeaderCartCookieVal != ""){
				dojo.cookie("cart_"+this.storeId+"_count", totalQuantity, {path:'/',domain:domainValue});
				return true;
		}
		return false;
	}, //checkHeaderCartCookie closed.

	/**
	 * Create cart cookie to store total items.
	 */
	createHeaderCartCookie:function(quantity){
	
			var currentHost = window.location.hostname;
			var domainValue = "";
			var isHostContainsCom = currentHost.indexOf("com");
			
			if(isHostContainsCom != -1){
				domainValue = ".parker.com";
			}else{
				domainValue = ".parker.corp";
			}
		
			dojo.cookie("cart_"+this.storeId+"_count", quantity, {path:"/",domain:domainValue});
			//http://ph.parker.com/<country code>/<store ID/<language code>/< to be provided by WebSphere>			
	}, //createHeaderCartCookie closed.
	/**
	* CAD AJAX call.
	*/
	AjaxCadCall:function(form,format){
		 var params = [];
		 params["part"] = form.part.value;
		 params["format"] = format;
		 if(!submitRequest()){
			 return;
			}
		 cursor_wait();
		 
		 wc.service.invoke("AjaxCadDownload",params);
		 return false;
    },
 // Add to Quote Cart Ajax for quote
	AddItem2QuoteCartAjax : function(catEntryIdentifier, quantity, customParams)
	{
		
		var params = [];
		params.storeId		= this.storeId;
		params.catalogId	= this.catalogId;
		params.langId		= this.langId;
		params.orderId		= ".";
		params.calculationUsage = "-1";
		if (document.getElementById("parentCatID") != null && document.getElementById("parentCatID") != 'undefined') {
			params.parentCatID = document.getElementById("parentCatID").value;
		}
		
		var flag=true;
		
		if(dojo.isArray(catEntryIdentifier) && dojo.isArray(quantity)){
			for(var i=0; i<catEntryIdentifier.length; i++){
				if(!isPositiveInteger(quantity[i])){
					MessageHelper.displayErrorMessage(MessageHelper.messages['QUANTITY_INPUT_ERROR']);
					return;
				}
				params["catEntryId_" + (i+1)] = catEntryIdentifier[i];
				params["quantity_" + (i+1)]	= quantity[i];
			}
		}
		else{
			if(!isPositiveInteger(quantity)){
				MessageHelper.displayErrorMessage(MessageHelper.messages['QUANTITY_INPUT_ERROR']);
				return;
			}
			params.catEntryId	= catEntryIdentifier;
			params.quantity		= quantity;
		}		

		//Pass any other customParams set by other add on features
		if(customParams != null && customParams != 'undefined'){
			
			for(i in customParams){
				params[i] = customParams[i];
			}			
		}
		
		//For Handling multiple clicks
		if(!submitRequest()){
			return;
		}   
		cursor_wait();		
		if(this.ajaxShopCart){
			var cartCookieStatus = this.checkHeaderQuoteCartCookie(quantity);
			if(!cartCookieStatus){
				this.createHeaderQuoteCartCookie(quantity);
			}

			wc.service.invoke("AjaxAddQuoteItem", params);
			this.baseItemAddedToCart=true;
		}else{
			wc.service.invoke("AjaxAddQuoteItem_shopCart", params);
			this.baseItemAddedToCart=true;
		}
		
	},
	/**
	 * Check whether the mini cart cookies need to be updated or not.
	 * 
	 */
	checkHeaderQuoteCartCookie:function(quantity){	
		var currentHost = window.location.hostname;
		var domainValue = "";
		var isHostContainsCom = currentHost.indexOf("com");
		
		if(isHostContainsCom != -1){
			domainValue = ".parker.com";
		}else{
			domainValue = ".parker.corp";
		}	
		var existingHeaderCartCookieVal = getCookie("quote_"+this.storeId+"_count");	
		if(quantity != null && quantity != undefined){
			quantity = quantity.replace(",", "");
		}
		if(existingHeaderCartCookieVal != null && existingHeaderCartCookieVal != undefined){
			existingHeaderCartCookieVal = existingHeaderCartCookieVal.replace(",", "");
		}
		var totalQuantity = parseInt(existingHeaderCartCookieVal) + parseInt(quantity);		
		if(existingHeaderCartCookieVal != undefined && existingHeaderCartCookieVal != ""){
				dojo.cookie("quote_"+this.storeId+"_count", totalQuantity, {path:'/',domain:domainValue});				
				return true;
		}
		return false;
	}, //checkHeaderCartCookie closed.

	/**
	 * Create quote cart cookie to store total items.
	 */
	createHeaderQuoteCartCookie:function(quantity){	
			var currentHost = window.location.hostname;
			var domainValue = "";
			var isHostContainsCom = currentHost.indexOf("com");
			
			if(isHostContainsCom != -1){
				domainValue = ".parker.com";
			}else{
				domainValue = ".parker.corp";
			}
		
			dojo.cookie("quote_"+this.storeId+"_count", quantity, {path:"/",domain:domainValue});			
	} //createHeaderQuoteCartCookie closed.
	
}
categoryDisplayJS.HistoryTracker.prototype.back = categoryDisplayJS.goBack;
categoryDisplayJS.HistoryTracker.prototype.forward=categoryDisplayJS.goForward;